import { FIGURE_PARTS, QUESTIONS_PER_RUN } from './config.js?v=1.44';
import { DB } from './data.js?v=1.44';
import { P, S, figParts } from './state.js?v=1.44';
import { lang, tx, themeName, diffName, archName, moodName, teamName } from './i18n.js?v=1.44';
import { $, clear, el } from './ui.js?v=1.44';
import { requestQuizFit, resetScreenScroll, syncDock } from './layout.js?v=1.44';
import { isPaused } from './pause.js?v=1.44';
import { questionSignature } from './checkpoint.js?v=1.44';

export function shuffle(a) {
  const arr = a.slice();
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

export function scopeKey(session = S) {
  const theme = session.random ? 'random' : session.theme;
  return `${theme}|${session.diff.id}|${session.mood}`;
}

export function questionKey(q) { return q.rev > 1 ? q.id + 'r' + q.rev : q.id; }

function usedMap(session = S) {
  return (P.used && P.used[scopeKey(session)]) || {};
}

/**
 * Build a pool: mood + difficulty first, then drop mood, then widen difficulty.
 * Anti-repeat uses finished quizzes only.
 */
export function pickQuestions({ random, theme, diff, mood, count }) {
  const base = random ? DB.questions : (DB.byTheme[theme] || []);
  const inDiff = (q, mn, mx) => q.diff >= mn && q.diff <= mx;
  const inMood = (q) => Array.isArray(q.moods) && q.moods.includes(mood);

  let pool = base.filter((q) => inDiff(q, diff.min, diff.max) && inMood(q));
  if (pool.length < count) pool = base.filter((q) => inDiff(q, diff.min, diff.max));

  let mn = diff.min;
  let mx = diff.max;
  while (pool.length < count && (mn > 1 || mx < 5)) {
    if (mn > 1) mn -= 1;
    if (mx < 5) mx += 1;
    pool = base.filter((q) => inDiff(q, mn, mx));
  }
  if (pool.length < count) pool = base.slice();

  const used = usedMap();
  let fresh = pool.filter((q) => !used[questionKey(q)]);
  if (fresh.length < count) {
    const k = scopeKey();
    if (P.used && P.used[k]) {
      const ids = Object.keys(P.used[k]);
      const drop = ids.slice(0, Math.max(1, ids.length - count * 3));
      drop.forEach((id) => { delete P.used[k][id]; });
      fresh = pool.filter((q) => !P.used[k][questionKey(q)]);
    }
    if (fresh.length < count) fresh = pool;
  }
  return shuffle(fresh).slice(0, count);
}

export function prepareQuestion(q, presetOrder = null) {
  const pack = q[lang()] || q.ru;
  const idx = pack.o.map((_, i) => i);
  const order = Array.isArray(presetOrder) ? presetOrder.slice() : shuffle(idx);
  return {
    id: q.id,
    rev: q.rev || 1,
    signature: questionSignature(q),
    theme: q.theme,
    moods: q.moods,
    a1: q.a1,
    a2: q.a2,
    order,
    text: pack.q,
    fact: pack.f,
    options: order.map((i) => pack.o[i]),
    correct: order.indexOf(q.correct),
  };
}

export function retargetQuestion(pq) {
  const raw = DB.questions.find((x) => x.id === pq.id);
  if (!raw) return pq;
  const pack = raw[lang()] || raw.ru;
  const order = pq.order || pack.o.map((_, i) => i);
  pq.text = pack.q;
  pq.fact = pack.f;
  pq.order = order;
  pq.options = order.map((i) => pack.o[i]);
  pq.correct = order.indexOf(raw.correct);
  return pq;
}

let raf = 0;
let timerLeft = 0;
let timerTotal = 20;
let lastTs = 0;
let onTimeout = null;

export function stopTimer() {
  if (raf) cancelAnimationFrame(raf);
  raf = 0;
  onTimeout = null;
}
export function timerSnapshot() { return { left: timerLeft, total: timerTotal, running: !!raf, paused: isPaused() }; }
export function paintTimer() {
  const t = $('quiz-timer');
  if (!t) return;
  const p = Math.max(0, timerLeft / timerTotal * 100);
  t.style.width = p + '%';
  t.style.background = p > 40 ? 'var(--ok)' : (p > 15 ? '#ffd54f' : 'var(--bad)');
  const seconds = Math.max(0, Math.ceil(timerLeft));
  const label = $('timer-label');
  if (label) label.textContent = seconds > 0 ? tx('timer_seconds', { n: seconds }) : tx('timer_unlimited');
  const headerTime = $('header-quiz-time');
  if (headerTime) headerTime.textContent = S && !S.done ? (seconds > 0 ? tx('timer_seconds', { n: seconds }) : '∞') : '';
  const track = $('timer-track');
  if (track) {
    track.setAttribute('aria-valuemax', String(timerTotal));
    track.setAttribute('aria-valuenow', String(seconds));
    track.setAttribute('aria-valuetext', label ? label.textContent : String(seconds));
  }
}
function tick(now) {
  if (!raf) return;
  if (isPaused()) { lastTs = now; raf = requestAnimationFrame(tick); return; }
  const dt = Math.min(.25, (now - lastTs) / 1000);
  lastTs = now;
  timerLeft = Math.max(0, timerLeft - dt);
  paintTimer();
  if (timerLeft <= 0) {
    const callback = onTimeout;
    stopTimer();
    if (callback) callback();
    return;
  }
  raf = requestAnimationFrame(tick);
}
export function startTimer(seconds, timeoutCb, remaining = null) {
  stopTimer();
  timerTotal = Math.max(1, Number(seconds) || 20);
  timerLeft = remaining==null ? timerTotal : Math.max(0,Math.min(timerTotal,Number(remaining)||0));
  onTimeout = timeoutCb;
  paintTimer();
  lastTs = performance.now();
  if(timerLeft>0)raf = requestAnimationFrame(tick);
  else if(timeoutCb)timeoutCb();
}
export function totalInRun() {
  if (S && Array.isArray(S.q) && S.q.length) return S.q.length;
  return S && S.mode === 'duel' ? QUESTIONS_PER_RUN * 2 : QUESTIONS_PER_RUN;
}
export function paintDuelBoard(activeIdx) {
  const board = $('duel-board');
  if (!board || !S || S.mode !== 'duel' || !S.teams) {
    if (board) board.hidden = true;
    return;
  }
  const who = activeIdx == null ? S.qi % 2 : activeIdx;
  board.hidden = false;
  $('duel-compact-name').textContent = tx('turn_fmt', { n: teamName(S.teams[who]) });
  $('duel-compact-score').textContent = S.teams.map(t => t.score).join(' : ');
  S.teams.forEach((t, i) => {
    const row = $('duel-row-' + i);
    if (!row) return;
    row.classList.toggle('on', i === who);
    row.setAttribute('aria-current', i === who ? 'true' : 'false');
    row.title = teamName(t);
    row.querySelector('.duel-name').textContent = teamName(t);
    row.querySelector('.duel-pts').textContent = String(t.score);
    row.setAttribute('aria-label', `${teamName(t)}: ${t.score}${i === who ? '. ' + tx('turn_fmt', { n: teamName(t) }) : ''}`);
  });
}
export function paintQuestionText() {
  const q = S && S.q && S.q[S.qi];
  if (!q) return;
  $('quiz-q').textContent = q.text;
  $('quiz-progress').style.width = ((S.qi / totalInRun()) * 100) + '%';
  $('quiz-count').textContent = tx('count_fmt', { n: S.qi + 1, t: totalInRun() });
  if ($('header-quiz-count')) {
    $('header-quiz-count').textContent = `${S.qi + 1} / ${totalInRun()}`;
    $('header-quiz-count').setAttribute('aria-label', tx('count_fmt', { n: S.qi + 1, t: totalInRun() }));
  }
  paintDuelBoard();
  const chip = $('fig-progress');
  if (chip) {
    chip.classList.toggle('duel-hide', S.mode === 'duel');
    chip.textContent = S.mode === 'duel' ? '' : tx('figchip_fmt', { p: figParts(S.fig), d: diffName(S.diff) });
  }
  $('quiz-turn').hidden = S.mode !== 'duel';
  $('quiz-turn').textContent = S.mode === 'duel' ? tx('turn_fmt', { n: teamName(S.teams[S.qi % 2]) }) : '';
  [...$('quiz-ans').querySelectorAll('.ans')].forEach((b, i) => {
    b.querySelector('.ans-txt').textContent = q.options[i];
  });
  paintTimer();
  if (S.done) paintAnswerFeedback();
  else $('quiz-next').textContent = tx('choose_answer');
  requestQuizFit();
}
export function renderQuestion() {
  const q = S && S.q && S.q[S.qi];
  if (!q) return;
  $('scr-quiz').dataset.view = 'question';
  S.showingFact = false;
  S.answerChoice = undefined;
  S.timerExpired = false;
  const box = $('quiz-ans');
  clear(box);
  q.options.forEach((opt, i) => {
    const b = el('button', { class: 'ans', type: 'button' });
    b.appendChild(el('span', { class: 'ans-key', text: String(i + 1), 'aria-hidden': 'true' }));
    b.appendChild(el('span', { class: 'ans-txt', text: opt }));
    b.addEventListener('click', () => applyAnswer(i));
    box.appendChild(b);
  });
  $('quiz-fact').hidden = true;
  $('quiz-question-view').hidden = false;
  $('quiz-next').disabled = true;
  $('quiz-review').hidden = true;
  paintQuestionText();
  // The timer is intentionally soft, as described in Help. At zero the player
  // can still answer; this is not an accidental lost timeout callback anymore.
  startTimer(S.diff.sec, () => { if (S && !S.done) { S.timerExpired = true; paintTimer(); } });
  resetScreenScroll('quiz');
  syncDock();
  window.dispatchEvent(new Event('factbum:state'));
}
export function showAnswerView(showFact = true) {
  if (!S || !S.done) return;
  S.showingFact = showFact;
  $('scr-quiz').dataset.view = showFact ? 'fact' : 'review';
  $('quiz-question-view').hidden = showFact;
  $('quiz-fact').hidden = !showFact;
  const review = $('quiz-review');
  review.hidden = false;
  review.textContent = tx(showFact ? 'quiz_review' : 'quiz_fact');
  review.setAttribute('aria-pressed', showFact ? 'false' : 'true');
  review.setAttribute('aria-controls', showFact ? 'quiz-question-view' : 'quiz-fact');
  resetScreenScroll('quiz');
  syncDock();
  window.dispatchEvent(new Event('factbum:state'));
}
/** Restore the current UI without counting an answer again. */
export function restoreQuestionState({view,timer}) {
  if(!S?.q?.[S.qi])return;
  const answer=S.answers[S.qi];
  S.done=false;renderQuestion();stopTimer();
  timerTotal=timer.total;timerLeft=timer.left;
  if(answer!==-1){
    S.done=true;S.answerChoice=answer;S.showingFact=view!=='review';
    paintAnswerFeedback();showAnswerView(view!=='review');paintTimer();
  }else{
    startTimer(timer.total,()=>{if(S&&!S.done){S.timerExpired=true;paintTimer();}},timer.left);
  }
  syncDock();requestQuizFit();
}

/** Repaint feedback without mutating score, advice or question order. */
export function paintAnswerFeedback() {
  const q = S.q[S.qi];
  const choice = S.answerChoice;
  const ok = choice === q.correct;
  const buttons = [...$('quiz-ans').querySelectorAll('.ans')];
  buttons.forEach((b, j) => {
    b.classList.add('off'); b.disabled = true;
    b.classList.toggle('ok', j === q.correct);
    b.classList.toggle('bad', choice === j && !ok);
    b.querySelector('.ans-key').textContent = j === q.correct ? '✓' : choice === j ? '×' : String(j + 1);
    b.setAttribute('aria-label', q.options[j] + (j === q.correct ? '. ' + tx('correct_answer') : ''));
  });
  const verdict = $('quiz-verdict');
  verdict.textContent = ok ? tx('v_ok') : choice == null ? tx('v_time') : tx('v_bad');
  verdict.className = 'verdict ' + (ok ? 'ok' : 'bad');
  $('quiz-fact-txt').textContent = q.fact;
  $('quiz-correct-text').textContent = q.options[q.correct];
  const count = tx('count_fmt', { n: S.qi + 1, t: totalInRun() });
  $('quiz-feedback-context').textContent = S.mode === 'duel'
    ? count + ' · ' + teamName(S.teams[S.qi % 2]) + ' · ' + S.teams[0].score + ':' + S.teams[1].score : count;
  const chips = $('quiz-chips'); clear(chips);
  chips.classList.toggle('duel-stack', S.mode === 'duel');
  if (S.mode !== 'duel') {
    [q.a1, q.a2].filter(Boolean).forEach((id) => {
      const arch = DB.archetypes.find((a) => a.id === id);
      const chip = el('span', { class: 'chip' });
      chip.appendChild(el('span', { class: 'arch-e', text: arch ? arch.e : '', 'aria-hidden': 'true' }));
      chip.appendChild(el('span', { text: '+1 ' + archName(id) })); chips.appendChild(chip);
    });
    chips.appendChild(el('span', { class: 'chip cur', text: tx('chip_cur') }));
  }
  paintDuelBoard();
  const last = S.qi === totalInRun() - 1;
  const next = $('quiz-next'); next.disabled = false;
  next.textContent = S.mode === 'duel' && !last ? tx('handoff_btn') : tx(last ? 'final' : 'next');
  const review = $('quiz-review');
  review.textContent = tx(S.showingFact ? 'quiz_review' : 'quiz_fact');
  requestQuizFit();
}
export function applyAnswer(choice) {
  if (!S || !S.running || S.done || isPaused()) return null;
  const q = S.q && S.q[S.qi];
  if (!q || (choice !== null && (!Number.isInteger(choice) || choice < 0 || choice >= q.options.length))) return null;
  S.done = true;
  S.answerChoice = choice;
  if(!Array.isArray(S.answers)||S.answers.length!==S.q.length)S.answers=Array(S.q.length).fill(-1);
  S.answers[S.qi]=choice;
  stopTimer();
  paintTimer();
  const ok = choice === q.correct;
  if (!ok) S.wrong += 1;
  if (S.mode === 'duel') {
    if (ok) S.teams[S.qi % 2].score += 1;
  } else {
    S.pts[q.a1] = (S.pts[q.a1] || 0) + 1;
    if (q.a2) S.pts[q.a2] = (S.pts[q.a2] || 0) + 1;
  }
  paintAnswerFeedback();
  showAnswerView(true);
  return { ok, last: S.qi === totalInRun() - 1 };
}

export function markSessionUsed() {
  if (!S || !S.q) return;
  if (!P.used) P.used = {};
  const k = scopeKey();
  const map = P.used[k] || (P.used[k] = {});
  S.q.forEach((q) => { map[questionKey(q)] = 1; });
}

export function recordThemeShares() {
  if (S.random) {
    P.rand = (P.rand || 0) + 1;
    const bag = {};
    S.q.forEach((q) => { bag[q.theme] = (bag[q.theme] || 0) + 1; });
    for (const [tid, n] of Object.entries(bag)) {
      const cur = P.themes[tid] || { quizzes: 0, questions: 0 };
      P.themes[tid] = { quizzes: cur.quizzes, questions: cur.questions + n };
    }
  } else {
    const cur = P.themes[S.theme] || { quizzes: 0, questions: 0 };
    P.themes[S.theme] = {
      quizzes: cur.quizzes + 1,
      questions: cur.questions + S.q.length,
    };
  }
}

export function moodLine() {
  if (!S) return '';
  if (S.random) return tx('random_mood');
  const t = DB.themes.find((x) => x.id === S.theme);
  return `${t ? t.emoji : ''} ${themeName(S.theme)}`;
}

export function startHint() {
  if (!S || !S.diff || !S.mood) return tx('mood_hint');
  const key = S.mode === 'duel' ? 'start_hint_duel' : 'start_hint_fmt';
  return tx(key, { d: diffName(S.diff), m: moodName(S.mood) });
}

export { FIGURE_PARTS };
