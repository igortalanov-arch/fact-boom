/** Desktop side panels (variant B): live figure progress, session info, records.
 *  Visible only on wide screens (see CSS breakpoint); updated on state/locale/viewport events, with no background polling. */
import { FIGURE_PARTS } from './config.js?v=1.44';
import { DB } from './data.js?v=1.44';
import { P, S, figParts } from './state.js?v=1.44';
import { lang, tx, themeName, diffName, moodName, figName, archName, teamName } from './i18n.js?v=1.44';
import { $, clear, el } from './ui.js?v=1.44';
import { iconEl, ACH_ICON, THEME_ICON, MOOD_ICON } from './icons.js?v=1.44';
import { figSvgEl } from './silhouettes.js?v=1.44';
import { partLabel } from './figures.js?v=1.44';

const PN_ACH = [
  { id: 'part', label: 'ach1' },
  { id: 'fig', label: 'ach2' },
  { id: 'col3', label: 'ach3' },
  { id: 'q100', label: 'ach4' },
  { id: 'travel', label: 'ach5' },
  { id: 'legend', label: 'ach6' },
];

const WIDE_Q = '(min-width:1220px)';
let lastSig = '';

/* v1.44: the panel figure is browsable (‹ › arrows). While a solo run is in
 * progress the panel is locked to the figure the player picked for that game. */
const LS_PANEL_FIG = 'factbum_panel_fig';
let panelFigId = null;
try { panelFigId = localStorage.getItem(LS_PANEL_FIG) || null; } catch { /* private mode */ }

function panelBrowseLocked() {
  return !!(S && S.running && S.mode === 'solo' && S.fig);
}

function collectingFig() {
  const figs = DB.figures || [];
  if (!figs.length) return null;
  if (panelBrowseLocked()) return figs.find((f) => f.id === S.fig) || figs[0];
  let fig = panelFigId ? figs.find((f) => f.id === panelFigId) : null;
  if (!fig) fig = figs.find((f) => figParts(f.id) < FIGURE_PARTS) || figs[0];
  return fig;
}

function stepPanelFig(dir) {
  const figs = DB.figures || [];
  if (!figs.length || panelBrowseLocked()) return;
  const cur = collectingFig();
  const idx = cur ? figs.findIndex((f) => f.id === cur.id) : -1;
  const next = figs[((idx + dir) % figs.length + figs.length) % figs.length];
  if (!next) return;
  panelFigId = next.id;
  try { localStorage.setItem(LS_PANEL_FIG, panelFigId); } catch { /* ignore */ }
  paint();
}

function totals() {
  const parts = Object.values(P.figs || {}).reduce((a, b) => a + (Number(b) || 0), 0);
  let topArch = null;
  let topN = 0;
  for (const [id, n] of Object.entries(P.arch || {})) {
    if (Number(n) > topN) { topN = Number(n); topArch = id; }
  }
  return {
    quizzes: (P.sessions || 0) + (P.duels || 0),
    answered: P.answered || 0,
    parts,
    best: P.best ? `${P.best.correct}/10` : '—',
    topArch: topArch ? archName(topArch) : '—',
  };
}

function row(name, value) {
  const r = el('div', { class: 'prow' });
  r.appendChild(el('span', { class: 'prow-name', text: name }));
  r.appendChild(el('b', { text: String(value) }));
  return r;
}

function isDuel() {
  return !!(S && S.mode === 'duel' && S.teams);
}

function visitStats() {
  try {
    const raw = sessionStorage.getItem('factbum_visit');
    const arr = raw ? JSON.parse(raw) : [];
    return Array.isArray(arr) ? arr.filter((e) => e && e.m === 'duel') : [];
  } catch { return []; }
}

function paintLeftDuel(host) {
  clear(host);
  const card = el('div', { class: 'pcard' });
  card.appendChild(el('h4', { text: tx('pn_teams') }));
  const turn = S.running ? (S.qi % 2) : -1;
  S.teams.forEach((t, i) => {
    const r = el('div', { class: turn === i ? 'pteam turn' : 'pteam' });
    r.appendChild(el('span', { class: 'tdot' }));
    r.appendChild(el('span', { class: 'tnm', text: teamName(t) }));
    r.appendChild(el('span', { class: 'tsc', text: String(t.score || 0) }));
    card.appendChild(r);
  });
  if (turn >= 0 && S.teams[turn]) {
    card.appendChild(el('div', { class: 'pmut', text: `${tx('pn_turn')}: ${teamName(S.teams[turn])}` }));
  }
  host.appendChild(card);
}

function paintRightDuel(host) {
  clear(host);
  const duels = visitStats();
  const card = el('div', { class: 'pcard' });
  card.appendChild(el('h4', { text: tx('pn_visit') }));
  card.appendChild(row(tx('pn_runs'), duels.length));
  const th = {};
  const mo = {};
  duels.forEach((d) => {
    if (d.t) th[d.t] = (th[d.t] || 0) + 1;
    if (d.mo) mo[d.mo] = (mo[d.mo] || 0) + 1;
  });
  Object.entries(th).sort((a, b) => b[1] - a[1]).forEach(([id, n]) => {
    const r = el('div', { class: 'prow2' });
    r.appendChild(iconEl(id === 'random' ? 'theme-random' : (THEME_ICON[id] || 'theme-body'), 'ico sm'));
    r.appendChild(el('span', { class: 'nm', text: id === 'random' ? tx('random_name') : themeName(id) }));
    r.appendChild(el('b', { text: '×' + n }));
    card.appendChild(r);
  });
  Object.entries(mo).sort((a, b) => b[1] - a[1]).forEach(([id, n]) => {
    const r = el('div', { class: 'prow2' });
    r.appendChild(iconEl(MOOD_ICON[id] || 'mood-fun', 'ico sm'));
    r.appendChild(el('span', { class: 'nm', text: moodName(id) }));
    r.appendChild(el('b', { text: '×' + n }));
    card.appendChild(r);
  });
  host.appendChild(card);
}

function paintLeft(host) {
  if (isDuel()) { paintLeftDuel(host); return; }
  clear(host);
  const fig = collectingFig();
  if (fig) {
    const card = el('div', { class: 'pcard' });
    card.appendChild(el('h4', { text: tx('pn_collect') }));
    const wrap = el('div', { class: 'pfigwrap' });
    wrap.appendChild(figSvgEl(fig.id, figParts(fig.id), { size: 'sm' }));
    card.appendChild(wrap);
    const locked = panelBrowseLocked();
    const nav = el('div', { class: 'pnav' });
    const prevBtn = el('button', { class: 'pnav-btn', type: 'button', text: '‹', 'aria-label': tx('panel_prev_fig'), title: tx('panel_prev_fig') });
    const nextBtn = el('button', { class: 'pnav-btn', type: 'button', text: '›', 'aria-label': tx('panel_next_fig'), title: tx('panel_next_fig') });
    if (locked) { prevBtn.disabled = true; nextBtn.disabled = true; }
    prevBtn.addEventListener('click', () => stepPanelFig(-1));
    nextBtn.addEventListener('click', () => stepPanelFig(1));
    nav.appendChild(prevBtn);
    nav.appendChild(el('div', { class: 'pnm', text: figName(fig.id) }));
    nav.appendChild(nextBtn);
    card.appendChild(nav);
    const segs = el('div', { class: 'psegs' });
    const n = figParts(fig.id);
    for (let i = 0; i < FIGURE_PARTS; i++) {
      segs.appendChild(el('i', { class: n > i ? 'on' : '' }));
    }
    card.appendChild(segs);
    card.appendChild(el('div', { class: 'pmut', text: `${n}/${FIGURE_PARTS} · ${tx('pn_part_hint')}` }));
    for (let i = 0; i < FIGURE_PARTS; i++) {
      const pr = el('div', { class: 'ppart' });
      pr.appendChild(el('span', { class: n > i ? 'dot on' : 'dot' }));
      pr.appendChild(el('span', { text: partLabel(fig, i) }));
      card.appendChild(pr);
    }
    host.appendChild(card);
  }
  if (S && (S.theme || S.random)) {
    const card = el('div', { class: 'pcard' });
    card.appendChild(el('h4', { text: tx('pn_theme') }));
    const trow = el('div', { class: 'ptheme' });
    trow.appendChild(iconEl(S.random ? 'theme-random' : (THEME_ICON[S.theme] || 'theme-body'), 'ico sm'));
    trow.appendChild(el('b', { text: S.random ? tx('random_name') : themeName(S.theme) }));
    card.appendChild(trow);
    if (S.diff) card.appendChild(row(tx('mood_diff_title'), diffName(S.diff)));
    if (S.mood) card.appendChild(row(tx('mood_mood_title'), moodName(S.mood)));
    host.appendChild(card);
  }
}

function paintRight(host) {
  if (isDuel()) { paintRightDuel(host); return; }
  clear(host);
  const t = totals();
  const rec = el('div', { class: 'pcard' });
  rec.appendChild(el('h4', { text: tx('pn_records') }));
  rec.appendChild(row(tx('pn_quizzes'), t.quizzes));
  rec.appendChild(row(tx('pn_answered'), t.answered));
  rec.appendChild(row(tx('pn_parts'), t.parts));
  rec.appendChild(row(tx('pn_best'), t.best));
  rec.appendChild(row(tx('pn_toparch'), t.topArch));
  host.appendChild(rec);
  const ac = el('div', { class: 'pcard' });
  ac.appendChild(el('h4', { text: tx('pn_ach') }));
  PN_ACH.forEach((a) => {
    const on = !!(P.ach && P.ach[a.id]);
    const chip = el('span', { class: on ? 'pach on' : 'pach' });
    chip.appendChild(iconEl(ACH_ICON[a.id] || 'ach-part', on ? 'ico sm' : 'ico sm dim'));
    chip.appendChild(el('span', { text: tx(a.label) }));
    ac.appendChild(chip);
  });
  host.appendChild(ac);
}

function signature() {
  try {
    return JSON.stringify([
      lang(), document.documentElement.getAttribute('data-theme'),
      (DB.figures || []).length,
      S && S.fig, S && S.running, S && S.qi, S && S.theme, S && S.random,
      S && S.diff && S.diff.id, S && S.mood,
      P.figs, P.ach, P.sessions, P.duels, P.answered,
      P.best && P.best.correct, P.arch,
      S && S.teams ? S.teams.map((t) => (t.name || '') + ':' + (t.score || 0)).join(',') : '',
      visitStats().length,
    ]);
  } catch { return ''; }
}

function paint() {
  const l = $('panel-left');
  const r = $('panel-right');
  if (!l || !r) return;
  if (!window.matchMedia || !window.matchMedia(WIDE_Q).matches) return;
  lastSig = signature();
  try { paintLeft(l); } catch { /* keep old */ }
  try { paintRight(r); } catch { /* keep old */ }
}

export function initPanels() {
  const update = () => {
    if (document.hidden) return;
    if (!window.matchMedia || !window.matchMedia(WIDE_Q).matches) return;
    if (signature() !== lastSig) paint();
  };
  window.addEventListener('factbum:state', update);
  window.addEventListener('factbum:screen', update);
  window.addEventListener('resize', () => { lastSig = ''; update(); }, { passive: true });
  document.addEventListener('visibilitychange', update);
  update();
}
