import { FIGURE_PARTS, QUESTIONS_PER_RUN, VERSION, getRank } from './config.js?v=1.44';
import { DB, loadAll } from './data.js?v=1.44';
import {
  P, S, prefs, setSession, hydrateProgress, save, savePrefs,
  figParts, themeStat, migrateSavedCards, syncInfo, syncNow, hasSavedOperation, isOperationDurable,
} from './state.js?v=1.44';
import {
  applyYandexChrome, gameReady, initYandex, showFullscreen, showRewarded,
  requestFullscreen, isAuthorized, yandexPlayerName, yandexPlayerID,
  gameplayStart, gameplayStop, yaPlatformLang,
} from './yandex.js?v=1.44';
import {
  applyStaticI18n, lang, setLang, setColorTheme, tx, themeName, figName,
  diffName, rankName, moodName, teamName,
} from './i18n.js?v=1.44';
import { $, clear, el, go, bindHistory, bindModal, confirmExit, screenId, toast, hideModal, showModal } from './ui.js?v=1.44';
import {
  pickQuestions, prepareQuestion, retargetQuestion, renderQuestion, applyAnswer, stopTimer,
  markSessionUsed, recordThemeShares, moodLine, startHint, totalInRun, paintDuelBoard, paintQuestionText, showAnswerView, timerSnapshot, restoreQuestionState,
} from './quiz.js?v=1.44';
import { drawFig, renderFigPicker, PART_LABEL } from './figures.js?v=1.44';
import { celebrateFx } from './silhouettes.js?v=1.44';
import { iconEl, iconSrc, DIFF_ICON, RANK_ICON, THEME_ICON, MOOD_ICON } from './icons.js?v=1.44';
import { calcCard, renderCard } from './card.js?v=1.44';
import { click as soundClick, jingle as soundJingle, fanfare as soundFanfare, setSound, isSoundOn } from './sound.js?v=1.44';
import { renderMuseum, refreshAchievements, bindFigZoom, paintFigZoom, closeFigZoom, bindMuseumTabs } from './museum.js?v=1.44';
import { archiveResultCard } from './share.js?v=1.44';
import { initPanels } from './panels.js?v=1.44';
import { initLayout, syncDock, requestQuizFit } from './layout.js?v=1.44';
import { isPaused, hasPause } from './pause.js?v=1.44';
import { createRunId, completionId, completedLocally, markCompleted, discardCheckpoint, findCheckpoint, retainedRunOperations, checkpointReferences, packCheckpoint, storeCheckpoint, decodeCheckpoint, acquireRun, releaseRun, ownsRun } from './checkpoint.js?v=1.44';

let museumReturn = 'start';
let exitPending = false;
let rewardInFlight = false;
let languageTouched = false;

function playerLabel() {
  const y = prefs.user;
  // A name is not proof that cloud persistence succeeded.
  const who=y&&y.authorized ? tx('player_account') : tx('sync_guest');
  const state=syncInfo.state;
  const status=syncInfo.local===false?'sync_error':state==='synced'?'sync_saved':state==='syncing'||state==='pending'||state==='loading'?'sync_pending':state==='quota'?'sync_quota':state==='storage-error'?'sync_error':'sync_local';
  return `${who} · ${tx(status)}`;
}
function teamLabel(t) { return teamName(t); }

function backTarget() {
  const id = screenId();
  if (id === 'theme') return S && S.mode === 'duel' ? 'teams' : 'start';
  if (id === 'mood') return 'theme';
  if (id === 'fig') return 'mood';
  if (id === 'museum' && ['card', 'part', 'duel'].includes(museumReturn) && S && !S.running) return museumReturn;
  return 'start';
}
function paintBack() {
  const b = $('btn-back'); if (!b) return;
  b.hidden = ['boot', 'start'].includes(screenId());
  const zoom = $('fig-zoom');
  const label = zoom && !zoom.hidden ? tx('museum_zoom_close')
    : screenId() === 'quiz' && S && S.running ? tx('nav_exit_quiz')
    : backTarget() === 'start' ? tx('nav_home') : tx('back');
  b.setAttribute('aria-label', label); b.title = label;
}
/** Explicit routes: browser history can never revive an already finished round. */
function visit(id, opts = {}) {
  if (hasPause('ad') || hasPause('platform') || S?.finishing) return;
  const previous = screenId();
  if(S?.running&&previous==='quiz'&&id!=='quiz')return;
  if (id === 'quiz' && !(S && S.running && S.q)) id = 'start';
  if (['part', 'card'].includes(id) && !(S && S.card)) id = 'start';
  if (id === 'duel' && !(S && S.teams && !S.running)) id = 'start';
  if (id === 'teams' && !(S && S.mode === 'duel')) id = 'start';
  if (id === 'mood' && !(S && S.theme)) id = S ? 'theme' : 'start';
  if (id === 'fig' && !(S && S.mode === 'solo' && S.diff && S.mood)) id = S && S.theme ? 'mood' : 'start';
  if (id === 'start') {
    if(S?.running){saveRoundCheckpoint();stopCheckpointClock();releaseRun();}
    stopTimer(); gameplayStop(); hideHandoff(); setSession(null); paintStart();
  }
  if (id === 'theme') {
    if (!S || (S.card && !S.running)) setSession({ mode: 'solo' });
    $('theme-sub').textContent = S.mode === 'duel' ? tx('theme_sub_duel') : tx('theme_sub');
    renderThemes();
  }
  if (id === 'mood') { renderDiffMoods(); syncStartBtn(); }
  if (id === 'fig') renderFigPicker((fig) => beginSolo(fig));
  if (id === 'museum') {
    if (previous !== 'museum') museumReturn = ['card', 'part', 'duel'].includes(previous) ? previous : 'start';
    renderMuseum();
  }
  if (id === 'card') renderCard();
  if (id === 'part') paintPart();
  if (id === 'duel') paintDuelResult();
  if (id === 'help') renderHelp();
  closeFigZoom();
  go(id, opts);
  paintBack();
  if (id === 'start' || id === 'theme') maybeInterstitial();
}
async function navigateBack(opts = { push: false, replace: true }) {
  if(S?.finishing)return false;
  if (!$('modal').hidden) { hideModal(false); return false; }
  if (!$('fig-zoom').hidden) { closeFigZoom(); paintBack(); return false; }
  if (hasPause('ad') || hasPause('platform')) return false;
  if (screenId() === 'quiz' && S && S.running) return exitQuiz(opts);
  visit(backTarget(), opts);
  return true;
}

function stampUiIcon(node, name) {
  if (!node) return;
  let ic = node.querySelector(':scope > img.ico.ui');
  if (!ic) {
    ic = iconEl(name, 'ico ui');
    node.insertBefore(ic, node.firstChild);
  } else {
    ic.src = iconSrc(name);
  }
}

function paintStart() {
  stampUiIcon($('btn-play'), 'ui-play');
  stampUiIcon($('btn-duel'), 'ui-duel');
  stampUiIcon($('btn-museum'), 'ui-museum');
  stampUiIcon($('btn-help'), 'ui-help');
  $('start-stats').textContent = (P.sessions || P.duels)
    ? tx('stats_fmt', { s: P.sessions, d: P.duels || 0, a: P.answered })
    : tx('stats_first');
  $('player-line').textContent = playerLabel();
  $('game-version').textContent = tx('version_fmt', { v: VERSION });
  stampUiIcon($('btn-lang'), 'ui-lang');
  const langBtn = $('btn-lang');
  const langSpan = langBtn && langBtn.querySelector('span');
  if (langSpan) langSpan.textContent = lang() === 'ru' ? 'EN' : 'RU';
  if (langBtn) langBtn.setAttribute('aria-label', lang() === 'ru' ? 'English' : 'Русский');
  stampUiIcon($('btn-theme'), prefs.theme === 'dark' ? 'ui-sun' : 'ui-moon');
  const themeBtn = $('btn-theme');
  if (themeBtn) themeBtn.setAttribute('aria-label', tx(prefs.theme === 'dark' ? 'theme_light' : 'theme_dark'));
  const sndBtn = $('btn-sound');
  if (sndBtn) {
    const on = isSoundOn();
    sndBtn.setAttribute('aria-pressed', String(on));
    sndBtn.setAttribute('aria-label', tx(on ? 'mute_sound' : 'unmute_sound'));
    sndBtn.title = tx(on ? 'sound_on' : 'sound_off');
  }
  stampUiIcon($('teams-reroll'), 'ui-reroll');
  stampUiIcon($('teams-swap'), 'ui-swap');
  stampUiIcon($('teams-go'), 'ui-themes');
  stampUiIcon($('btn-duel-start'), S && S.mode === 'duel' ? 'ui-duel' : 'ui-play');
  stampUiIcon($('btn-duel-again'), 'ui-duel');
  const ft = $('fact-tag');
  if (ft) {
    // v1.32 fix: the hardcoded RU label in index.html must not stack with the
    // translated span (was rendering «ВАУ-ФАКТ ВАУ-ФАКТ» / «ВАУ-ФАКТ WOW FACT»)
    ft.textContent = '';
    stampUiIcon(ft, 'ui-fact');
    const sp = document.createElement('span');
    sp.textContent = tx('fact_tag');
    ft.appendChild(sp);
  }
  document.querySelectorAll('[data-go="museum"]').forEach((b) => stampUiIcon(b, 'ui-museum'));
  document.querySelectorAll('[data-go="theme"]').forEach((b) => stampUiIcon(b, 'ui-themes'));
  document.querySelectorAll('[data-go="start"]').forEach((b) => stampUiIcon(b, 'ui-play'));
  document.querySelectorAll('[data-go="mood"]').forEach((b) => stampUiIcon(b, 'ui-play'));
  const reward = $('btn-reward');
  if (reward) {
    const complete = DB.figures.length && DB.figures.every((f) => figParts(f.id) >= FIGURE_PARTS);
    reward.disabled = rewardInFlight || !!complete;
    reward.querySelector('span').textContent = tx(rewardInFlight ? 'reward_busy' : complete ? 'reward_all' : 'btn_reward');
  }
  paintResume();
  paintBack();
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', prefs.theme === 'light' ? '#eef1fb' : '#0e1130');
}

function paintDuelResult() {
  if (!S || !S.teams) return;
  const a = { ...S.teams[0], name: teamLabel(S.teams[0]) };
  const b = { ...S.teams[1], name: teamLabel(S.teams[1]) };
  const title = a.score === b.score
    ? tx('duel_draw')
    : tx('duel_win', { n: a.score > b.score ? a.name : b.name });
  if ($('duel-title')) $('duel-title').textContent = title;
  const em = $('duel-em');
  if (em) { clear(em); em.appendChild(iconEl('rank-legend', 'ico lg')); }
  const box = $('duel-score');
  if (box) {
    box.className = 'duel-result';
    box.innerHTML = '';
    const winner = a.score === b.score ? -1 : (a.score > b.score ? 0 : 1);
    [a, b].forEach((t, i) => {
      const row = el('div', { class: 'duel-row' + (i === winner ? ' on' : '') });
      row.appendChild(el('span', { class: 'duel-name', text: t.name }));
      row.appendChild(el('span', { class: 'duel-pts', text: String(t.score) }));
      box.appendChild(row);
    });
  }
}

function paintPart() {
  if (!S || !S.partView || !S.fig) return;
  const { already, newPart, corr, granted } = S.partView;
  const fig = DB.figures.find((f) => f.id === S.fig);
  if (!fig) return;
  const now = figParts(S.fig);
  const complete = now >= FIGURE_PARTS;
  // v1.44: nothing was guessed — the piece is withheld and explained (see Help).
  const none = !already && !granted;
  if (none) {
    $('part-title').textContent = tx('part_none_title');
    $('part-sub-name').textContent = `${fig.emoji[0]} ${figName(fig.id)}`;
    $('part-sub-desc').textContent = tx('fig_progress_fmt', { n: now });
  } else {
    if (already) $('part-title').textContent = tx('part_already');
    else $('part-title').textContent = complete ? tx('part_done') : tx('part_added_fmt', { n: newPart + 1 });
    const partId = already ? FIGURE_PARTS - 1 : newPart;
    const labels = PART_LABEL[lang()];
    $('part-sub-name').textContent = `${fig.emoji[0]} ${figName(fig.id)} — ${labels[fig.parts[partId].id]}`;
    $('part-sub-desc').textContent = lang() === 'en' ? fig.parts[partId].en : fig.parts[partId].ru;
  }
  if (none) {
    drawFig('part-fig', fig, -1, false);
  } else if (complete && !already) {
    // Slow fly-home first; confetti + fanfare land with the last colored piece.
    const host = $('part-fig');
    drawFig('part-fig', fig, newPart, true, () => {
      if (host) celebrateFx(host);
      soundFanfare();
    });
  } else {
    drawFig('part-fig', fig, already ? -1 : newPart, false);
  }
  if (none) $('part-hint').textContent = tx('part_none_hint');
  else if (already) $('part-hint').textContent = tx('part_hint_already');
  else if (complete) $('part-hint').textContent = tx('part_hint_done_fmt', { n: figName(fig.id) });
  else $('part-hint').textContent = tx('part_hint_fmt', { n: FIGURE_PARTS - now });
  $('part-next').textContent = tx('part_next');
  const rk = getRank(corr);
  const pr = $('part-rank');
  pr.style.setProperty('--c1', rk.c1);
  pr.style.setProperty('--c2', rk.c2);
  clear(pr);
  const em = el('div', { class: 'em' });
  em.appendChild(iconEl(RANK_ICON[rk.id] || 'rank-novice', 'ico lg'));
  pr.appendChild(em);
  pr.appendChild(el('div', { class: 'ttl', text: tx('rank_line_fmt', { c: corr }) })).style.fontSize = '19px';
  const you = el('div', { class: 'arch' });
  you.innerHTML = tx('rank_you_fmt', { r: rankName(rk), e: '' });
  pr.appendChild(you);
  pr.appendChild(el('div', { class: 'shadow', text: lang() === 'en' ? rk.de : rk.d })).style.marginTop = '8px';
}

function paintHandoff() {
  const box = $('handoff');
  if (!box || box.hidden || !S || !S.teams) return;
  const prevTeam = S.teams[S.qi % 2] || {};
  const nextTeam = S.teams[(S.qi + 1) % 2] || {};
  if ($('handoff-prev')) $('handoff-prev').textContent = tx('handoff_prev', { n: teamLabel(prevTeam) });
  if ($('handoff-next')) $('handoff-next').textContent = tx('handoff_next', { n: teamLabel(nextTeam) });
  if ($('handoff-go')) $('handoff-go').textContent = tx('handoff_go');
}

function paintQuizLang() {
  if (!S || !S.q || screenId() !== 'quiz') return;
  S.q.forEach(retargetQuestion);
  paintQuestionText();
}

function paintTeamsLang() {
  ['team-a', 'team-b'].forEach((id) => {
    const input = $(id);
    if (!input || !input.dataset.id) return;
    const row = DB.teams.find((x) => x.id === input.dataset.id);
    if (row) input.value = lang() === 'en' ? row.en : row.ru;
  });
  if (S && S.teams) {
    S.teams.forEach((t) => { if (t.id) t.name = teamLabel(t); });
  }
}

function refreshChrome() {
  applyStaticI18n();
  paintStart();
  renderHelp();
  paintTeamsLang();
  if (S) {
    const line = $('mood-theme-name');
    if (line) {
      if (S.random) line.innerHTML = tx('random_mood');
      else line.textContent = moodLine().replace(/<[^>]+>/g, '');
    }
    if ($('start-hint')) $('start-hint').textContent = startHint();
    if ($('theme-sub')) $('theme-sub').textContent = S.mode === 'duel' ? tx('theme_sub_duel') : tx('theme_sub');
    syncStartBtn();
  }
  if (screenId() === 'theme') renderThemes();
  if (screenId() === 'mood') renderDiffMoods();
  if (screenId() === 'fig') renderFigPicker((id) => beginSolo(id));
  if (screenId() === 'museum') renderMuseum();
  paintFigZoom();
  if (screenId() === 'card' && S && S.card) {
    renderCard();
  }
  if (screenId() === 'part') paintPart();
  if (screenId() === 'duel') {
    paintDuelResult();
    if ($('duel-saved')) $('duel-saved').textContent = tx('card_saved');
  }
  if (screenId() === 'card' && $('card-saved')) $('card-saved').textContent = tx('card_saved');
  if (screenId() === 'quiz') paintQuizLang();
  paintHandoff();
  syncDock();
  paintBack();
  // v1.44: paintTeamsLang() may have re-localised team names in S — let the
  // desktop panels (and other state listeners) repaint with the final wording.
  window.dispatchEvent(new Event('factbum:state'));
  if ($('modal') && !$('modal').hidden && /^exit/.test($('modal').dataset.kind)) {
    const saved=$('modal').dataset.kind==='exit-save';
    $('modal-txt').textContent = tx(saved?'checkpoint_exit':'exit_confirm');
    $('modal-ok').textContent = tx(saved?'checkpoint_menu':'exit_yes');
    $('modal-cancel').textContent = tx('exit_no');
  }
}

function renderHelp() {
  const host = $('help-body');
  if (!host) return;
  const blocks = [
    ['help_n_title', 'help_n_txt'],
    ['help_th_title', 'help_th_txt'],
    ['help_mood_title', 'help_mood_txt'],
    ['help_diff_title', 'help_diff_txt'],
    ['help_norep_title', 'help_norep_txt'],
    ['help_rand_title', 'help_rand_txt'],
    ['help_rank_title', 'help_rank_txt'],
    ['help_arch_title', 'help_arch_txt'],
    ['help_fig_title', 'help_fig_txt'],
    ['help_duel_title', 'help_duel_txt'],
    ['help_resume_title', 'help_resume_txt'],
    ['help_acc_title', 'help_acc_txt'],
    ['help_facts_title', 'help_facts_txt'],
    ['help_keys_title', 'help_keys_txt'],
  ];
  clear(host);
  const helpIco = {
    help_n_title: 'ui-play',
    help_th_title: 'ui-themes',
    help_mood_title: 'mood-thoughtful',
    help_diff_title: 'diff-medium',
    help_norep_title: 'ui-cards',
    help_rand_title: 'theme-random',
    help_rank_title: 'rank-legend',
    help_arch_title: 'ui-ach',
    help_fig_title: 'ach-fig',
    help_duel_title: 'ui-duel',
    help_resume_title:'ui-play',
    help_acc_title: 'ui-profile',
    help_facts_title: 'ui-help',
    help_keys_title: 'ui-lang',
  };
  blocks.forEach(([t, b]) => {
    const card = el('div', { class: 'card help-card' });
    const h = el('h2', { class: 'ico-head' });
    h.style.fontSize = '26px';
    if (helpIco[t]) h.appendChild(iconEl(helpIco[t], 'ico ui'));
    h.appendChild(document.createTextNode(tx(t)));
    card.appendChild(h);
    const p = el('p');
    p.style.marginTop = '6px';
    p.innerHTML = tx(b, { n: DB.questionTotal, v: VERSION });
    card.appendChild(p);
    host.appendChild(card);
  });
  $('help-footer').textContent = tx('help_footer', { v: VERSION });
  const ht = $('help-title');
  if (ht) {
    const ic = ht.querySelector('img.ico.ui');
    ht.textContent = tx('help_title');
    if (ic) ht.insertBefore(ic, ht.firstChild);
    else stampUiIcon(ht, 'ui-help');
  }
}

function renderThemes() {
  const g = $('theme-grid');
  clear(g);
  DB.themes.forEach((t) => {
    const st = themeStat(t.id);
    const btn = el('button', { class: 'tcard', type: 'button' });
    btn.appendChild(iconEl(THEME_ICON[t.id] || 'theme-body', 'ico theme'));
    btn.appendChild(el('div', { class: 'nm', text: themeName(t.id) }));
    btn.appendChild(el('div', { class: 'dt', text: tx('theme_card_fmt', { cnt: (DB.byTheme[t.id] || []).length, n: st.quizzes }) }));
    btn.addEventListener('click', () => pickTheme(t.id, false));
    g.appendChild(btn);
  });
  const rnd = el('button', { class: 'tcard', type: 'button' });
  rnd.appendChild(iconEl('theme-random', 'ico theme'));
  rnd.appendChild(el('div', { class: 'nm', text: tx('random_name') }));
  rnd.appendChild(el('div', { class: 'dt', text: tx('random_card_fmt', { n: P.rand || 0 }) }));
  rnd.addEventListener('click', () => pickTheme('random', true));
  g.appendChild(rnd);
}

function pickTheme(id, isRandom) {
  if (isPaused()) return;
  const mode = S && S.mode === 'duel' ? 'duel' : 'solo';
  const teams = S && S.teams ? S.teams : null;
  setSession({
    mode,
    theme: isRandom ? 'random' : id,
    random: !!isRandom,
    diff: null,
    mood: null,
    fig: null,
    q: null,
    qi: 0,
    wrong: 0,
    pts: {},
    teams,
  });
  const line = $('mood-theme-name');
  if (isRandom) line.innerHTML = tx('random_mood');
  else line.textContent = moodLine();
  $('start-hint').textContent = tx('mood_hint');
  renderDiffMoods();
  syncStartBtn();
  go('mood');
}

function renderDiffMoods() {
  const dg = $('diff-grid');
  clear(dg);
  DB.diffs.forEach((df) => {
    const b = el('button', { class: 'mood' + (S && S.diff && S.diff.id === df.id ? ' sel' : ''), type: 'button' });
    b.appendChild(iconEl(DIFF_ICON[df.id] || 'diff-medium', 'ico'));
    const cap = el('div', { text: lang() === 'en' ? df.en : df.ru });
    const sub = el('div', { class: 'mood-sub', text: lang() === 'en' ? df.de : df.dt });
    b.appendChild(cap);
    b.appendChild(sub);
    b.addEventListener('click', () => {
      if (isPaused()) return;
      S.diff = df;
      renderDiffMoods();
      maybeAdvanceFromMood();
    });
    dg.appendChild(b);
  });
  const g = $('mood-grid');
  clear(g);
  DB.moods.forEach((m) => {
    const b = el('button', {
      class: 'mood' + (S && S.mood === m.id ? ' sel' : ''),
      type: 'button',
    });
    b.appendChild(iconEl(MOOD_ICON[m.id] || 'mood-thoughtful', 'ico'));
    b.appendChild(el('div', { text: lang() === 'en' ? m.en : m.ru }));
    b.addEventListener('click', () => {
      if (isPaused()) return;
      S.mood = m.id;
      renderDiffMoods();
      maybeAdvanceFromMood();
    });
    g.appendChild(b);
  });
}

function startBtnLabel() {
  return S && S.mode === 'duel' ? tx('btn_start_duel') : tx('btn_start');
}

function syncStartBtn() {
  const btn = $('btn-duel-start');
  if (!btn) return;
  btn.hidden = false;
  btn.removeAttribute('hidden');
  const ready = !!(S && S.diff && S.mood);
  btn.disabled = !ready;
  btn.setAttribute('aria-disabled', ready ? 'false' : 'true');
  btn.classList.toggle('is-off', !ready);
  const label = startBtnLabel();
  const span = btn.querySelector('span');
  if (span) span.textContent = label;
  stampUiIcon(btn, S && S.mode === 'duel' ? 'ui-duel' : 'ui-play');
  if ($('start-hint')) $('start-hint').textContent = startHint();
}

function maybeAdvanceFromMood() {
  syncStartBtn();
  // v1.44: desktop panels reflect the picked difficulty/mood immediately.
  window.dispatchEvent(new Event('factbum:state'));
}

function onStartFromMood() {
  if (!S || !S.diff || !S.mood || isPaused()) return;
  if (S.mode === 'duel') beginDuel();
  else {
    renderFigPicker((id) => beginSolo(id));
    go('fig');
  }
}

function dealQuestions(count) {
  const raw = pickQuestions({
    random: S.random,
    theme: S.theme,
    diff: S.diff,
    mood: S.mood,
    count,
  });
  return raw.map(q=>prepareQuestion(q));
}

function logVisitPick() {
  try {
    const raw = sessionStorage.getItem('factbum_visit');
    const arr = raw ? JSON.parse(raw) : [];
    arr.push({ m: S.mode, t: S.random ? 'random' : S.theme, d: S.diff, mo: S.mood });
    sessionStorage.setItem('factbum_visit', JSON.stringify(arr.slice(-60)));
  } catch { /* private mode */ }
}

let checkpointClock=0;
let suppressCheckpoint=false;
let roundStarting=false;
let resumingRound=false;
let choosingNewRound=false;

function saveRoundCheckpoint(){
  if(suppressCheckpoint||!S?.running||!ownsRun(prefs.uid,S.runId))return false;
  const c=packCheckpoint(prefs.uid,S,timerSnapshot(),!!S.handoffOpen);
  if(!c)return false;
  const saved=storeCheckpoint(c);
  if(!saved)window.dispatchEvent(new Event('factbum:storage-warning'));
  return saved;
}
function stopCheckpointClock(){clearInterval(checkpointClock);checkpointClock=0;}
function startCheckpointClock(){stopCheckpointClock();checkpointClock=setInterval(()=>{if(S?.running&&!S.done&&!isPaused())saveRoundCheckpoint();},2000);}
function acknowledgeRounds(){
  for(const op of retainedRunOperations(prefs.uid))if(isOperationDurable(op))markCompleted(prefs.uid,op.slice('finish-'.length));
}
function resumeCandidate(){
  acknowledgeRounds();
  const c=findCheckpoint(prefs.uid);
  if(c&&isOperationDurable(completionId(c.runId))){markCompleted(prefs.uid,c.runId);return null;}
  return c;
}
function paintResume(){
  const box=$('resume-box');if(!box)return;
  const c=resumeCandidate(),show=!!c;
  box.hidden=!show;$('start-intro').hidden=show;
  $('btn-play').querySelector('span').textContent=tx(show?'checkpoint_new':'btn_play');
  if(!c)return;
  const pending=hasSavedOperation(completionId(c.runId));
  const decoded=decodeCheckpoint(c,prefs.uid,DB,prepareQuestion);
  $('resume-context').textContent=pending?tx('checkpoint_pending_short'):!decoded.ok?tx(decoded.reason==='content'?'checkpoint_changed_short':'checkpoint_invalid_short'):tx('checkpoint_context',{mode:tx(c.mode==='duel'?'btn_duel':'checkpoint_solo'),theme:themeName(c.theme),n:c.index+1,total:c.questions.length});
  $('btn-resume').textContent=tx(pending?'checkpoint_retry':decoded.ok?'checkpoint_continue':'checkpoint_new');
}
async function allowNewRound(){
  const c=resumeCandidate();if(!c)return true;
  if(hasSavedOperation(completionId(c.runId))){toast(tx('checkpoint_pending'));return false;}
  // Never discard a run that is active in another tab.
  if(!await acquireRun(prefs.uid,c.runId))return true;
  try{
    const ok=await showModal({kind:'leave-round',text:tx('checkpoint_discard'),ok:tx('checkpoint_new'),cancel:tx('checkpoint_cancel')});
    if(ok)discardCheckpoint(prefs.uid,c.runId);
    return ok;
  }finally{releaseRun();paintResume();}
}
async function resumeRound(){
  if(resumingRound||roundStarting||choosingNewRound||S?.running||screenId()!=='start'||isPaused())return;
  resumingRound=true;
  try{
    const c=resumeCandidate();if(!c){paintResume();return;}
    const op=completionId(c.runId);
    if(hasSavedOperation(op)){
      await save(true);
      if(isOperationDurable(op)){markCompleted(prefs.uid,c.runId);toast(tx('checkpoint_saved'));}
      else {syncNow().catch(()=>{});toast(tx('save_warning'));}
      paintResume();return;
    }
    const decoded=decodeCheckpoint(c,prefs.uid,DB,prepareQuestion);
    if(!decoded.ok){
      const ok=await showModal({kind:'leave-round',text:tx(decoded.reason==='content'?'checkpoint_changed':'checkpoint_invalid'),ok:tx('checkpoint_new'),cancel:tx('checkpoint_cancel')});
      if(ok){if(await acquireRun(prefs.uid,c.runId)){discardCheckpoint(prefs.uid,c.runId);releaseRun();}setSession({mode:'solo'});renderThemes();$('theme-sub').textContent=tx('theme_sub');go('theme');}
      return;
    }
    if(!await acquireRun(prefs.uid,c.runId)){
      await showModal({kind:'round-busy',text:tx('checkpoint_busy'),ok:tx('checkpoint_ok')});return;
    }
    // A different tab may have completed the round just before the lease changed.
    if(completedLocally(prefs.uid,c.runId)||hasSavedOperation(op)){
      await save(true);if(isOperationDurable(op))markCompleted(prefs.uid,c.runId);releaseRun();paintResume();return;
    }
    suppressCheckpoint=true;
    try{
      setSession(decoded.session);hideHandoff();
      restoreQuestionState(decoded);
      go('quiz');
      if(decoded.view==='handoff')showHandoff();else gameplayStart();
    }finally{suppressCheckpoint=false;}
    startCheckpointClock();saveRoundCheckpoint();
  }finally{resumingRound=false;}
}
async function beginRound(figId=null){
  if(!S||S.running||roundStarting||!S.diff||!S.mood||isPaused())return;
  const session=S,screen=screenId();roundStarting=true;
  const id=createRunId();requestFullscreen();
  try{
    if(!await acquireRun(prefs.uid,id,{fresh:true})){toast(tx('checkpoint_busy'));return;}
    if(S!==session||screenId()!==screen||isPaused()){releaseRun();return;}
    S.runId=id;S.startedAt=Date.now();S.running=true;S.finishing=false;
    if(S.mode==='solo')S.fig=figId;
    hideHandoff();S.q=dealQuestions(S.mode==='duel'?QUESTIONS_PER_RUN*2:QUESTIONS_PER_RUN);
    S.qi=0;S.wrong=0;S.pts={};S.done=false;S.answers=Array(S.q.length).fill(-1);
    if(S.mode==='duel')S.teams.forEach(t=>t.score=0);
    logVisitPick();gameplayStart();renderQuestion();go('quiz');startCheckpointClock();saveRoundCheckpoint();
  }finally{roundStarting=false;}
}
function beginSolo(figId){return beginRound(figId);}
function beginDuel(){if(S?.mode==='duel')return beginRound();}

async function alreadyFinished(session){
  const op=completionId(session.runId);
  if(!completedLocally(prefs.uid,session.runId)&&!hasSavedOperation(op))return false;
  await save(true);if(isOperationDurable(op))markCompleted(prefs.uid,session.runId);
  stopTimer();gameplayStop();stopCheckpointClock();releaseRun();setSession(null);visit('start');toast(tx('checkpoint_saved'));return true;
}
async function finishSolo(){
  if(!S?.running||S.finishing)return;
  const session=S;session.finishing=true;
  stopTimer();gameplayStop();stopCheckpointClock();
  try{
    if(await alreadyFinished(session))return;
    markSessionUsed();
    // v1.44: a puzzle piece is granted only when at least one answer was correct.
    const corr=QUESTIONS_PER_RUN-S.wrong;
    const before=figParts(S.fig),already=before>=FIGURE_PARTS;let newPart=-1,granted=false;
    if(!already&&corr>0){granted=true;newPart=before;P.figs[S.fig]=before+1;}
    recordThemeShares();P.sessions++;P.answered+=S.q.length;
    if(!P.best||corr>P.best.correct)P.best={correct:corr,theme:S.random?'random':S.theme};
    for(const a in S.pts)P.arch[a]=(P.arch[a]||0)+S.pts[a];
    refreshAchievements();S.running=false;S.partView={already,newPart,corr,granted};S.card=calcCard();
    archiveResultCard({defer:true});
    // The part, counters, achievements and archive entry are one durable operation.
    await save(true,{operationId:completionId(S.runId),includeCards:true});
    if(isOperationDurable(completionId(S.runId))){markCompleted(prefs.uid,S.runId);releaseRun();}
    else toast(tx('save_warning'));
    if(S!==session)return;
    paintPart();soundJingle('solo');go('part');queueInterstitial();
  }catch(error){console.error(error);toast(tx('save_warning'));}
  finally{session.finishing=false;}
}
async function finishDuel(){
  if(!S?.running||S.finishing)return;
  const session=S;session.finishing=true;
  stopTimer();gameplayStop();stopCheckpointClock();
  try{
    if(await alreadyFinished(session))return;
    hideHandoff();markSessionUsed();recordThemeShares();P.duels++;P.answered+=S.q.length;
    if(S.teams[0].score===S.teams[1].score)P.duelDraws++;
    refreshAchievements();S.running=false;archiveResultCard({defer:true});
    await save(true,{operationId:completionId(S.runId),includeCards:true});
    if(isOperationDurable(completionId(S.runId))){markCompleted(prefs.uid,S.runId);releaseRun();}
    else toast(tx('save_warning'));
    if(S!==session)return;
    paintDuelResult();if($('duel-saved'))$('duel-saved').textContent=tx('card_saved');
    soundJingle('duel');go('duel');queueInterstitial();
  }catch(error){console.error(error);toast(tx('save_warning'));}
  finally{session.finishing=false;}
}

function hideHandoff() {
  if(S)S.handoffOpen=false;
  const n = $('handoff');
  if (n) n.hidden = true;
}

function showHandoff() {
  const box = $('handoff');
  if (!box || !S || !S.teams) {
    continueAfterHandoff();
    return;
  }
  const prevTeam = S.teams[S.qi % 2] || {};
  const nextTeam = S.teams[(S.qi + 1) % 2] || {};
  const prev = $('handoff-prev');
  const next = $('handoff-next');
  const goBtn = $('handoff-go');
  if (prev) prev.textContent = tx('handoff_prev', { n: teamLabel(prevTeam) });
  if (next) next.textContent = tx('handoff_next', { n: teamLabel(nextTeam) });
  if (goBtn) goBtn.textContent = tx('handoff_go');
  box.hidden = false;
  box.removeAttribute('hidden');
  S.handoffOpen=true;window.dispatchEvent(new Event('factbum:state'));
  gameplayStop();
  goBtn.focus({ preventScroll: true });
}

function continueAfterHandoff() {
  if (!S || !S.running || !S.done || $('handoff').hidden || isPaused()) return;
  hideHandoff();
  gameplayStart();
  S.done = false;
  S.qi += 1;
  if (S.qi >= totalInRun()) {
    finishDuel();
    return;
  }
  renderQuestion();
}

function nextQuestion() {
  if (!S || !S.running || !S.done || isPaused()) return;
  if (S.qi >= totalInRun() - 1) {
    hideHandoff();
    if (S.mode === 'duel') finishDuel();
    else finishSolo();
    return;
  }
  if (S.mode === 'duel') {
    showHandoff();
    return;
  }
  S.done = false;
  S.qi += 1;
  renderQuestion();
}

async function exitQuiz(opts = {}) {
  if (!S || !S.running || S.finishing || exitPending) return false;
  exitPending = true;
  gameplayStop();
  try {
    const saved=saveRoundCheckpoint();
    const ok = await confirmExit(saved);
    if (!ok) { if ($('handoff').hidden) gameplayStart(); return false; }
    saveRoundCheckpoint();stopCheckpointClock();releaseRun();
    stopTimer(); gameplayStop(); hideHandoff(); setSession(null);
    go('start', opts); paintStart();
    return true;
  } finally { exitPending = false; }
}

function typingInField() {
  const el = document.activeElement;
  if (!el) return false;
  const tag = (el.tagName || '').toLowerCase();
  return tag === 'input' || tag === 'textarea' || el.isContentEditable;
}

/* ------------------------- Yandex monetization hooks ---------------------- */

// Queue an interstitial to show once the player returns to the menu after a run.
let interstitialQueued = false;

function queueInterstitial() {
  interstitialQueued = true;
}

async function maybeInterstitial() {
  if (!interstitialQueued) return;
  interstitialQueued = false;
  try { await showFullscreen(); } catch { /* ignore */ }
}

async function rewardWatch() {
  if (rewardInFlight || isPaused()) return;
  const incomplete = DB.figures.map((f) => f.id).filter((id) => figParts(id) < FIGURE_PARTS);
  if (!incomplete.length) { toast(tx('reward_all')); paintStart(); return; }
  rewardInFlight = true; paintStart();
  try {
    const got = await showRewarded();
    if (!got) { toast(tx('reward_none')); return; }
    const id = incomplete[Math.floor(Math.random() * incomplete.length)];
    P.figs[id] = Math.min(FIGURE_PARTS, (P.figs[id] || 0) + 1);
    refreshAchievements();
    await save(true);
    toast(tx('reward_got', { n: figName(id) }));
  } finally { rewardInFlight = false; paintStart(); }
}

/* --------------------------- end monetization ------------------------------ */

function bindKeys() {
  document.addEventListener('keydown', (e) => {
    if (e.defaultPrevented || e.repeat || e.ctrlKey || e.metaKey || e.altKey || typingInField()) return;
    const modal = $('modal');
    if (modal && !modal.hidden) return;
    const zoom = $('fig-zoom');
    const handoff = $('handoff');

    if (e.key === 'Escape') {
      if (zoom && !zoom.hidden) {
        e.preventDefault();
        closeFigZoom();
        return;
      }
      if (screenId() !== 'start') {
        e.preventDefault();
        navigateBack();
      }
      return;
    }

    if (zoom && !zoom.hidden) return;
    if ((e.key === 'Enter' || e.key === ' ') && document.activeElement?.closest('#chrome')) return;
    if (handoff && !handoff.hidden) {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        continueAfterHandoff();
      }
      return;
    }

    if (screenId() !== 'quiz' || !S) return;
    if (!S.done) {
      const digit = /^(?:Digit|Numpad)([1-5])$/.exec(e.code);
      const n = digit ? Number(digit[1]) : 0;
      if (n >= 1 && n <= 5) {
        e.preventDefault();
        if (applyAnswer(n - 1)) soundClick();
      }
      return;
    }
    if (e.key === 'Enter') {
      if (document.activeElement?.id === 'quiz-review') return;
      e.preventDefault();
      nextQuestion();
    }
  });
}

function twoNames() {
  const pool = shuffleLocal(DB.teams);
  return [pool[0], pool[1]];
}

function shuffleLocal(a) {
  const arr = a.slice();
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function fillTeamInputs(a, b) {
  $('team-a').value = lang() === 'en' ? a.en : a.ru;
  $('team-b').value = lang() === 'en' ? b.en : b.ru;
  $('team-a').dataset.id = a.id;
  $('team-b').dataset.id = b.id;
}

async function openDuelNames() {
  if(isPaused()||S?.running||S?.finishing||choosingNewRound||roundStarting||resumingRound)return;
  choosingNewRound=true;let allowed;try{allowed=await allowNewRound();}finally{choosingNewRound=false;}
  if(!allowed||isPaused())return;
  const [a, b] = twoNames();
  fillTeamInputs(a, b);
  setSession({ mode: 'duel', teams: [{ name: '', score: 0 }, { name: '', score: 0 }] });
  go('teams');
}

function commitTeams() {
  if (isPaused()) return;
  const na = $('team-a').value.trim() || (lang() === 'en' ? 'Team A' : 'Команда А');
  const nb = $('team-b').value.trim() || (lang() === 'en' ? 'Team B' : 'Команда Б');
  setSession({
    mode: 'duel',
    teams: [
      { id: $('team-a').dataset.id || '', name: na, score: 0, ...(!$('team-a').value.trim() ? { defaultTeam: 'a' } : {}) },
      { id: $('team-b').dataset.id || '', name: nb, score: 0, ...(!$('team-b').value.trim() ? { defaultTeam: 'b' } : {}) },
    ],
  });
  $('theme-sub').textContent = tx('theme_sub_duel');
  renderThemes();
  go('theme');
}

async function openSolo() {
  if(isPaused()||S?.running||S?.finishing||choosingNewRound||roundStarting||resumingRound)return;
  choosingNewRound=true;let allowed;try{allowed=await allowNewRound();}finally{choosingNewRound=false;}
  if(!allowed||isPaused())return;
  setSession({ mode: 'solo' });
  $('theme-sub').textContent = tx('theme_sub');
  renderThemes();
  go('theme');
}

function onHardwareBack() {
  navigateBack({ push: false, replace: true }).then((left) => {
    if (left === false) {
      try {
        const url = new URL(location.href); url.hash = screenId();
        history.pushState({ screen: screenId() }, '', url);
      } catch { /* sandboxed embedding */ }
    }
  });
}

function bindUi() {
  // Soft UI click on every button press (capture phase, before handlers).
  document.addEventListener('click', (e) => {
    try {
      if (e.target && e.target.closest && e.target.closest('button')) soundClick();
    } catch { /* ignore */ }
  }, true);
  bindModal();
  bindFigZoom();
  bindMuseumTabs();
  bindHistory(onHardwareBack);
  bindKeys();
  window.addEventListener('factbum:screen', paintBack);
  window.addEventListener('factbum:sync',()=>{if($('player-line'))$('player-line').textContent=playerLabel();acknowledgeRounds();if(screenId()==='start')paintResume();});
  window.addEventListener('factbum:sdk-available',()=>{if(!LANG_PRECHOSEN&&!languageTouched){setLang(yaPlatformLang);refreshChrome();}});
  window.addEventListener('factbum:account-changing',()=>{saveRoundCheckpoint();save(true);});
  window.addEventListener('factbum:account-changed',async()=>{saveRoundCheckpoint();await save(true);location.reload();});
  window.addEventListener('factbum:overlay', paintBack);
  $('btn-back').addEventListener('click', () => navigateBack());
  let warnedStorage = false;
  window.addEventListener('factbum:storage-warning', () => { if (!warnedStorage) { warnedStorage = true; toast(tx('save_warning')); } });

  $('btn-resume').addEventListener('click',resumeRound);
  window.addEventListener('factbum:state',()=>{saveRoundCheckpoint();if(screenId()==='start')paintResume();});
  window.addEventListener('blur',saveRoundCheckpoint);
  document.addEventListener('visibilitychange',saveRoundCheckpoint);
  window.addEventListener('storage',e=>{if(checkpointReferences(prefs.uid,e.key)&&screenId()==='start')paintResume();});
  window.addEventListener('pageshow',e=>{if(e.persisted){stopTimer();stopCheckpointClock();releaseRun();gameplayStop();setSession(null);go('start',{push:false,replace:true});paintStart();}});
  $('btn-play').addEventListener('click', openSolo);
  $('btn-duel').addEventListener('click', openDuelNames);
  $('btn-duel-again').addEventListener('click', openDuelNames);
  $('btn-museum').addEventListener('click', () => visit('museum'));
  $('btn-help').addEventListener('click', () => visit('help'));
  $('btn-lang').addEventListener('click', () => { languageTouched=true; setLang(lang() === 'ru' ? 'en' : 'ru'); refreshChrome(); });
  $('btn-theme').addEventListener('click', () => {
    setColorTheme(prefs.theme === 'dark' ? 'light' : 'dark');
    refreshChrome();
  });
  const sndToggle = $('btn-sound');
  if (sndToggle) {
    sndToggle.addEventListener('click', () => {
      const next = setSound(!isSoundOn());
      if (next) soundClick(); // audible confirmation when unmuting
      paintStart();
    });
  }

  document.querySelectorAll('[data-go]').forEach((btn) => {
    btn.addEventListener('click', () => visit(btn.getAttribute('data-go')));
  });

  const rewardBtn = $('btn-reward');
  if (rewardBtn) {
    rewardBtn.addEventListener('click', rewardWatch);
    stampUiIcon(rewardBtn, 'ui-reward');
  }

  $('quiz-next').addEventListener('click', nextQuestion);
  $('quiz-review').addEventListener('click', () => { if (!isPaused()) showAnswerView(!S.showingFact); });
  $('part-next').addEventListener('click', () => { renderCard(); if ($('card-saved')) $('card-saved').textContent = tx('card_saved'); go('card'); });
  $('btn-duel-start').addEventListener('click', onStartFromMood);
  const handoffGo = $('handoff-go');
  if (handoffGo) {
    handoffGo.addEventListener('click', (e) => {
      e.preventDefault();
      continueAfterHandoff();
    });
  }

  $('teams-reroll').addEventListener('click', () => {
    const [a, b] = twoNames();
    fillTeamInputs(a, b);
  });
  $('teams-swap').addEventListener('click', () => {
    const a = $('team-a').value;
    const aid = $('team-a').dataset.id;
    $('team-a').value = $('team-b').value;
    $('team-a').dataset.id = $('team-b').dataset.id || '';
    $('team-b').value = a;
    $('team-b').dataset.id = aid || '';
  });
  $('teams-go').addEventListener('click', commitTeams);
  ['team-a', 'team-b'].forEach((id) => {
    $(id).addEventListener('input', () => { delete $(id).dataset.id; });
  });


}

async function boot() {
  try {
    setColorTheme(prefs.theme || 'dark');
    const msg = $('boot-msg');
    if (msg) msg.textContent = tx('loading');

    // Platform chrome (fullscreen, no context menu, no swipe-to-refresh).
    applyYandexChrome();

    // Fetch static content while the SDK initializes; handle rejection explicitly.
    const contentReady=loadAll().then(data=>({data}),error=>({error}));
    // Init Yandex SDK (guest-safe, never throws).
    const ya = await initYandex();
    const pid = yandexPlayerID();
    const authorized = isAuthorized();
    if (pid) {
      prefs.uid = 'ya-' + pid;
      prefs.user = {
        id: String(pid),
        name: authorized ? yandexPlayerName() : '',
        authorized,
      };
    } else if (!prefs.uid) {
      prefs.uid = 'ya-' + Math.random().toString(36).slice(2, 10);
      prefs.user = { id: prefs.uid, name: '', authorized: false };
    }
    savePrefs();

    // Auto-detect interface language from the SDK (requirement 2.14).
    // Only override when the player hasn't explicitly chosen a language.
    // LANG_PRECHOSEN is captured at module load, BEFORE any savePrefs() writes
    // the default language into localStorage (fix for v1.31).
    try {
      if (!LANG_PRECHOSEN) {
        const envLang = (ya && ya.lang) || 'ru';
        setLang(envLang === 'ru' ? 'ru' : 'en');
      }
    } catch { /* ignore */ }

    const content=await contentReady;if(content.error)throw content.error;
    if(!LANG_PRECHOSEN&&!languageTouched)setLang(yaPlatformLang);
    await hydrateProgress();
    initLayout();
    bindUi();
    migrateSavedCards();
    const logo = $('brand-logo');
    if (logo) {
      logo.hidden = false;
      logo.addEventListener('error', () => { logo.hidden = true; });
    }
    refreshChrome();
    $('scr-boot').classList.remove('on');
    go('start', { push: false });
    paintStart();
    // Tell Yandex the game has finished loading (mandatory for moderation).
    try { gameReady(); } catch { /* ignore */ }
    window.addEventListener('pagehide', () => {try{saveRoundCheckpoint();save(true);}catch{}stopTimer();stopCheckpointClock();gameplayStop();releaseRun();});
  } catch (err) {
    console.error(err);
    $('boot-msg').textContent = tx('load_err');
    if(!$('boot-retry')){const b=el('button',{id:'boot-retry',class:'btn',text:tx('retry_loading'),type:'button'});b.addEventListener('click',()=>location.reload());$('boot-msg').after(b);}
  }
}

function loadPrefsSafe() {
  try {
    const l = localStorage.getItem('factbum_lang');
    if (l === 'en' || l === 'ru') prefs.lang = l;
    const t = localStorage.getItem('factbum_theme');
    if (t === 'light' || t === 'dark') prefs.theme = t;
    // v1.32: restore the guest uid BEFORE boot() mints a fresh one, otherwise
    // guest/local progress would not survive a restart (Yandex builds get a
    // stable uid from the player id instead).
    const snd = localStorage.getItem('factbum_sound');
    if (snd === 'on' || snd === 'off') prefs.sound = snd;
    const u = localStorage.getItem('factbum_uid');
    if (u) {prefs.uid = u;prefs.previousUid=u;}
  } catch { /* */ }
}

// v1.31 fix (§2.14): capture an explicit language choice BEFORE any code path
// writes the default language to localStorage (setColorTheme/savePrefs below).
const LANG_PRECHOSEN = (() => {
  try {
    const v = localStorage.getItem('factbum_lang');
    return (v === 'en' || v === 'ru') ? v : null;
  } catch { return null; }
})();

loadPrefsSafe();
setColorTheme(prefs.theme);
boot();
initPanels();
