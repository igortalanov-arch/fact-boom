import { FIGURE_PARTS, getRank } from './config.js?v=1.44';
import { DB } from './data.js?v=1.44';
import { P, Cards, themeStat, unlockAch, figParts, removeSavedCard, resetFigure } from './state.js?v=1.44';
import { tx, themeName, figName, rankName } from './i18n.js?v=1.44';
import { $, clear, el, showModal } from './ui.js?v=1.44';
import { iconEl, iconSrc, RANK_ICON, ACH_ICON, THEME_ICON } from './icons.js?v=1.44';
import { resolveCardImg, cardTitle, cardSub, cardMeta, cardData } from './share.js?v=1.44';
import { figSvgEl } from './silhouettes.js?v=1.44';

const ACH = [
  { id: 'part', label: 'ach1', test: () => Object.values(P.figs).reduce((a, b) => a + b, 0) >= 1 },
  { id: 'fig', label: 'ach2', test: () => Object.values(P.figs).filter((v) => v >= FIGURE_PARTS).length >= 1 },
  { id: 'col3', label: 'ach3', test: () => Object.values(P.figs).filter((v) => v >= FIGURE_PARTS).length >= 3 },
  { id: 'q100', label: 'ach4', test: () => P.answered >= 100 },
  { id: 'travel', label: 'ach5', test: () => DB.themes.filter((t) => themeStat(t.id).questions > 0).length >= 5 },
  { id: 'legend', label: 'ach6', test: () => !!(P.best && P.best.correct >= 9) },
];

let zoomId = null;
let zoomCard = null;
let museumTab = 'figs';
let zoomFocus = null;
function focusZoom() {
  zoomFocus = document.activeElement;
  const scroll = $('fig-zoom').querySelector('.dialog-scroll');
  if (scroll) scroll.scrollTop = 0;
  $('fig-zoom-close').focus({ preventScroll: true });
  window.dispatchEvent(new Event('factbum:overlay'));
}

export function setMuseumTab(tab) {
  museumTab = tab === 'cards' ? 'cards' : 'figs';
}

export function refreshAchievements() {
  ACH.forEach((a) => { if (a.test()) unlockAch(a.id); });
}

export function openFigZoom(id) {
  zoomId = id;
  paintFigZoom();
  focusZoom();
}

export function closeFigZoom() {
  zoomId = null;
  zoomCard = null;
  const box = $('fig-zoom');
  if (box) box.hidden = true;
  if (zoomFocus && zoomFocus.isConnected) { try { zoomFocus.focus({ preventScroll: true }); } catch { /* ignore */ } }
  zoomFocus = null;
  window.dispatchEvent(new Event('factbum:overlay'));
}

export function openCardZoom(card) {
  zoomId = null;
  zoomCard = card;
  paintFigZoom();
  focusZoom();
}

export function paintFigZoom() {
  const box = $('fig-zoom');
  if (!box) return;
  if (zoomCard) {
    const d = cardData(zoomCard);
    const zimg = resolveCardImg(zoomCard, true);
    const ztitle = cardTitle(d);
    const zsub = cardSub(d);
    const [zm1, zm2] = cardMeta(d);
    const stage = $('fig-zoom-fig');
    if (stage) {
      clear(stage);
      if (zimg) {
        const img = el('img', { class: 'card-zoom-img', alt: '', src: zimg });
        stage.appendChild(img);
      }
    }
    if ($('fig-zoom-name')) $('fig-zoom-name').textContent = ztitle;
    if ($('fig-zoom-meta')) {
      const bits = [zsub, zm1, zm2].filter(Boolean);
      $('fig-zoom-meta').textContent = bits.join('\n');
    }
    if ($('fig-zoom-close')) $('fig-zoom-close').textContent = tx('museum_zoom_close');
    paintZoomDelete(true);
    box.hidden = false;
    box.removeAttribute('hidden');
    return;
  }
  if (!zoomId) return;
  const fig = DB.figures.find((f) => f.id === zoomId);
  if (!fig) return;
  const n = figParts(fig.id);
  const stage = $('fig-zoom-fig');
  if (stage) {
    clear(stage);
    stage.appendChild(figSvgEl(fig.id, n, { size: 'xl' }));
  }
  if ($('fig-zoom-name')) $('fig-zoom-name').textContent = figName(fig.id);
  if ($('fig-zoom-meta')) {
    $('fig-zoom-meta').textContent = n >= FIGURE_PARTS
      ? `${n}/6 · ${tx('museum_done')}`
      : `${n}/6 · ${tx('museum_wip')}`;
  }
  if ($('fig-zoom-close')) $('fig-zoom-close').textContent = tx('museum_zoom_close');
  paintZoomDelete(false);
  box.hidden = false;
  box.removeAttribute('hidden');
}

function paintZoomDelete(isCard) {
  const btn = $('fig-zoom-del');
  if (!btn) return;
  if (isCard) {
    btn.hidden = false;
    btn.textContent = tx('museum_del_card');
  } else if (zoomId && figParts(zoomId) > 0) {
    btn.hidden = false;
    btn.textContent = tx('museum_del_fig');
  } else {
    btn.hidden = true;
  }
}

async function confirmDeleteFig(id) {
  if (!id || !figParts(id)) return;
  const ok = await showModal({
    kind: 'del-fig',
    text: tx('museum_del_fig_confirm', { n: figName(id) }),
    ok: tx('museum_del'),
    cancel: tx('cancel'),
  });
  if (!ok) return;
  resetFigure(id);
  closeFigZoom();
  renderMuseum();
}

async function confirmDeleteCard(card) {
  if (!card || !card.id) return;
  const ok = await showModal({
    kind: 'del-card',
    text: tx('museum_del_card_confirm'),
    ok: tx('museum_del'),
    cancel: tx('cancel'),
  });
  if (!ok) return;
  removeSavedCard(card.id);
  closeFigZoom();
  renderMuseum();
}

export function bindFigZoom() {
  const box = $('fig-zoom');
  if (!box) return;
  box.addEventListener('click', (e) => {
    if (e.target === box) closeFigZoom();
  });
  box.addEventListener('keydown', (e) => {
    if (e.key !== 'Tab' || box.hidden) return;
    const buttons = [...box.querySelectorAll('button')].filter((b) => !b.hidden && !b.disabled);
    const first = buttons[0], last = buttons[buttons.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  });
  const btn = $('fig-zoom-close');
  if (btn) btn.addEventListener('click', (e) => { e.preventDefault(); closeFigZoom(); });
  const del = $('fig-zoom-del');
  if (del) {
    del.addEventListener('click', (e) => {
      e.preventDefault();
      if (zoomCard) confirmDeleteCard(zoomCard);
      else if (zoomId) confirmDeleteFig(zoomId);
    });
  }
  if (!bindFigZoom._esc) {
    bindFigZoom._esc = true;
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && !e.defaultPrevented && $('modal').hidden && (zoomId || zoomCard)) {
        e.preventDefault(); e.stopImmediatePropagation(); closeFigZoom();
      }
    });
  }
}

function paintTabs() {
  const figs = $('tab-figs');
  const cards = $('tab-cards');
  if (figs) {
    figs.textContent = tx('museum_tab_figs');
    figs.classList.toggle('on', museumTab === 'figs');
    let ic = figs.querySelector('img.ico.ui');
    if (!ic) { ic = iconEl('ui-museum', 'ico ui'); figs.insertBefore(ic, figs.firstChild); }
    else ic.src = iconSrc('ui-museum');
  }
  if (cards) {
    cards.textContent = tx('museum_tab_cards');
    cards.classList.toggle('on', museumTab === 'cards');
    let ic = cards.querySelector('img.ico.ui');
    if (!ic) { ic = iconEl('ui-cards', 'ico ui'); cards.insertBefore(ic, cards.firstChild); }
    else ic.src = iconSrc('ui-cards');
  }
  const pf = $('m-panel-figs');
  const pc = $('m-panel-cards');
  if (pf) pf.hidden = museumTab !== 'figs';
  if (pc) pc.hidden = museumTab !== 'cards';
  if ($('museum-title')) $('museum-title').textContent = museumTab === 'cards'
    ? tx('museum_cards_title')
    : tx('museum_title');
  if ($('museum-sub')) $('museum-sub').textContent = museumTab === 'cards'
    ? tx('museum_cards_sub')
    : tx('museum_sub');
}

function renderCardArchive() {
  const box = $('m-cards');
  if (!box) return;
  clear(box);
  if (!Cards.length) {
    box.appendChild(el('p', { class: 'sub', text: tx('museum_cards_empty') }));
    return;
  }
  Cards.forEach((c) => {
    const wrap = el('div', { class: 'mcard' });
    if (c.cols && c.cols.length === 3) {
      wrap.style.background = `linear-gradient(175deg, ${c.cols[0]}59, ${c.cols[2]}59), var(--card)`;
    }
    const btn = el('button', { class: 'mcard-open', type: 'button' });
    const cimg = resolveCardImg(c);
    if (cimg) btn.appendChild(el('img', { alt: '', src: cimg }));
    const d = cardData(c);
    const ctitle = cardTitle(d);
    const csub = cardSub(d);
    const [cm1, cm2] = cardMeta(d);
    btn.setAttribute('aria-label', ctitle);
    btn.appendChild(el('div', { class: 'nm', text: ctitle }));
    if (csub) btn.appendChild(el('div', { class: 'tm', text: csub }));
    if (cm1) btn.appendChild(el('div', { class: 'tm', text: cm1 }));
    if (cm2) btn.appendChild(el('div', { class: 'tm', text: cm2 }));
    if (!cm1 && !cm2 && !csub && c.theme) {
      btn.appendChild(el('div', { class: 'tm', text: tx('share_meta_l1', { t: themeName(c.theme) }) }));
    }
    btn.addEventListener('click', () => openCardZoom(c));
    wrap.appendChild(btn);
    const del = el('button', { class: 'm-del', type: 'button', text: tx('museum_del') });
    del.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      confirmDeleteCard(c);
    });
    wrap.appendChild(del);
    box.appendChild(wrap);
  });
}

export function bindMuseumTabs() {
  ['tab-figs', 'tab-cards'].forEach((id) => {
    const b = $(id);
    if (!b) return;
    b.addEventListener('click', () => {
      setMuseumTab(id === 'tab-cards' ? 'cards' : 'figs');
      renderMuseum();
    });
  });
}

export function renderMuseum() {
  refreshAchievements();
  paintTabs();
  renderCardArchive();
  const box = $('m-figs');
  clear(box);
  DB.figures.forEach((f) => {
    const n = figParts(f.id);
    const row = el('button', { class: 'mfig', type: 'button' });
    row.appendChild(figSvgEl(f.id, n, { size: 'md' }));
    const mid = el('div', { class: 'mfig-mid' });
    mid.appendChild(el('div', { class: 'nm', text: figName(f.id) }));
    mid.appendChild(el('div', { class: 'tm', text: n === FIGURE_PARTS ? tx('museum_done') : tx('museum_wip') }));
    mid.appendChild(el('div', { class: 'tm', text: tx('museum_zoom_hint') }));
    row.appendChild(mid);
    row.appendChild(el('div', { class: 'pct', text: `${n}/6` }));
    row.addEventListener('click', () => openFigZoom(f.id));
    box.appendChild(row);
  });

  const totQ = DB.themes.reduce((s, t) => s + themeStat(t.id).questions, 0);
  const pr = $('m-prog');
  clear(pr);
  pr.appendChild(el('p', { class: 'sub', text: tx('museum_profile_sub') }));
  pr.appendChild(el('p', { class: 'sub mt8', text: tx('museum_rand', { n: P.rand || 0 }) }));
  DB.themes.forEach((t) => {
    const st = themeStat(t.id);
    const p = totQ ? Math.round(st.questions / totQ * 100) : 0;
    const r = el('div', { class: 'prow' });
    const name = el('span', { class: 'prow-name' });
    name.appendChild(iconEl(THEME_ICON[t.id] || 'theme-body', 'ico sm'));
    name.appendChild(el('span', { text: themeName(t.id) }));
    r.appendChild(name);
    const pb = el('div', { class: 'pb' });
    pb.appendChild(el('i', { style: `width:${p}%` }));
    r.appendChild(pb);
    r.appendChild(el('span', { class: 'prow-pct', text: `${p}%` }));
    r.appendChild(el('span', { class: 'prow-meta', text: tx('museum_theme_meta', { q: st.questions, z: st.quizzes }) }));
    pr.appendChild(r);
  });

  const mb = $('m-best');
  clear(mb);
  if (P.best) {
    const rk = getRank(P.best.correct);
    const card = el('div', { class: 'card mt14' });
    card.appendChild(el('h2', { text: tx('museum_best') })).style.fontSize = '17px';
    const best = el('div', { class: 'best-line' });
    best.appendChild(iconEl(RANK_ICON[rk.id] || 'rank-novice', 'ico'));
    best.appendChild(el('span', { text: ` ${rankName(rk)} · ${P.best.correct}/10` }));
    card.appendChild(best);
    card.appendChild(el('div', { class: 'sub', text: tx('museum_best_sub_fmt', { t: themeName(P.best.theme) }) }));
    mb.appendChild(card);
  }

  const achBox = $('m-ach');
  clear(achBox);
  ACH.forEach((a) => {
    const on = !!P.ach[a.id];
    const chip = el('span', { class: on ? 'on ach-pill' : 'ach-pill' });
    chip.appendChild(iconEl(ACH_ICON[a.id] || 'ach-part', on ? 'ico sm' : 'ico sm dim'));
    chip.appendChild(el('span', { text: tx(a.label) }));
    achBox.appendChild(chip);
  });
}
