import { el } from './ui.js?v=1.44';
import { VERSION } from './config.js?v=1.44';

const EXT = {
  'diff-easy': 'png', 'diff-medium': 'png', 'diff-hard': 'png',
  'rank-novice': 'png', 'rank-apprentice': 'png', 'rank-student': 'png',
  'rank-expert': 'png', 'rank-master': 'png', 'rank-legend': 'png',
  'ach-part': 'png', 'ach-fig': 'png', 'ach-col3': 'png',
  'ach-q100': 'png', 'ach-travel': 'png', 'ach-legend': 'png',
  'theme-body': 'png', 'theme-space': 'png', 'theme-ai': 'png',
  'theme-nature': 'png', 'theme-history': 'png', 'theme-music': 'png',
  'theme-cinema': 'png', 'theme-random': 'png',
  'mood-thoughtful': 'png', 'mood-mysterious': 'png', 'mood-fun': 'png',
  'mood-light': 'png', 'mood-philosophical': 'png',
  'ui-play': 'png', 'ui-duel': 'png', 'ui-museum': 'png', 'ui-help': 'png',
  'ui-cards': 'png', 'ui-themes': 'png', 'ui-ach': 'png',
  'ui-lang': 'png', 'ui-sun': 'png', 'ui-moon': 'png', 'ui-profile': 'png',
  'ui-fact': 'png', 'ui-reward': 'png', 'ui-reroll': 'png', 'ui-swap': 'png',
};

export function iconSrc(name) {
  const pack = globalThis.__FACTBUM_ICONS__;
  if (pack && pack[name]) return pack[name];
  const ext = EXT[name] || 'png';
  return `assets/ui/icons/${name}.${ext}?v=${VERSION}`;
}

export function iconEl(name, cls = 'ico') {
  const img = el('img', { class: cls, alt: '', src: iconSrc(name), loading: 'eager', decoding: 'async' });
  img.addEventListener('error', () => { img.hidden = true; });
  return img;
}

export const RANK_ICON = {
  legend: 'rank-legend',
  master: 'rank-master',
  expert: 'rank-expert',
  student: 'rank-student',
  apprentice: 'rank-apprentice',
  novice: 'rank-novice',
};

export const DIFF_ICON = {
  easy: 'diff-easy',
  medium: 'diff-medium',
  hard: 'diff-hard',
};

export const ACH_ICON = {
  part: 'ach-part',
  fig: 'ach-fig',
  col3: 'ach-col3',
  q100: 'ach-q100',
  travel: 'ach-travel',
  legend: 'ach-legend',
};

export const THEME_ICON = {
  body: 'theme-body',
  space: 'theme-space',
  ai: 'theme-ai',
  nature: 'theme-nature',
  history: 'theme-history',
  music: 'theme-music',
  cinema: 'theme-cinema',
  random: 'theme-random',
};

export const MOOD_ICON = {
  thoughtful: 'mood-thoughtful',
  mysterious: 'mood-mysterious',
  fun: 'mood-fun',
  light: 'mood-light',
  philosophical: 'mood-philosophical',
};
