/**
 * Yandex Games SDK adapter for «Факт-бум. Кто ты?».
 *
 * Replaces the old VK bridge. Design goals:
 *  - Runs inside Yandex Games (server-hosted archive, /sdk.js is served automatically).
 *  - Degrades gracefully outside Yandex (local preview / plain hosting) so the game
 *    still boots instead of throwing.
 *  - Wraps everything the rest of the app needs: init, player cloud storage,
 *    language detection, ads (rewarded + interstitial) and Game Ready.
 *
 * SDK is loaded dynamically from /sdk.js (relative path — required when the
 * archive is uploaded to the Yandex server). Do NOT download /sdk.js into the
 * archive and do NOT use the absolute s3 URL for a server-hosted game.
 */
import { pauseForAd, resumeForAd } from './sound.js?v=1.44';
import { setPaused, isPaused, onPauseChange } from './pause.js?v=1.44';

let ysdk = null;
let yaPlayer = null;
let sdkLoading = null;
let accountChanging = false;
let configuredSDK = null;
let readyRequested = false, readySent = false;
let gameplayWanted = false, gameplayMarked = false;

function deadline(promise, ms, message) {
  let timer;
  return Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(message)),ms);})]).finally(()=>clearTimeout(timer));
}

const SDK_PATH = '/sdk.js';

/** Current language reported by the SDK environment (en/ru or others). */
export let yaPlatformLang = 'ru';

/** Load the SDK script once (idempotent, with timeout). */
function loadSdk(timeoutMs = 6000) {
  if (window.YaGames && typeof window.YaGames.init === 'function') {
    return Promise.resolve(window.YaGames);
  }
  if (sdkLoading) return sdkLoading;

  sdkLoading = new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = SDK_PATH;
    s.async = true;
    const done = (err) => {
      s.onload = s.onerror = null;
      if (err) reject(err);
      else if (window.YaGames && typeof window.YaGames.init === 'function') resolve(window.YaGames);
      else reject(new Error('YaGames not defined after load'));
    };
    const t = setTimeout(() => done(new Error('sdk timeout')), timeoutMs);
    s.onload = () => { clearTimeout(t); done(null); };
    s.onerror = () => { clearTimeout(t); done(new Error('sdk load failed')); };
    document.head.appendChild(s);
  });
  // allow a later retry if this attempt failed
  sdkLoading.catch(() => { sdkLoading = null; });
  return sdkLoading;
}

function mapLang(code) {
  if (!code) return 'ru';
  const c = String(code).toLowerCase();
  if (c === 'ru' || c.startsWith('ru')) return 'ru';
  return 'en';
}

function connectSDK(sdk) {
  ysdk=sdk;
  if(configuredSDK===sdk)return;
  configuredSDK=sdk;
  if (ysdk.on) {
      ysdk.on('game_api_pause', () => setPaused('platform', true));
      ysdk.on('game_api_resume', () => setPaused('platform', false));
      ysdk.on(ysdk.EVENTS?.ACCOUNT_SELECTION_DIALOG_OPENED || 'ACCOUNT_SELECTION_DIALOG_OPENED', () => {
        accountChanging=true; setPaused('account',true); window.dispatchEvent(new Event('factbum:account-changing'));
      });
      ysdk.on(ysdk.EVENTS?.ACCOUNT_SELECTION_DIALOG_CLOSED || 'ACCOUNT_SELECTION_DIALOG_CLOSED', () => {
        accountChanging=true; setPaused('account',true); window.dispatchEvent(new Event('factbum:account-changed'));
      });
    }
    const env = (ysdk.environment && ysdk.environment.i18n) || {};
    yaPlatformLang = mapLang(env.lang);

  syncGameplay();
  window.dispatchEvent(new CustomEvent('factbum:sdk-available',{detail:{lang:yaPlatformLang}}));
  if(readyRequested)gameReady();
}

/**
 * Initialize the SDK. Returns { ysdk, player, user, lang } or a minimal object
 * when the SDK is unavailable (local preview). Never throws.
 *
 * v1.31: the SDK is attempted on EVERY host instead of only on hosts matched by
 * a hostname regex. On Yandex Games /sdk.js is served next to the archive; on
 * any other hosting the request simply fails and we fall back to guest mode.
 * This removes the risk of silently skipping the SDK (and LoadingAPI.ready)
 * on an unrecognized Yandex portal domain.
 */
export async function initYandex() {
  try {
    // solo / local file build (double-click open): the SDK cannot exist on
    // file://, skip the /sdk.js probe to keep the console clean (guest mode).
    if (typeof location !== 'undefined' && location.protocol === 'file:') {
      return { ysdk: null, player: null, lang: 'ru', user: null };
    }
    await loadSdk();
    const initializing=window.YaGames.init();
    try {ysdk=await deadline(initializing,8000,'SDK init timeout');}
    catch(error){
      // Never leave the platform waiting for GameReady forever if init resolves
      // after the local fallback became usable. No late profile is auto-imported.
      initializing.then(connectSDK).catch(()=>{});
      throw error;
    }
    connectSDK(ysdk);

    let player = null;
    try {
      player = await deadline(ysdk.getPlayer({ scopes: false }), 4000, 'Player timeout');
    } catch { player = null; }
    yaPlayer = player;
    return {
      ysdk,
      player,
      lang: yaPlatformLang,
      user: describeUser(),
    };
  } catch (err) {
    // Local / non-Yandex preview: run as guest with local storage only.
    return { ysdk: null, player: null, lang: 'ru', user: null };
  }
}

export function describeUser() {
  if (!yaPlayer) return null;
  try {
    const id = yandexPlayerID();
    const authorized = !!(yaPlayer.isAuthorized && yaPlayer.isAuthorized());
    const name = authorized && yaPlayer.getName ? (yaPlayer.getName() || '') : '';
    return { id: id || '', name, authorized };
  } catch {
    return null;
  }
}

export function isAuthorized() {
  return !!(yaPlayer && yaPlayer.isAuthorized && yaPlayer.isAuthorized());
}

export function yandexPlayerName() {
  try { return (yaPlayer && yaPlayer.getName) ? (yaPlayer.getName() || '') : ''; }
  catch { return ''; }
}

export function yandexPlayerID() {
  try {
    if (yaPlayer && yaPlayer.getUniqueID) return yaPlayer.getUniqueID() || '';
    return (yaPlayer && yaPlayer.getID) ? (yaPlayer.getID() || '') : '';
  } catch { return ''; }
}

/** Only for one-time migration of pre-1.40 local keys. The IDs can differ. */
export function legacyYandexPlayerID() {
  try { return yaPlayer && yaPlayer.getUniqueID && yaPlayer.getID ? yaPlayer.getID() || '' : ''; }
  catch { return ''; }
}

/** Signal Yandex that the game finished loading (required for moderation). */
export function gameReady() {
  readyRequested=true;
  if(readySent||!ysdk?.features?.LoadingAPI)return;
  try{ysdk.features.LoadingAPI.ready();readySent=true;}catch{/* platform retry can call again */}
}
function syncGameplay(){
  const api=ysdk?.features?.GameplayAPI;if(!api)return;
  const shouldPlay=gameplayWanted&&!isPaused();
  try{
    if(shouldPlay&&!gameplayMarked){api.start();gameplayMarked=true;}
    else if(!shouldPlay&&gameplayMarked){api.stop();gameplayMarked=false;}
  }catch{/* SDK is optional in local preview */}
}
onPauseChange(syncGameplay);
export function gameplayStart(){gameplayWanted=true;syncGameplay();}
export function gameplayStop(){
  gameplayWanted=false;
  try{ysdk?.features?.GameplayAPI?.stop();}catch{/* local fallback */}
  gameplayMarked=false;
}

/**
 * Apply platform chrome and defensive UX rules demanded by Yandex:
 * fullscreen-ish layout, no context menu, no text selection, no swipe-to-refresh.
 * Safe to call even without the SDK.
 */
export function applyYandexChrome() {
  // The game's own CSS (css/app.css) already does the right thing for Yandex:
  //  - html,body { overscroll-behavior: none }  -> no swipe-to-refresh;
  //  - each .screen { overflow:auto }            -> tall screens scroll internally,
  //                                                so no browser/system scrollbar appears.
  // We therefore only add the bits the platform checks that the game can't express
  // in CSS alone, and we do NOT fight the existing layout (no overflow:hidden on
  // html/body, no touch-action:none, no blanket touchmove blocking) — otherwise
  // internal scrolling on touch devices would break.

  // Block the browser context menu in the whole game area (requirement 1.6.1.8/1.6.2.7).
  try {
    const block = (e) => { if (e && e.preventDefault) e.preventDefault(); return false; };
    document.addEventListener('contextmenu', block, { passive: false });
  } catch { /* ignore */ }

  // Disable text selection so long-press doesn't highlight the field.
  try {
    document.body.style.webkitUserSelect = 'none';
    document.body.style.userSelect = 'none';
    document.body.style.webkitTouchCallout = 'none';
  } catch { /* ignore */ }

  // On touch, block selection gestures but keep scrolling (scroll is handled by
  // .screen{overflow:auto}; we only neutralise the browser's pull-to-refresh which
  // is already covered by overscroll-behavior:none). Nothing to do here — rely on CSS.
}


/** Ask Yandex for fullscreen when the user enters gameplay (mobile). */
export function requestFullscreen() {
  try {
    if (!window.matchMedia('(pointer: coarse)').matches) return;
    const el = document.documentElement;
    if (document.fullscreenElement) return;
    if (el.requestFullscreen) {
      el.requestFullscreen().catch(() => {});
    } else if (el.webkitRequestFullscreen) {
      el.webkitRequestFullscreen();
    }
  } catch { /* ignore */ }
}

/* ----------------------------- Cloud storage -------------------------------
 * Uses the Yandex Player storage object, which also works for anonymous
 * (guest) players. Quota is ~200 KB per player — we keep the heavy media
 * (card thumbnails) OUT of the cloud, in localStorage only (same as VK build).
 * -------------------------------------------------------------------------- */
export function cloudUsable(uid) {
  return !!(yaPlayer && !accountChanging && uid === 'ya-' + yandexPlayerID());
}

/** Distinguish empty cloud data from offline/failed reads. Never write after a
 * failed read using a guessed player or after the account-selection dialog. */
export async function cloudReadAll(uid) {
  if (!cloudUsable(uid)) return {ok:false,reason:accountChanging?'account':'unavailable',data:null};
  const player=yaPlayer;
  try {
    const data=await deadline(player.getData(), 5000, 'Cloud read timeout');
    if (!cloudUsable(uid)||player!==yaPlayer) return {ok:false,reason:'account',data:null};
    return {ok:true,data:data&&typeof data==='object'?data:{}};
  } catch {return {ok:false,reason:'offline',data:null};}
}
export async function cloudWrite(values,uid) {
  if(!cloudUsable(uid))return false;
  const player=yaPlayer;
  try {await player.setData(values,true);return cloudUsable(uid)&&player===yaPlayer;}catch{return false;}
}

// Compatibility helpers used only by older integrations, not by v3 syncing.
export async function cloudGet(key) {
  const r=await cloudReadAll('ya-'+yandexPlayerID());return r.ok?r.data[key]??null:null;
}
export async function cloudSet(key,value) {
  return cloudWrite({[key]:value},'ya-'+yandexPlayerID());
}

/* ---------------------------------- Ads ------------------------------------
 * Monetization is mandatory on Yandex (requirement 1.12). The game shows:
 *  - interstitial fullscreen ads at natural level boundaries;
 *  - a rewarded video the player can watch voluntarily for a small bonus.
 * -------------------------------------------------------------------------- */
export async function showFullscreen() {
  if (!ysdk || !ysdk.adv) return false;
  pauseForAd(); // §4.7: game sound must pause for the duration of the ad
  try {
    await new Promise((resolve) => {
      ysdk.adv.showFullscreenAdv({
        callbacks: { onClose: resolve, onError: resolve, onOffline: resolve },
      });
    });
    return true;
  } catch {
    return false;
  } finally {
    resumeForAd();
  }
}

/** Returns true only if the player watched the rewarded video to the end. */
export async function showRewarded() {
  if (!ysdk || !ysdk.adv) return false;
  pauseForAd(); // §4.7: game sound must pause for the duration of the ad
  try {
    return await new Promise((resolve) => {
      let rewarded = false;
      ysdk.adv.showRewardedVideo({
        callbacks: {
          onRewarded: () => { rewarded = true; },
          onClose: () => resolve(rewarded),
          onError: () => resolve(false),
        },
      });
    });
  } catch {
    return false;
  } finally {
    resumeForAd();
  }
}

export function isAdsAvailable() {
  return !!(ysdk && ysdk.adv);
}
