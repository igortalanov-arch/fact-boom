/** Puzzle-6 figurines: sketch pieces land scattered & rotated, in a random order and random
 *  cells that differ per save and per re-assembly; at 6/6 they slowly fly home spinning in the
 *  air, coloring in as each one lands. */
import { FIGURE_PARTS } from './config.js?v=1.44';
import { P } from './state.js?v=1.44';
import { click as soundClick } from './sound.js?v=1.44';
import { el } from './ui.js?v=1.44';

const COLS = 2;
const ROWS = 3;

/* Slow, deliberate assembly so the player feels every piece: each flight ~1.3 s with a full
 * turn, staggered takeoffs, snap + color on landing, flash finale afterwards. */
export const ASSEMBLY = { lead: 520, step: 230, fly: 1250, flyVar: 120, tail: 240 };

export function figSrc(id, kind) {
  const pack = globalThis.__FACTBUM_FIGS__;
  const key = `${id}/${kind}`;
  if (pack && pack[key]) return pack[key];
  return `assets/figures/${id}/${kind}.jpg`;
}

function hashStr(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* Layout seed = figure + per-save random + re-assembly counter: same save renders one layout
 * consistently everywhere, but a fresh save (or a reset figure) scatters differently. */
export function assemblyKey(id) {
  const epoch = (P && P.figsV && P.figsV[id]) >>> 0;
  return `puz6:${id}:${(P && P.seed) >>> 0}:${epoch}`;
}

export function scatterFor(id, key) {
  const rnd = mulberry32(hashStr(String(key || assemblyKey(id))));
  const slots = [0, 1, 2, 3, 4, 5];
  for (let i = slots.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    const t = slots[i]; slots[i] = slots[j]; slots[j] = t;
  }
  const regions = [0, 1, 2, 3, 4, 5];
  for (let i = regions.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    const t = regions[i]; regions[i] = regions[j]; regions[j] = t;
  }
  const R = [0, 90, 180, 270];
  // Entry i describes the i-th COLLECTED piece: which image region it holds (random order)
  // and where it lands, rotated (random cell).
  return regions.map((region, i) => {
    const slot = slots[i];
    let rot = R[Math.floor(rnd() * 4)];
    if (slot === region && rot === 0) rot = 180; // never home+unrotated: always visibly scattered
    return { slot, rot, region };
  });
}

const posOf = (k) => ({ x: (k % COLS) * 50, y: Math.floor(k / COLS) * (100 / ROWS) });
const bgOf = (k) => `${k % COLS === 0 ? '0%' : '100%'} ${(Math.floor(k / COLS) / (ROWS - 1)) * 100}%`;

function reducedMotion() {
  try { return !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches); }
  catch { return false; }
}

function finishInstant(wrap, pieces, sc) {
  pieces.forEach((d) => {
    const i = Number(d.dataset.i);
    const home = posOf(sc[i].region);
    d.style.transition = 'none';
    d.style.transitionDelay = '0ms';
    d.style.left = `${home.x}%`;
    d.style.top = `${home.y}%`;
    d.style.transform = 'rotate(0deg)';
    const cl = d.querySelector('.puz-color');
    if (cl) { cl.style.transition = 'none'; cl.style.transitionDelay = '0ms'; cl.style.opacity = '1'; }
  });
  wrap.classList.add('coloring');
}

function playAssembly(wrap, pieces, sc, onDone) {
  if (reducedMotion() || !pieces.length) {
    finishInstant(wrap, pieces, sc);
    if (onDone) window.setTimeout(onDone, 30);
    return;
  }
  const A = ASSEMBLY;
  let last = 0;
  pieces.forEach((d, k) => {
    const i = Number(d.dataset.i);
    const home = posOf(sc[i].region);
    const dur = A.fly + (k % 3) * A.flyVar;
    const delay = A.lead + k * A.step;
    last = Math.max(last, delay + dur);
    d.style.transition = `left ${dur}ms cubic-bezier(.45,.03,.35,.98), top ${dur}ms cubic-bezier(.45,.03,.35,.98), transform ${dur + 60}ms cubic-bezier(.4,.02,.3,1)`;
    d.style.transitionDelay = `${delay}ms`;
    d.style.left = `${home.x}%`;
    d.style.top = `${home.y}%`;
    // A full turn in flight (direction alternates); lands unrotated (0 mod 360).
    d.style.transform = `rotate(${k % 2 ? -360 : 720}deg)`;
    const cl = d.querySelector('.puz-color');
    if (cl) {
      cl.style.transition = 'opacity .5s ease';
      cl.style.transitionDelay = `${delay + dur - 260}ms`;
      cl.style.opacity = '1';
    }
    window.setTimeout(() => {
      if (!d.isConnected) return;
      try { soundClick(); } catch { /* silent */ }
    }, delay + dur);
  });
  window.setTimeout(() => {
    if (!wrap.isConnected) return;
    wrap.classList.add('coloring');
    const flash = el('div', { class: 'puz-flash', 'aria-hidden': 'true' });
    wrap.appendChild(flash);
    window.setTimeout(() => flash.remove(), 950);
    if (onDone) window.setTimeout(onDone, A.tail);
  }, last + 120);
}

export function figSvgEl(id, collected, opts = {}) {
  const n = Math.max(0, Math.min(FIGURE_PARTS, collected | 0));
  const wrap = el('div', { class: 'figsil puzzle' + (opts.size ? ' ' + opts.size : '') });
  wrap.setAttribute('role', 'img');
  const done = n >= FIGURE_PARTS;
  const sc = scatterFor(id, opts.scatterKey);
  const sketch = figSrc(id, 'sketch');
  const color = figSrc(id, 'color');
  for (let s = 0; s < FIGURE_PARTS; s++) {
    const p = posOf(s);
    const sock = el('span', { class: 'puz-sock', 'aria-hidden': 'true' });
    sock.style.left = `${p.x}%`;
    sock.style.top = `${p.y}%`;
    wrap.appendChild(sock);
  }
  const pieces = [];
  for (let i = 0; i < n; i++) {
    const settled = done && !opts.celebrate;
    const at = settled ? posOf(sc[i].region) : posOf(sc[i].slot);
    const d = el('div', { class: 'puz-piece' + (opts.highlight === i ? ' new' : '') });
    d.dataset.i = String(i);
    d.dataset.r = String(sc[i].region);
    d.style.left = `${at.x}%`;
    d.style.top = `${at.y}%`;
    d.style.transform = `rotate(${settled ? 0 : sc[i].rot}deg)`;
    d.style.backgroundImage = `url(${JSON.stringify(sketch)})`;
    d.style.backgroundPosition = bgOf(sc[i].region);
    const cl = el('span', { class: 'puz-color', 'aria-hidden': 'true' });
    cl.style.backgroundImage = `url(${JSON.stringify(color)})`;
    cl.style.backgroundPosition = bgOf(sc[i].region);
    if (settled) cl.style.opacity = '1';
    d.appendChild(cl);
    wrap.appendChild(d);
    pieces.push(d);
  }
  if (done) wrap.classList.add('complete');
  if (done && opts.celebrate) {
    const kick = () => playAssembly(wrap, pieces, sc, opts.onDone);
    if (typeof requestAnimationFrame === 'function') requestAnimationFrame(() => requestAnimationFrame(kick));
    else window.setTimeout(kick, 50);
  }
  if (typeof Image !== 'undefined') {
    const probe = new Image();
    probe.onerror = () => {
      if (!wrap.isConnected) return;
      wrap.classList.add('broken');
      wrap.textContent = '';
      wrap.appendChild(el('div', { class: 'sil-fallback', text: '◆' }));
    };
    probe.src = sketch;
  }
  return wrap;
}

/* Confetti burst over the reward figure. Canvas 2D, self-cleaning. */
export function celebrateFx(host) {
  if (!host || !host.isConnected || reducedMotion()) return;
  if (typeof requestAnimationFrame !== 'function') return;
  const cv = document.createElement('canvas');
  try {
    const r = host.getBoundingClientRect();
    cv.width = Math.max(60, Math.round(r.width) || 300);
    cv.height = Math.max(60, Math.round(r.height) || 300);
  } catch { return; }
  cv.className = 'puz-confetti';
  host.classList.add('puz-fx-host');
  host.appendChild(cv);
  const ctx = cv.getContext('2d');
  if (!ctx) { cv.remove(); return; }
  const W = cv.width, H = cv.height;
  const cols = ['#ffd54f', '#5b8cff', '#3ddc97', '#ff6b81', '#9b7bff', '#ffffff'];
  const ps = [];
  for (let i = 0; i < 140; i++) {
    const rnd = Math.random;
    ps.push({
      x: W / 2 + (rnd() - 0.5) * W * 0.5, y: H * 0.35 + (rnd() - 0.5) * H * 0.3,
      vx: (rnd() - 0.5) * 7, vy: -2 - rnd() * 6, g: 0.22 + rnd() * 0.12,
      w: 4 + rnd() * 5, h: 6 + rnd() * 7, a: rnd() * Math.PI, va: (rnd() - 0.5) * 0.3,
      c: cols[(rnd() * cols.length) | 0], ph: rnd() * Math.PI * 2,
    });
  }
  const t0 = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
  const step = (now) => {
    const t = ((typeof now === 'number' ? now : Date.now()) - t0) / 1000;
    ctx.clearRect(0, 0, W, H);
    ctx.globalAlpha = t > 1.6 ? Math.max(0, 1 - (t - 1.6) / 0.8) : 1;
    for (const p of ps) {
      p.vy += p.g; p.x += p.vx + Math.sin(t * 5 + p.ph) * 0.6; p.y += p.vy; p.a += p.va;
      if (p.y > H + 20) continue;
      ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.a);
      ctx.fillStyle = p.c; ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
      ctx.restore();
    }
    ctx.globalAlpha = 1;
    if (t < 2.4 && cv.isConnected) requestAnimationFrame(step);
    else cv.remove();
  };
  requestAnimationFrame(step);
}
