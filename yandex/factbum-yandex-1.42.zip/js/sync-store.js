import { CLOUD_PREFIX, newBranch, mergeRecords, aggregate, applyChange, changeHasData, validBranch, legacyChange, mergeLegacy, progressChange, hasReset, stableStringify } from './sync-model.js?v=1.42';
import { cloudReadAll, cloudWrite, cloudUsable } from './yandex.js?v=1.42';
const PREFIX='factbum_sync3_', OUTBOX='factbum_outbox3_';
const clone=x=>JSON.parse(JSON.stringify(x));
const uuid=()=>globalThis.crypto?.randomUUID?.().replaceAll('-','') || Date.now().toString(36)+Math.random().toString(36).slice(2)+Math.random().toString(36).slice(2);
function get(k){try{return localStorage.getItem(k);}catch{return null;}}
function put(k,v){try{localStorage.setItem(k,v);return true;}catch{return false;}}
function remove(k){try{localStorage.removeItem(k);}catch{/* keep the durable operation */}}
function json(s,fallback){try{return JSON.parse(s)||fallback;}catch{return fallback;}}
function locks(name,fn){
  let entered=false;
  try{
    if(!navigator.locks?.request)return Promise.resolve().then(fn);
    return navigator.locks.request(name,()=>{entered=true;return fn();}).catch(error=>{if(!entered)return fn();throw error;});
  }catch(error){return entered?Promise.reject(error):Promise.resolve().then(fn);}
}
function actorID(){
  // Web Locks serialize same-installation tabs. Older browsers use a separate
  // session actor so unrelated tabs never overwrite the same cloud key.
  const key='factbum_writer_v3';
  let persistent=false;try{persistent=!!navigator.locks?.request;}catch{}
  try{const storage=persistent ? localStorage : sessionStorage;let id=storage.getItem(key);if(!/^[a-z0-9]{16,64}$/.test(id||'')){id=uuid();storage.setItem(key,id);}return id;}catch{return uuid();}
}
export class SyncStore {
  constructor(uid, {onChange,onStatus,retainOperations}={}) {
    this.uid=uid;this.actor=actorID();this.key=PREFIX+uid+'_'+this.actor;this.outPrefix=OUTBOX+uid+'_';
    this.records={};this.applied=new Set();this.memory=new Map();this.onChange=onChange||(()=>{});this.onStatus=onStatus||(()=>{});
    this.retainOperations=retainOperations||(()=>[]);
    this.status={state:'loading',local:true,pending:0};this.cloudAck=0;this.lastCloud=0;this.remoteData={};this.timer=0;this.localTask=null;this.cloudTask=null;this.closed=false;this.migrated=false;this.legacyCloudRead=false;this.localArchiveWasEmpty=false;this.lastGoodRead=false;
  }
  setStatus(state,extra={}){this.status={...this.status,state,...extra};this.onStatus({...this.status});}
  snapshot(){return {uid:this.uid,actor:this.actor,...this.status,ownRevision:this.records[this.actor]?.rev||0,cloudAck:this.cloudAck,slots:Object.keys(this.records).length};}
  localRead(){
    const value=json(get(this.key),{});
    if(value.schema===3 && value.uid===this.uid){this.records=mergeRecords(this.records,value.records);this.migrated ||= !!value.migrated;this.legacyCloudRead ||= !!value.legacyCloudRead;this.localArchiveWasEmpty ||= !!value.localArchiveWasEmpty;this.cloudAck=Math.max(this.cloudAck,Number(value.cloudAck)||0);}
    this.records[this.actor] ||= newBranch(this.actor);
  }
  pending(){
    const jobs=new Map(this.memory);
    try{for(let i=0;i<localStorage.length;i++){
      const key=localStorage.key(i);if(!key?.startsWith(this.outPrefix))continue;
      const op=json(get(key),null);if(op?.uid===this.uid&&op.actor===this.actor&&op.id&&op.change)jobs.set(op.id,op);
    }}catch{/* memory still works; UI reports storage loss */}
    return [...jobs.values()].sort((a,b)=>a.time-b.time||a.id.localeCompare(b.id));
  }
  persist(){
    const pendingIDs=new Set([...this.pending().map(x=>x.id),...this.retainOperations()]);
    for(const [actor,r] of Object.entries(this.records)){
      if(actor!==this.actor){r.receipts=[];continue;}
      const ids=[...new Set(r.receipts||[])].sort();const recent=new Set(ids.slice(-128));
      r.receipts=ids.filter(id=>recent.has(id)||pendingIDs.has(id));
    }
    const ok=put(this.key,stableStringify({schema:3,uid:this.uid,migrated:this.migrated,legacyCloudRead:this.legacyCloudRead,localArchiveWasEmpty:this.localArchiveWasEmpty,cloudAck:this.cloudAck,records:this.records}));
    this.status.local=ok;
    if(!ok)this.setStatus('storage-error',{local:false});
    return ok;
  }
  emit(){
    const view=mergeRecords(this.records,{});
    for(const op of this.pending())if(!this.applied.has(op.id)&&!view[this.actor]?.receipts.includes(op.id))view[this.actor]=applyChange(view[this.actor]||newBranch(this.actor),op.change,view);
    this.onChange(aggregate(view));
  }
  parseCloud(data){
    const records={};for(const [k,v]of Object.entries(data||{})){
      if(!k.startsWith(CLOUD_PREFIX))continue;
      const actor=k.slice(CLOUD_PREFIX.length),r=typeof v==='string'?json(v,null):v;
      if(validBranch(r,actor))records[actor]=r;
    }return records;
  }
  async init({localProgress,localCards=[],hasLocalCards=false,localProjection=false,legacyProgress,legacyCards}={}){
    this.legacyProgress=legacyProgress;this.legacyCards=legacyCards;
    this.localRead();
    if(!this.migrated)this.localArchiveWasEmpty=hasLocalCards&&!localCards.length&&!localProjection;
    const response=await cloudReadAll(this.uid);
    if(response.ok){this.remoteData=response.data;this.lastGoodRead=true;this.records=mergeRecords(this.records,this.parseCloud(response.data));}
    const legacyP=legacyProgress(response.ok?response.data.factbum_yandex_v2:null);
    const legacyC=legacyCards(response.ok?response.data.factbum_yandex_c1:null);
    if(!this.migrated){
      const populated=Object.values(this.records).some(r=>r.rev>0);
      let change;
      if(!populated){change=legacyChange(mergeLegacy(localProgress,legacyP),[...localCards,...legacyC]);}
      else {
        const visible=aggregate(this.records).progress;
        // Only import a genuine v1/v2 local snapshot once, never a v3 projection.
        change=localProjection?{}:progressChange(visible,mergeLegacy(visible,localProgress),this.records);
        for(const id of Object.keys(change.parts||{}))if(hasReset(this.records,id))delete change.parts[id];
        change.cards=Object.fromEntries(localCards.map(c=>[c.id,c]));
      }
      // An explicitly empty old local archive can suppress the old cloud IDs,
      // but not new cards subsequently created in v3 on another device.
      if(hasLocalCards&&!localCards.length&&legacyC.length){change.deleted=Object.fromEntries(legacyC.map(c=>[c.id,1]));}
      this.records[this.actor]=applyChange(this.records[this.actor]||newBranch(this.actor),change,this.records);
      this.migrated=true;
      this.legacyCloudRead=response.ok;
    }
    // Local outbox survives reload/offline. Merge it before displaying progress.
    await this.flushLocal(false);this.emit();
    if(!this.status.local)this.setStatus('storage-error');
    else this.setStatus(response.ok?'pending':cloudUsable(this.uid)?'offline':'local');
    this.bind();this.schedule(300);
    return aggregate(this.records);
  }
  hasOperation(id){
    if(!id)return false;
    this.localRead();
    if(this.applied.has(id)||this.pending().some(op=>op.id===id))return true;
    if(Object.values(this.records).some(r=>r.receipts?.includes(id)))return true;
    return Object.values(this.parseCloud(this.remoteData)).some(r=>r.receipts?.includes(id));
  }
  operationDurable(id){
    if(!id)return false;
    const op=json(get(this.outPrefix+id),null);
    if(op?.id===id&&op.uid===this.uid)return true;
    const local=json(get(this.key),{});
    if(local.uid===this.uid&&Object.values(local.records||{}).some(r=>r.receipts?.includes(id)))return true;
    return Object.values(this.parseCloud(this.remoteData)).some(r=>r.receipts?.includes(id));
  }
  enqueue(change,operationId=null){
    if(this.closed||!changeHasData(change))return this.flushLocal(false);
    if(operationId&&this.hasOperation(operationId))return this.flushLocal(false);
    const id=operationId||Date.now().toString(36)+'-'+uuid();
    if(!/^[a-zA-Z0-9:_-]{1,96}$/.test(id))throw new Error('Invalid operation ID');
    const op={id,uid:this.uid,actor:this.actor,time:Date.now(),change:{...clone(change),opID:id}};
    this.memory.set(id,op);
    const durable=put(this.outPrefix+id,JSON.stringify(op));
    if(!durable)this.setStatus('storage-error',{local:false});else this.setStatus('pending',{pending:this.pending().length});
    return this.flushLocal();
  }
  flushLocal(schedule=true){
    if(this.localTask)return this.localTask.then(()=>this.pending().length?this.flushLocal(schedule):undefined);
    const run=async()=>{
      if(this.closed)return;
      this.localRead();const applied=[];
      for(const op of this.pending()){
        if(!this.applied.has(op.id)&&!this.records[this.actor].receipts.includes(op.id)){
          this.records[this.actor]=applyChange(this.records[this.actor],op.change,this.records);this.applied.add(op.id);
        }
        applied.push(op);
      }
      const saved=this.persist();
      if(saved){for(const op of applied){remove(this.outPrefix+op.id);this.memory.delete(op.id);}}
      this.status.pending=Math.max(this.pending().length,(this.records[this.actor]?.rev||0)>this.cloudAck?1:0);
      this.emit();if(schedule)this.schedule(500);
    };
    const task=locks('factbum-local-'+this.uid,run);this.localTask=task;
    return task.finally(()=>{if(this.localTask===task)this.localTask=null;});
  }
  schedule(delay=500){
    if(this.closed)return;clearTimeout(this.timer);
    if(!cloudUsable(this.uid)){if(this.status.local)this.setStatus('local');return;}
    const wait=Math.max(delay,5000-(Date.now()-this.lastCloud));
    this.timer=setTimeout(()=>{this.timer=0;this.syncNow().catch(()=>this.setStatus('offline'));},wait);
  }
  async syncNow(){
    if(this.closed||!cloudUsable(this.uid))return false;
    await this.flushLocal(false);
    if(this.cloudTask)return this.cloudTask;
    const run=async()=>{
      if(this.closed||!cloudUsable(this.uid))return false;
      this.lastCloud=Date.now();this.setStatus('syncing');
      const response=await cloudReadAll(this.uid);
      if(!response.ok){this.setStatus(response.reason==='account'?'account':'offline');this.schedule(15000);return false;}
      this.remoteData=response.data;this.lastGoodRead=true;
      await locks('factbum-local-'+this.uid,async()=>{
        this.localRead();this.records=mergeRecords(this.records,this.parseCloud(response.data));
        if(!this.legacyCloudRead){
          const oldP=this.legacyProgress(response.data.factbum_yandex_v2), oldC=this.legacyCards(response.data.factbum_yandex_c1);
          const d=legacyChange(oldP,oldC);
          for(const scope of Object.keys(d.used))if(Object.values(this.records).some(r=>r.used?.[scope]))delete d.used[scope];
          if(this.localArchiveWasEmpty&&oldC.length)d.deleted=Object.fromEntries(oldC.map(c=>[c.id,1]));
          this.records[this.actor]=applyChange(this.records[this.actor],d,this.records);this.legacyCloudRead=true;
        }
        this.persist();this.emit();
      });
      const branch=clone(this.records[this.actor]);const key=CLOUD_PREFIX+this.actor;
      const remote=typeof response.data[key]==='string'?json(response.data[key],null):response.data[key];
      // An unchanged actor slot needs no write. Pulling other slots still updates UI.
      const same=remote&&stableStringify(mergeRecords({[this.actor]:branch},{[this.actor]:remote})[this.actor])===stableStringify(remote);
      if(same&&this.cloudAck>=branch.rev){this.setStatus(this.status.local?'synced':'storage-error',{pending:0});return true;}
      const values={[key]:branch};
      // Retire only known legacy cloud duplicates, after their data has been
      // migrated locally. Each device still writes ONLY its own v3 slot.
      if(this.migrated){
        const oldP=response.data.factbum_yandex_v2,oldC=response.data.factbum_yandex_c1;
        const p=typeof oldP==='string'?json(oldP,null):oldP,c=typeof oldC==='string'?json(oldC,null):oldC;
        // A corrupt/unrecognised legacy value is retained for recovery, not erased.
        if(p&&typeof p==='object'&&!Array.isArray(p)&&(p.v==null||Number(p.v)<=3)&&['sessions','answered','figs','duels','arch','themes'].some(k=>k in p)){
          put('factbum_cloud_progress_backup_'+this.uid,typeof oldP==='string'?oldP:JSON.stringify(oldP));values.factbum_yandex_v2=null;
        }
        if(Array.isArray(c)){
          const backed=put('factbum_cloud_cards_backup_'+this.uid,typeof oldC==='string'?oldC:JSON.stringify(oldC));
          if(backed||!c.some(x=>x&&x.img))values.factbum_yandex_c1=null;
        }
      }
      const size=new TextEncoder().encode(JSON.stringify({...response.data,...values})).length;
      if(size>190000){this.setStatus('quota',{bytes:size});return false;}
      const warning=setTimeout(()=>this.setStatus('offline'),12000);
      // Do not race/abandon setData: a late old write must not overtake a retry.
      const ok=await cloudWrite(values,this.uid);clearTimeout(warning);
      if(!ok){this.setStatus('offline');this.schedule(15000);return false;}
      this.remoteData={...response.data,...values};
      await locks('factbum-local-'+this.uid,async()=>{
        this.localRead();this.cloudAck=Math.max(this.cloudAck,branch.rev);this.persist();
        for(const op of this.pending())if(branch.receipts.includes(op.id)){remove(this.outPrefix+op.id);this.memory.delete(op.id);}
      });
      const dirty=(this.records[this.actor]?.rev||0)>this.cloudAck;
      this.setStatus(this.status.local?(dirty?'pending':'synced'):'storage-error',{pending:dirty?1:0,bytes:size});
      if(dirty)this.schedule(500);return true;
    };
    const task=locks('factbum-cloud-'+this.uid+'-'+this.actor,run);this.cloudTask=task;
    try{return await task;}finally{if(this.cloudTask===task)this.cloudTask=null;}
  }
  bind(){
    this.online=()=>this.schedule(0);this.focus=()=>{if(!document.hidden)this.schedule(0);};
    this.storage=e=>{if(e.key===this.key){this.localRead();this.emit();}else if(e.key?.startsWith(this.outPrefix))this.flushLocal().catch(()=>{});};
    window.addEventListener('online',this.online);window.addEventListener('focus',this.focus);window.addEventListener('storage',this.storage);
  }
  close(){this.closed=true;clearTimeout(this.timer);window.removeEventListener('online',this.online);window.removeEventListener('focus',this.focus);window.removeEventListener('storage',this.storage);}
}
