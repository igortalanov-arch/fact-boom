import { tx } from './i18n.js?v=1.42';
import { syncDock, resetScreenScroll } from './layout.js?v=1.42';
import { setPaused } from './pause.js?v=1.42';

export function $(id) {
  return document.getElementById(id);
}

export function clear(el) {
  while (el && el.firstChild) el.removeChild(el.firstChild);
}

export function el(tag, attrs = {}, children = []) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v == null || v === false) continue;
    if (k === 'class') n.className = v;
    else if (k === 'text') n.textContent = v;
    else if (k === 'html') n.innerHTML = v;
    else if (k.startsWith('on') && typeof v === 'function') n.addEventListener(k.slice(2), v);
    else n.setAttribute(k, v === true ? '' : v);
  }
  for (const c of [].concat(children)) {
    if (c == null) continue;
    n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  }
  return n;
}

let current = 'boot';
let historyEnabled = true;

export function screenId() {
  return current;
}

export function go(id, { push = true, replace = false } = {}) {
  const node = $('scr-' + id);
  if (!node) return;
  if (current === id) push = false;
  document.querySelectorAll('.screen').forEach((s) => s.classList.remove('on'));
  node.classList.add('on');
  current = id;
  resetScreenScroll(id);
  syncDock(id);
  window.dispatchEvent(new CustomEvent('factbum:screen', { detail: id }));
  if ((push || replace) && historyEnabled) {
    try {
      const url = new URL(location.href);
      url.hash = id;
      history[replace ? 'replaceState' : 'pushState']({ screen: id }, '', url);
    } catch { /* ignore */ }
  }
}

export function bindHistory(onBack) {
  try {
    const url = new URL(location.href);
    url.hash = 'start';
    history.replaceState({ screen: 'start' }, '', url);
  } catch { /* ignore */ }
  window.addEventListener('popstate', (e) => {
    const target = (e.state && e.state.screen) || 'start';
    onBack(target);
  });
}

let modalResolve = null;
let modalFocus = null;
const modalQueue = [];

function paintModal(opts) {
  const root = $('modal');
  if (root) root.dataset.kind = opts.kind || '';
  $('modal-txt').textContent = opts.text;
  $('modal-ok').textContent = opts.ok || 'OK';
  const c = $('modal-cancel');
  if (opts.cancel) {
    c.hidden = false;
    c.textContent = opts.cancel;
  } else {
    c.hidden = true;
  }
  modalFocus = document.activeElement;
  root.hidden = false;
  setPaused('modal', true);
  const destructive = /^(exit|leave|del-)/.test(opts.kind || '');
  const focusEl = destructive && opts.cancel ? c : $('modal-ok');
  try { focusEl.focus(); } catch { /* */ }
}

export function showModal({ text, ok, cancel, kind }) {
  return new Promise((resolve) => {
    const job = { text, ok, cancel, kind, resolve };
    if (modalResolve) {
      modalQueue.push(job);
      return;
    }
    modalResolve = resolve;
    paintModal(job);
  });
}

export function hideModal(result) {
  $('modal').hidden = true;
  const r = modalResolve;
  modalResolve = null;
  setPaused('modal', false);
  if (modalFocus && modalFocus.isConnected) { try { modalFocus.focus({ preventScroll: true }); } catch { /* ignore */ } }
  if (r) r(result);
  const next = modalQueue.shift();
  if (next) {
    modalResolve = next.resolve;
    paintModal(next);
  }
}

export function bindModal() {
  $('modal-ok').addEventListener('click', () => hideModal(true));
  $('modal-cancel').addEventListener('click', () => hideModal(false));
  $('modal').addEventListener('click', (e) => {
    if (e.target.id === 'modal') hideModal(false);
  });
  $('modal').addEventListener('keydown', (e) => {
    if (e.key !== 'Tab') return;
    const root = $('modal');
    if (!root || root.hidden) return;
    const list = [...root.querySelectorAll('button')].filter((b) => !b.hidden);
    if (!list.length) return;
    const first = list[0];
    const last = list[list.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  });
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' || e.defaultPrevented) return;
    const modal = $('modal');
    if (modal && !modal.hidden) {
      e.preventDefault();
      e.stopImmediatePropagation();
      hideModal(false);
    }
  });
}

export async function confirmExit(saved = false) {
  return showModal({
    kind: saved?'exit-save':'exit',
    text: tx(saved?'checkpoint_exit':'exit_confirm'),
    ok: tx(saved?'checkpoint_menu':'exit_yes'),
    cancel: tx('exit_no'),
  });
}

let toastTimer = 0;
export function toast(text) {
  let n = document.getElementById('toast');
  if (!n) {
    n = document.createElement('div');
    n.id = 'toast';
    n.className = 'toast';
    (document.getElementById('app') || document.body).appendChild(n);
  }
  n.textContent = text;
  n.classList.add('on');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => n.classList.remove('on'), 2800);
}
