/** 3D figurines: silhouette + 5 pixel-cut parts (head, torso, arms, legs, unique). */
import { el } from './ui.js?v=1.42';

const PARTS = ['head', 'torso', 'arms', 'legs', 'unique'];

export function figSrc(id, part) {
  const pack = globalThis.__FACTBUM_FIGS__;
  const key = part ? `${id}/${part}` : id;
  if (pack && pack[key]) return pack[key];
  if (part) return `assets/figures/${id}/${part}.png`;
  return `assets/figures/${id}/full.png`;
}

export function figSvgEl(id, collected, opts = {}) {
  const n = Math.max(0, Math.min(5, collected | 0));
  const wrap = el('div', { class: 'figsil photo' + (opts.size ? ' ' + opts.size : '') });
  const full = figSrc(id);
  const url = `url(${JSON.stringify(full)})`;

  const sil = el('span', { class: 'sil-mask', 'aria-hidden': 'true' });
  sil.style.maskImage = url;
  sil.style.webkitMaskImage = url;
  wrap.appendChild(sil);

  PARTS.forEach((part, i) => {
    const img = el('img', {
      class: 'layer paint' + (n > i ? ' on' : '') + (opts.highlight === i ? ' new' : ''),
      alt: '',
      src: figSrc(id, part),
      loading: 'lazy',
    });
    wrap.appendChild(img);
  });

  const fullImg = el('img', { class: 'layer full-img', alt: '', src: full });
  wrap.appendChild(fullImg);
  if (n >= 5) wrap.classList.add('complete');

  fullImg.addEventListener('error', () => {
    wrap.classList.remove('photo', 'complete');
    wrap.textContent = '';
    wrap.appendChild(el('div', { class: 'sil-fallback', text: '◆' }));
  });
  return wrap;
}
