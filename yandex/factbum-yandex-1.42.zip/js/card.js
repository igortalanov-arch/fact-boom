import { ADVICE_DIR_MAP, ADVICE_DIRS, GENERIC_PCT, HYBRID_GAP, QUESTIONS_PER_RUN, getRank } from './config.js?v=1.42';
import { DB, locName } from './data.js?v=1.42';
import { P, S } from './state.js?v=1.42';
import { lang, tx, archName, themeName, diffName, rankName } from './i18n.js?v=1.42';
import { $, clear, el } from './ui.js?v=1.42';
import { shuffle } from './quiz.js?v=1.42';
import { iconEl, RANK_ICON } from './icons.js?v=1.42';
import { cardCols, cardTitle } from './share.js?v=1.42';

export function calcCard() {
  const total = Object.values(S.pts).reduce((a, b) => a + b, 0) || 1;
  const correct = QUESTIONS_PER_RUN - S.wrong;
  const sorted = Object.entries(S.pts).sort((a, b) => b[1] - a[1]);
  const top1 = sorted[0] ? sorted[0][0] : 'explorer';
  const p1 = sorted[0] ? sorted[0][1] : 0;
  const top2 = sorted[1] ? sorted[1][0] : null;
  const p2 = sorted[1] ? sorted[1][1] : 0;
  const pct = Math.round(p1 / total * 100);
  const generic = pct < GENERIC_PCT;
  const hybrid = !generic && sorted.length > 1 && (p1 - p2) <= HYBRID_GAP;
  const th = DB.themes.find((t) => t.id === S.theme);
  const noun = S.random
    ? tx('noun_random')
    : (lang() === 'en' ? ('of ' + (th ? th.noun_en : '')) : (th ? th.noun_ru : ''));
  const title = generic
    ? tx('generic_title')
    : hybrid
      ? `${archName(top1)}-${archName(top2)} ${noun}`
      : `${archName(top1)} ${noun}`;
  const advice = pickAdvice(generic ? [top1, top2].filter(Boolean) : [top1]);
  return { top1, top2, p1, p2, pct, generic, hybrid, title, total, advice, correct };
}

function pickAdvice(archs) {
  const dir = ADVICE_DIRS[(Math.max(0, P.sessions - 1)) % ADVICE_DIRS.length];
  const want = ADVICE_DIR_MAP[dir];
  const correct = QUESTIONS_PER_RUN - S.wrong;
  const lv = correct <= 4 ? 1 : (correct >= 7 ? 2 : null);
  let pool = DB.advice.filter((s) => archs.includes(s.a) && want.includes(s.th));
  if (lv && !pool.some((s) => s.lv === lv)) {
    pool = DB.advice.filter((s) => archs.includes(s.a));
  }
  if (!pool.length) pool = DB.advice.filter((s) => archs.includes(s.a));
  if (!pool.length) pool = DB.advice.slice();
  const preferred = lv ? shuffle(pool.filter((s) => s.lv === lv)) : [];
  const rest = lv ? shuffle(pool.filter((s) => s.lv !== lv)) : shuffle(pool);
  return preferred.concat(rest).slice(0, 1);
}

export function renderCard() {
  const c = S.card;
  const arch = DB.archetypes.find((a) => a.id === c.top1);
  const base = c.generic ? ['#5b8cff', '#27407e'] : (arch ? arch.c : ['#5b8cff', '#27407e']);
  const [cc1, , cc2] = cardCols(base[0], base[1]);
  const bc = $('bigcard');
  bc.style.setProperty('--c1', cc1);
  bc.style.setProperty('--c2', cc2);
  clear(bc);
  const em = el('div', { class: 'em' });
  em.appendChild(iconEl(RANK_ICON[getRank(c.correct).id] || 'rank-novice', 'ico lg'));
  bc.appendChild(em);
  bc.appendChild(el('div', { class: 'ttl', text: cardTitle({ ...c, kind: 'solo', theme: S.random ? 'random' : S.theme }) }));
  const rk = getRank(c.correct);
  bc.appendChild(el('div', { class: 'rk', text: `${rankName(rk)} · ${tx('score_of10_fmt', { c: c.correct })}` }));
  const archLine = c.generic
    ? `${tx('card_arch_balanced')} ${tx('card_theme_fmt', { t: themeName(S.random ? 'random' : S.theme) })}`
    : `${archName(c.top1)} — ${c.pct}% ${tx('card_theme_fmt', { t: themeName(S.random ? 'random' : S.theme) })}`;
  bc.appendChild(el('div', { class: 'arch', text: archLine }));
  if (c.top2 && !c.generic) {
    bc.appendChild(el('div', {
      class: 'shadow',
      text: tx('card_shadow_fmt', { a: archName(c.top2), p: Math.round(c.p2 / c.total * 100) }),
    }));
  }

  bc.appendChild(el('p',{class:'archetype-note',text:tx('archetype_note')}));

  const box = $('card-sovety');
  clear(box);
  const tip = c.advice && c.advice[0];
  if (tip) {
    const th = DB.adviceThemes.find((x) => x.id === tip.th);
    const card = el('div', { class: 'bigcard', id: 'sovet-card' });
    card.style.setProperty('--c1', cc1);
    card.style.setProperty('--c2', cc2);
    card.appendChild(el('div', { class: 'rk', text: tx('sovety_title') }));
    card.appendChild(el('div', { class: 'ttl', text: lang() === 'en' ? tip.en : tip.ru }));
    card.appendChild(el('div', {
      class: 'arch',
      text: `${archName(tip.a)} · ${locName(th, lang())}`,
    }));
    box.appendChild(card);
  }
  $('card-cur').textContent = tx('card_cur_fmt', { w: S.wrong, t: c.total, d: diffName(S.diff) });
}
