import { FIGURE_PARTS, PART_LABEL } from './config.js?v=1.42';
import { DB } from './data.js?v=1.42';
import { P, figParts } from './state.js?v=1.42';
import { lang, tx, figName } from './i18n.js?v=1.42';
import { $, clear, el } from './ui.js?v=1.42';
import { figSvgEl } from './silhouettes.js?v=1.42';

export function partLabel(fig, index) {
  const p = fig.parts[index];
  if (!p) return '';
  return lang() === 'en' ? p.en : p.ru;
}

export function drawFig(containerId, fig, highlightIdx) {
  const box = $(containerId);
  if (!box) return;
  clear(box);
  const n = figParts(fig.id);
  box.appendChild(figSvgEl(fig.id, n, { size: 'lg', highlight: highlightIdx }));
  const labs = el('div', { class: 'fig-labs' });
  for (let i = 0; i < FIGURE_PARTS; i++) {
    const on = n > i;
    labs.appendChild(el('span', {
      class: 'fig-lab' + (on ? ' on' : '') + (i === highlightIdx ? ' new' : ''),
      text: partLabel(fig, i),
    }));
  }
  box.appendChild(labs);
}

export function renderFigPicker(onPick) {
  const root = $('fig-pick');
  clear(root);
  DB.figures.forEach((f) => {
    const n = Math.min(FIGURE_PARTS, P.figs[f.id] || 0);
    const unique = f.parts[4];
    const btn = el('button', { class: 'tcard figpick', type: 'button' });
    btn.appendChild(figSvgEl(f.id, n, { size: 'sm' }));
    btn.appendChild(el('div', { class: 'nm', text: figName(f.id) }));
    const dt = n >= FIGURE_PARTS
      ? tx('fig_done_badge')
      : tx('fig_pick_fmt', { p: lang() === 'en' ? unique.en : unique.ru, n });
    btn.appendChild(el('div', { class: 'dt', text: dt }));
    btn.addEventListener('click', () => onPick(f.id));
    root.appendChild(btn);
  });
}

export { PART_LABEL };
