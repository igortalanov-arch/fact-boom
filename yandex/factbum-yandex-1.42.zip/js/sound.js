/**
 * Sound FX for «Факт-бум. Кто ты?» (v1.32).
 *
 * Procedural WebAudio sounds (no audio files): soft UI click and a warm
 * result jingle (solo card / duel verdict). No music tracks.
 *
 * Platform compliance:
 *  - §1.3  sound stops when the page loses focus (visibilitychange / blur);
 *  - §4.7  sound stops while fullscreen ads (interstitial / rewarded) are on;
 *  - rec 6.2 mute toggle (persisted in prefs.sound).
 *
 * The AudioContext is created lazily on the first user gesture (click),
 * so browser autoplay policies are respected.
 */
import { prefs, savePrefs } from './state.js?v=1.42';
import { isPaused, hasPause, setPaused, onPauseChange } from './pause.js?v=1.42';

let ctx = null;
let master = null;



const counters = { click: 0, jingle: 0 };

function isMuted() {
  return prefs.sound === 'off';
}


function ensure() {
  if (!ctx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    try {
      ctx = new AC();
      ctx.addEventListener('statechange', applyPause);
      master = ctx.createGain();
      master.gain.value = isMuted() ? 0 : 0.9;
      master.connect(ctx.destination);
    } catch {
      ctx = null;
      return null;
    }
  }
  if (ctx.state === 'suspended' && !isPaused()) {
    try { ctx.resume().catch(() => {}); } catch { /* ignore */ }
  }
  return ctx;
}

function applyPause() {
  if (!ctx) return;
  try {
    if (isPaused() && ctx.state === 'running') ctx.suspend().catch(() => {});
    else if (!isPaused() && ctx.state === 'suspended') ctx.resume().catch(() => {});
  } catch { /* ignore */ }
}

/* ------------------------------ focus / ads ------------------------------ */

onPauseChange(applyPause);

export function pauseForAd() { setPaused('ad', true); }
export function resumeForAd() { setPaused('ad', false); }

/* --------------------------------- mute ---------------------------------- */

export function isSoundOn() {
  return !isMuted();
}

/** Toggle sound on/off; persists the preference. Returns new state (on=true). */
export function setSound(on) {
  prefs.sound = on ? 'on' : 'off';
  try { savePrefs(); } catch { /* ignore */ }
  if (master) {
    try { master.gain.value = on ? 0.9 : 0; } catch { /* ignore */ }
  }
  if (on) ensure();
  return on;
}

/* ------------------------------- synthesis ------------------------------- */

function voice(t, freq, dur, peak, type, harmonic) {
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(peak, t + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g);
  g.connect(master);
  o.start(t);
  o.stop(t + dur + 0.05);
  if (harmonic) {
    const o2 = ctx.createOscillator();
    const g2 = ctx.createGain();
    o2.type = 'sine';
    o2.frequency.setValueAtTime(freq * 2, t);
    g2.gain.setValueAtTime(0.0001, t);
    g2.gain.exponentialRampToValueAtTime(peak * 0.32, t + 0.010);
    g2.gain.exponentialRampToValueAtTime(0.0001, t + dur * 0.7);
    o2.connect(g2);
    g2.connect(master);
    o2.start(t);
    o2.stop(t + dur);
  }
}

/** Soft, short UI click — a warm wooden tick, quiet and non-irritating. */
export function click() {
  const c = ensure();
  if (!c || isMuted() || isPaused()) return;
  counters.click += 1;
  const t = ctx.currentTime + 0.001;
  voice(t, 660, 0.085, 0.16, 'triangle', true);
  voice(t + 0.028, 990, 0.06, 0.05, 'sine', false);
}

/**
 * Result jingle.
 *  kind 'solo' — gentle rising arpeggio with a soft pad (card & summary);
 *  kind 'duel'  — playful motif ending in a warm "ta-da" chord (verdict).
 */
export function jingle(kind) {
  const c = ensure();
  if (!c || isMuted() || isPaused()) return;
  counters.jingle += 1;
  const t0 = ctx.currentTime + 0.02;
  if (kind === 'duel') {
    [392.0, 523.25, 659.25, 783.99].forEach((f, i) => {
      voice(t0 + i * 0.09, f, 0.42, 0.19, 'triangle', true);
    });
    const tc = t0 + 0.42;
    [523.25, 659.25, 783.99].forEach((f) => voice(tc, f, 1.0, 0.14, 'triangle', true));
    [261.63, 329.63].forEach((f) => voice(tc, f, 1.2, 0.05, 'sine', false));
  } else {
    [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => {
      voice(t0 + [0, 0.10, 0.20, 0.34][i], f, i === 3 ? 0.95 : 0.55, 0.19, 'triangle', true);
    });
    [261.63, 329.63, 392.0].forEach((f) => voice(t0, f, 1.4, 0.045, 'sine', false));
  }
}

/** Read-only diagnostics for regression tests; no global cheat/play hooks. */
export function audioSnapshot() {
  return {
    ctx: ctx ? ctx.state : null, muted: isMuted(),
    pausedByAd: hasPause('ad') || hasPause('platform'),
    pausedByHidden: hasPause('hidden'), pausedByBlur: hasPause('blur'),
    clicks: counters.click, jingles: counters.jingle,
  };
}
