import {
  CARD_ARCHIVE_MAX, FIGURE_PARTS, LS_CARDS_PREFIX, LS_LANG, LS_SAVE_PREFIX, LS_SOUND, LS_THEME,
  LS_UID, OLD_FIG_SLUG, OLD_THEME_ID, SAVE_VERSION, YA_CARDS_KEY, YA_STORAGE_KEY,
} from './config.js?v=1.43';
import { legacyYandexPlayerID } from './yandex.js?v=1.43';
import { SyncStore } from './sync-store.js?v=1.43';
import { progressChange, changeHasData, cardWithoutImage, stableStringify } from './sync-model.js?v=1.43';
import { normalizeCardEntry } from './archive-data.js?v=1.43';
import { retainedRunOperations } from './checkpoint.js?v=1.43';

export const prefs = {
  lang: 'ru',
  theme: 'dark',
  sound: 'on',
  uid: '',
  user: null,
};

export let P = emptyProgress();
export let S = null;
export let Cards = [];
let hasLocalCards = false;
let sync = null;
let savedProgress = emptyProgress();
let savedCards = [];
let preserveLegacyArchive=false;
export let syncInfo = {state:'loading',local:true,pending:0};
const copy = x => JSON.parse(JSON.stringify(x));
export function syncSnapshot(){return sync ? sync.snapshot() : {...syncInfo};}
export function syncNow(){return sync ? sync.syncNow() : Promise.resolve(false);}
export function hasSavedOperation(id){return !!(sync&&sync.hasOperation(id));}
export function isOperationDurable(id){return !!(sync&&sync.operationDurable(id));}

export function setSession(next) {
  S = next;
  window.dispatchEvent(new Event('factbum:state'));
}

export function emptyProgress() {
  return {
    v: SAVE_VERSION,
    sessions: 0,
    duels: 0,
    duelWins: 0,
    duelDraws: 0,
    answered: 0,
    rand: 0,
    // 1.43: per-save entropy for the puzzle scatter (random layout, differs across saves).
    seed: (Math.random() * 0x7fffffff) | 0,
    figsV: {},
    figs: {},
    arch: {},
    themes: {},
    ach: {},
    best: null,
    used: {},
  };
}

function lsGet(key) {
  try { return localStorage.getItem(key); } catch { return null; }
}
function lsSet(key, val) {
  try { localStorage.setItem(key, val); return true; } catch { return false; }
}

export function loadPrefs() {
  prefs.lang = lsGet(LS_LANG) === 'en' ? 'en' : 'ru';
  prefs.theme = lsGet(LS_THEME) === 'light' ? 'light' : 'dark';
  prefs.sound = lsGet(LS_SOUND) === 'off' ? 'off' : 'on';
  if (!prefs.uid) prefs.uid = lsGet(LS_UID) || '';
}

export function savePrefs() {
  lsSet(LS_LANG, prefs.lang);
  lsSet(LS_THEME, prefs.theme);
  lsSet(LS_SOUND, prefs.sound);
  if (prefs.uid) lsSet(LS_UID, prefs.uid);
}

export function saveKey() {
  return LS_SAVE_PREFIX + (prefs.uid || 'local');
}

export function cardsKey() {
  return LS_CARDS_PREFIX + (prefs.uid || 'local');
}

export function loadCards() {
  Cards = [];
  hasLocalCards = false;
  const keys = [...(canReadGlobalLegacy()?['factbum_cards_v1']:[]), cardsKey()];
  for (const k of keys) {
    const raw = lsGet(k);
    if (!raw) continue;
    try {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr)) { Cards = arr; hasLocalCards = true; }
    } catch { /* next */ }
  }
}

function cardsWithoutImages() {
  return Cards.map(({ img, ...rest }) => rest);
}

function writeCardProjection() {
  if(preserveLegacyArchive)return;
  const saved=lsSet(cardsKey(),JSON.stringify(Cards)) || lsSet(cardsKey(),JSON.stringify(cardsWithoutImages()));
  if(!saved)window.dispatchEvent(new Event('factbum:storage-warning'));
  hasLocalCards=saved||hasLocalCards;
}
function cardChanges() {
  const old=new Map(savedCards.map(c=>[c.id,c]));
  const current=new Map(Cards.map(c=>[c.id,c]));
  const change={cards:{},deleted:{}};
  for(const [id,c] of current)if(stableStringify(old.get(id))!==stableStringify(c))change.cards[id]=cardWithoutImage(c);
  for(const id of old.keys())if(!current.has(id))change.deleted[id]=1;
  return change;
}
export function saveCards() {
  const change=cardChanges();
  savedCards=copy(Cards);if(!sync)writeCardProjection();
  if(sync&&changeHasData(change))return sync.enqueue(change);
  return Promise.resolve();
}

/** Run AFTER loadAll(): dictionary IDs are needed to recover pre-1.39 cards. */
export function migrateSavedCards() {
  let changed = false;
  Cards = Cards.map((entry, i) => {
    if (!entry || typeof entry !== 'object') { changed = true; return null; }
    const input = entry.id ? entry : { ...entry, id: 'legacy-' + (entry.ts || 0) + '-' + i };
    const next = normalizeCardEntry(input);
    if (next !== entry) changed = true;
    return next;
  }).filter(Boolean);
  if (changed) saveCards();
  return changed;
}

export function addSavedCard(entry, {defer=false}={}) {
  if (!entry) return;
  if (Cards.some((c) => c.id === entry.id)) return;
  Cards.unshift(entry);
  while (Cards.length > CARD_ARCHIVE_MAX) Cards.pop();
  if(!defer)saveCards();
}

export function removeSavedCard(id) {
  if (!id) return false;
  const next = Cards.filter((c) => c.id !== id);
  if (next.length === Cards.length) return false;
  Cards = next;
  saveCards();
  return true;
}

export function resetFigure(id) {
  if (!id || !P.figs || !P.figs[id]) return false;
  delete P.figs[id];
  // 1.43: re-assembly counter bumps the scatter seed — the next attempt scatters differently.
  P.figsV = P.figsV && typeof P.figsV === 'object' ? P.figsV : {};
  P.figsV[id] = (((P.figsV[id] | 0) + 1) >>> 0);
  save(true);
  return true;
}

function asThemeStat(v) {
  if (!v) return { quizzes: 0, questions: 0 };
  if (typeof v === 'number') return { quizzes: v, questions: v * 10 };
  return {
    quizzes: Number(v.quizzes) || 0,
    questions: Number(v.questions) || 0,
  };
}

function migrateUsed(used) {
  const out = {};
  if (!used || typeof used !== 'object') return out;
  for (const [k, val] of Object.entries(used)) {
    let scope = k;
    for (const [ru, id] of Object.entries(OLD_THEME_ID)) {
      if (scope.startsWith(ru + '|')) scope = id + scope.slice(ru.length);
    }
    scope = scope
      .replace('|Легко', '|easy')
      .replace('|Средне', '|medium')
      .replace('|Сложно', '|hard');
    const map = {};
    if (typeof val === 'string') val.split(',').filter(Boolean).forEach((id) => { map[id] = 1; });
    else if (Array.isArray(val)) val.forEach((id) => { map[id] = 1; });
    else if (val && typeof val === 'object') Object.assign(map, val);
    out[scope] = map;
  }
  return out;
}

function compactForSave() {
  const used = {};
  for (const [k, map] of Object.entries(P.used || {})) {
    const ids = Object.keys(map);
    used[k] = (ids.length > 240 ? ids.slice(-240) : ids).join(',');
  }
  return JSON.stringify({ ...P, used, _syncProjection:3 });
}

function migrateFigs(figs, fromV) {
  const out = {};
  if (!figs) return out;
  for (const [k, n] of Object.entries(figs)) {
    let id = OLD_FIG_SLUG[k] || k;
    if (id === 'robot') id = 'android'; // 1.43: explorer robot restyled as android
    let v = Math.max(0, Math.min(FIGURE_PARTS, Number(n) || 0));
    // 1.43: five old parts become a complete six-piece puzzle — earned stays earned.
    if ((fromV || 0) < 4 && v >= 5) v = FIGURE_PARTS;
    if (v) out[id] = v;
  }
  return out;
}

function migrateThemes(themes) {
  const out = {};
  if (!themes) return out;
  for (const [k, v] of Object.entries(themes)) {
    const id = OLD_THEME_ID[k] || k;
    if (id === 'random') continue;
    out[id] = asThemeStat(v);
  }
  return out;
}

export function normalizeProgress(raw) {
  const base = emptyProgress();
  if (!raw || typeof raw !== 'object') return base;
  const p = { ...base, ...raw };
  p.v = SAVE_VERSION;
  p.sessions = Number(p.sessions) || 0;
  p.duels = Number(p.duels) || 0;
  p.duelWins = Number(p.duelWins) || 0;
  p.duelDraws = Number(p.duelDraws) || 0;
  p.answered = Number(p.answered) || 0;
  p.rand = Number(p.rand) || 0;
  // 1.43: puzzle scatter seed; old saves get a fresh random one (persisted on next write).
  p.seed = Number(p.seed) > 0 ? (Number(p.seed) >>> 0) : ((Math.random() * 0x7fffffff) | 0);
  if (!p.figsV || typeof p.figsV !== 'object') p.figsV = {};
  p.figs = migrateFigs(p.figs, raw.v);
  p.arch = p.arch && typeof p.arch === 'object' ? p.arch : {};
  p.themes = migrateThemes(p.themes);
  p.ach = p.ach && typeof p.ach === 'object' ? p.ach : {};
  p.used = migrateUsed(p.used);
  if (p.best && p.best.theme) {
    p.best = {
      correct: Number(p.best.correct) || 0,
      theme: OLD_THEME_ID[p.best.theme] || p.best.theme,
    };
  }
  return p;
}

export function loadLocalProgress() {
  const keys = [saveKey(), 'factbum_v1_' + (prefs.uid || ''), ...(canReadGlobalLegacy()?['factbum_v1']:[])];
  for (const k of keys) {
    const raw = lsGet(k);
    if (!raw) continue;
    try { return normalizeProgress(JSON.parse(raw)); } catch { /* next */ }
  }
  return emptyProgress();
}

export function save(immediate = false, {operationId=null,includeCards=false}={}) {
  const change=progressChange(savedProgress,P,sync?.records||{});
  if(includeCards){Object.assign(change,cardChanges());savedCards=copy(Cards);}
  savedProgress=copy(P);
  window.dispatchEvent(new Event('factbum:state'));
  // The durable outbox is written synchronously by enqueue. Compatibility
  // projections are updated only AFTER the canonical v3 cache commits.
  return sync ? (changeHasData(change)?sync.enqueue(change,operationId):sync.flushLocal(false)) : Promise.resolve();
}

function canReadGlobalLegacy(){
  const owner=lsGet('factbum_legacy_owner');
  if(owner)return owner===prefs.uid||owner===prefs.legacyUid;
  if(prefs.previousUid&&prefs.previousUid!==prefs.uid&&prefs.previousUid!==prefs.legacyUid)return false;
  if(lsGet('factbum_v1')||lsGet('factbum_cards_v1'))lsSet('factbum_legacy_owner',prefs.uid);
  return true;
}

/** Preserve local progress when the SDK's modern ID differs from getID(). */
function migrateProfileKeys() {
  if (!prefs.uid) return;
  const marker = 'factbum_id_migrated_' + prefs.uid;
  if (lsGet(marker) === '1') return;
  // An already-created modern profile needs no deprecated SDK call.
  if (lsGet(saveKey()) !== null && lsGet(cardsKey()) !== null) { lsSet(marker, '1'); return; }
  const legacy = legacyYandexPlayerID();
  if (!legacy) return;
  const oldUID = 'ya-' + legacy;
  prefs.legacyUid=oldUID;
  if (oldUID === prefs.uid) { lsSet(marker, '1'); return; }
  let ok = true;
  for (const prefix of [LS_SAVE_PREFIX, LS_CARDS_PREFIX]) {
    const destination = prefix + prefs.uid;
    if (lsGet(destination) !== null) continue;
    const raw = lsGet(prefix + oldUID);
    if (raw === null) continue;
    try {
      const value = JSON.parse(raw);
      const valid = prefix === LS_CARDS_PREFIX ? Array.isArray(value) : value && typeof value === 'object' && !Array.isArray(value);
      if (valid && !lsSet(destination, raw)) ok = false;
    } catch { /* corrupt legacy data must not block startup */ }
  }
  // Keep the old keys untouched as a backup; do not copy another profile.
  if (ok) lsSet(marker, '1');
}

function decodeLegacyProgress(raw){
  try{return normalizeProgress(typeof raw==='string'?JSON.parse(raw):raw);}catch{return emptyProgress();}
}
function normalizedCards(raw){
  let rows;try{rows=typeof raw==='string'?JSON.parse(raw):raw;}catch{rows=[];}
  if(!Array.isArray(rows))return [];
  return rows.map((c,i)=>{
    if(!c||typeof c!=='object')return null;
    return normalizeCardEntry(c.id?c:{...c,id:'legacy-'+(c.ts||0)+'-'+i});
  }).filter(Boolean);
}
export async function hydrateProgress() {
  loadPrefs();migrateProfileKeys();
  const localProgress=loadLocalProgress();loadCards();
  const localCards=normalizedCards(Cards),hadCards=hasLocalCards;
  if(Cards.some(c=>c&&c.img)){
    const backup='factbum_archive_backup_'+prefs.uid;
    if(!lsGet(backup)&&!lsSet(backup,JSON.stringify(Cards)))preserveLegacyArchive=true;
  }
  P=localProgress;Cards=localCards;savedProgress=copy(P);savedCards=copy(Cards);
  if(sync)sync.close();
  sync=new SyncStore(prefs.uid,{
    retainOperations:()=>retainedRunOperations(prefs.uid),
    onChange:({progress,cards})=>{
      P=normalizeProgress(progress);Cards=normalizedCards(cards);
      savedProgress=copy(P);savedCards=copy(Cards);
      if(sync.status.local){lsSet(saveKey(),compactForSave());writeCardProjection();}
      window.dispatchEvent(new Event('factbum:state'));
    },
    onStatus:info=>{
      syncInfo=info;window.dispatchEvent(new Event('factbum:sync'));
      if(info.state==='storage-error')window.dispatchEvent(new Event('factbum:storage-warning'));
    },
  });
  await sync.init({localProgress,localCards,hasLocalCards:hadCards,localProjection:localProgress._syncProjection===3,legacyProgress:decodeLegacyProgress,legacyCards:normalizedCards});
  return P;
}

export function themeStat(id) {
  return asThemeStat(P.themes[id]);
}

export function addThemeQuestions(themeId, n) {
  const cur = themeStat(themeId);
  P.themes[themeId] = { quizzes: cur.quizzes, questions: cur.questions + n };
}

export function addThemeQuiz(themeId) {
  const cur = themeStat(themeId);
  P.themes[themeId] = { quizzes: cur.quizzes + 1, questions: cur.questions };
}

export function unlockAch(id) {
  if (!P.ach[id]) {
    P.ach[id] = Date.now();
    return true;
  }
  return false;
}

export function figParts(id) {
  return Math.max(0, Math.min(FIGURE_PARTS, P.figs[id] || 0));
}
