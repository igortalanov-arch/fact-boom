import { VERSION } from './config.js?v=1.43';
import { DB, locName } from './data.js?v=1.43';
import { prefs, savePrefs } from './state.js?v=1.43';

const HTML_KEYS = new Set([
  'start_sub', 'help_n_txt', 'help_th_txt', 'help_diff_txt', 'help_norep_txt',
  'help_rank_txt', 'help_arch_txt', 'help_fig_txt', 'help_acc_txt', 'help_facts_txt',
  'help_mood_txt', 'help_duel_txt', 'help_rand_txt', 'random_mood', 'rank_you_fmt',
  'theme_sub_duel',
]);

export const STR = {
  ru: {
    checkpoint_changed_short:'Вопросы сохранённой партии обновились.',
    checkpoint_invalid_short:'Сохранённую партию не удалось восстановить.',
    checkpoint_pending_short:'Результат ожидает сохранения.',
    help_resume_title:'Продолжение партии',
    help_resume_txt:'Во время партии на этом устройстве сохраняются вопрос, порядок вариантов, ответы и остаток времени. На главном экране появится «Продолжить партию». При выборе нового квиза можно удалить прежнюю незавершённую партию; завершённый прогресс останется. Если вопросы обновились, старая партия не воспроизводится с новыми ответами. Состояние не переносится на другое устройство.',
    checkpoint_continue: "Продолжить партию",
    checkpoint_new: "Новый квиз",
    checkpoint_solo: "Соло",
    checkpoint_context: "{mode} · {theme} · вопрос {n}/{total} · на устройстве",
    checkpoint_exit: "Вернуться в меню? Незавершённая партия сохранена на этом устройстве — её можно продолжить.",
    checkpoint_menu: "В меню",
    checkpoint_discard: "Начать новый квиз вместо сохранённой партии? Завершённый прогресс и коллекция останутся.",
    checkpoint_cancel: "Отмена",
    checkpoint_ok: "Понятно",
    checkpoint_busy: "Эта партия сейчас открыта в другой вкладке. Продолжите её там или начните отдельный новый квиз.",
    checkpoint_changed: "Вопросы сохранённой партии были обновлены. Начните новый квиз; завершённый прогресс и коллекция не изменились.",
    checkpoint_invalid: "Сохранённую партию не удалось восстановить. Можно начать новый квиз; завершённый прогресс не затронут.",
    checkpoint_pending: "Результат ещё не удалось надёжно сохранить. Повторите попытку перед новой игрой.",
    checkpoint_retry: "Повторить сохранение",
    checkpoint_saved: "Результат этой партии уже учтён.",

    retry_loading:'Повторить загрузку', sync_guest:'Гость', player_account:'Игрок Яндекса', sync_saved:'сохранено в облаке', sync_pending:'синхронизация…', sync_local:'сохранено на устройстве', sync_quota:'облако заполнено, копия на устройстве', sync_error:'не удалось сохранить',
    logo: 'ФАКТ-БУМ', h1: 'Кто ты?',
    start_sub: 'Викторина из 10 фактов-вопросов (около 5–10 минут, зависит от сложности).<br>Собери коллекционную фигурку — в любом квизе — узнай свой архетип и получи полезные советы на каждый день.',
    btn_play: 'Играть', btn_duel: 'Две команды', btn_museum: 'Музей', btn_help: 'Справка',
    stats_first: 'Первый квиз займёт около 5 минут',
    stats_fmt: 'Соло-квизов: {s} · дуэлей: {d} · вопросов: {a}',
    player_fmt: 'Игрок: {u}',
    player_ya: '{n} · {u}',
    player_guest: 'Гость · {u}',
    btn_reward: 'Случайный фрагмент за просмотр рекламы',
    sound_on: 'Звук включён',
    sound_off: 'Звук выключен',
    mute_sound: 'Выключить звук', unmute_sound: 'Включить звук',
    theme_light: 'Светлая тема', theme_dark: 'Тёмная тема',
    nav_home: 'В главное меню', nav_exit_quiz: 'Выйти из квиза',
    choose_answer: 'Выберите ответ', correct_answer: 'Верный ответ',
    quiz_review: 'Ответы', quiz_fact: 'Вау-факт',
    timer_label: 'Время на вопрос', timer_seconds: '{n} с', timer_unlimited: 'Без спешки',
    legacy_card_title: 'Карточка прошлой игры', legacy_card_note: 'Часть данных старой карточки недоступна.',
    result_card_title: 'Результат квиза', share_difficulty: 'Сложность: {d}', share_points: '{p} очков за сессию',
    save_warning: 'Не удалось сохранить на устройстве. Проверьте свободное место и настройки браузера.',
    reward_busy: 'Загружаем рекламу…',
    reward_got: 'Новый фрагмент: {n}',
    reward_none: 'Реклама не показана — попробуйте ещё раз.',
    reward_all: 'Все фигурки уже собраны!',
    version_fmt: 'версия {v}',
    help_title: 'Справка', help_sub: 'Как устроен «Факт-бум» — за минуту. Обещаем, не заскучаете.',
    help_n_title: 'Суть',
    help_n_txt: '10 вопросов про удивительные факты — и около пяти минут жизни. В соло игра определяет, кто из 10 архетипов вы, присваивает звание и добавляет кусочек пазла к выбранной фигурке. Стресса нет: за ошибки и таймауты ничего не списывают — мир добрый.',
    help_th_title: 'Темы',
    help_th_txt: 'Семь тем и карточка Рандом, где вопросы берутся из всех тем сразу. Сейчас в игре {n} вопросов; копилка растёт, в планах добавление пула вопросов.',
    help_mood_title: 'Настроение',
    help_mood_txt: 'У каждого вопроса есть одно или несколько настроений: вдумчивое, загадочное, весёлое, мимолётное, философское. Выбранное настроение отбирает подходящие факты. Если таких мало — игра мягко расширит пул, чтобы набрать десятку.',
    help_diff_title: 'Сложность и время',
    help_diff_txt: '<b>Легко</b> — простые факты (сложность 1–2), на вопрос 60 секунд.<br><b>Средне</b> — вперемешку (2–4), 40 секунд.<br><b>Сложно</b> — для знатоков (3–5), 20 секунд.<br>Таймер можно пережить: время вышло — игра не накажет, а просто будет ждать вашего выбора. Тихо и без упреков.',
    help_norep_title: 'Без повторов',
    help_norep_txt: 'Вопросы отмечаются после полного прохождения квиза в выбранной комбинации темы, сложности и настроения. При смене настроек или исчерпании подходящего пула знакомые вопросы могут вернуться. Существенно исправленная версия вопроса считается новой.',
    help_rand_title: 'Рандом',
    help_rand_txt: 'Рандом-квизы считаются отдельно от тематических. В профиле музея темы показаны долями: сколько вопросов какой темы вам уже встретилось (включая рандом). Один рандомный вопрос = 1/10 доли темы, не «целый квиз».',
    help_rank_title: 'Звания',
    help_rank_txt: 'По числу правильных из десяти (сложность не учитывается). Цель — Легенда.',
    help_arch_title: 'Архетипы',
    archetype_note:'Игровой портрет подборки — не тест личности и не медицинская оценка.',
    help_arch_txt: 'Каждый вопрос связан с 1–2 архетипами. Любой ответ — верный или нет — даёт +1 очко этим архетипам: любопытство считается. Ошибки не отнимают очки архетипа. Это игровой портрет подборки, а не психологическая или медицинская диагностика.<br><br>Десять архетипов: Эмпат, Исследователь, Изобретатель, Мечтатель, Детектив, Философ, Интуит, Весельчак, Наставник, Новатор. Плюс по окончании игры получаете один интересный совет в соответствии с вашей игрой и уровнем.',
    help_fig_title: 'Фигурки',
    help_fig_txt: 'Десять коллекционных фигурок. Любую можно собирать в любом квизе — астронавта в «Музыке», скрипку в «Истории». Один соло-квиз = один кусочек пазла из шести: он ложится на поле случайно, хоть вверх ногами, и до последнего неясно, кто собирается. Шесть квизов — кусочки слетаются вместе, и фигурка оживает в цвете. В дуэли фигурки не выбираются и не растут.',
    help_duel_title: 'Две команды',
    help_duel_txt: 'Каждая команда отвечает на 10 вопросов по очереди (20 фактов на партию). Побеждает та, у кого больше верных ответов. Имена можно взять из ста предложений или придумать свои. Ни архетипа, ни фигурки — только счёт и честь.',
    help_acc_title: 'Ваш профиль',
    help_acc_txt: 'Прогресс сохраняется на устройстве и синхронизируется с доступным профилем Яндекс Игр. При потере связи изменения остаются в локальной очереди. Статус сохранения указан на главном экране. <a href="privacy.html">Сведения о данных и конфиденциальности</a>.',
    help_facts_title: 'Про факты',
    help_facts_txt: 'Вопросы охватывают науку, природу, историю вещей и искусство. Формулировки, цифры и даты могут уточняться при обновлениях.',
    help_footer: '«Факт-бум. Кто ты?» · Игорь Таланов · 2026 · v{v}',
    help_back: 'Всё понятно',
    theme_title: 'Выбери тему',
    theme_sub: '10 вопросов → кусочек пазла + карточка архетипа',
    theme_sub_duel: 'Каждая команда получит по 10 вопросов · фигурки отдыхают',
    back: 'Назад', cancel: 'Отмена',
    mood_diff_title: 'Насколько сложно?',
    mood_mood_title: 'Какое настроение?',
    mood_hint: 'Сначала выбери сложность и настроение — тогда кнопка старта станет активной.',
    start_hint_fmt: 'сложность: {d} · настроение: {m} — нажми «Начать»',
    start_hint_duel: 'сложность: {d} · настроение: {m} — нажми «Начать дуэль»',
    fig_title: 'Кого соберём?',
    fig_sub: 'Любую фигурку — в любом квизе. За соло-квиз — кусочек пазла. 6 квизов — фигурка оживает.',
    fig_progress_fmt: 'собрано {n}/6',
    fig_done_badge: 'уже в музее',
    fact_tag: 'ВАУ-ФАКТ',
    v_ok: 'Верно!',
    v_time: 'Время вышло! Верный ответ подсвечен',
    v_bad: 'Не угадали — теперь знаете!',
    chip_cur: 'любопытство +1',
    next: 'Дальше →', final: 'Финал →',
    exit_confirm: 'Выйти из квиза? Ответы этой сессии не запишутся, вопросы останутся в колоде.',
    exit_yes: 'Выйти', exit_no: 'Остаться',
    count_fmt: '{n} из {t}',
    figchip_fmt: 'Фигурка: {p}/6 · {d}',
    duelchip_fmt: '{a} {sa} : {sb} {b}',
    turn_fmt: 'Ход: {n}',
    theme_card_fmt: '{cnt} фактов · квизов: {n}',
    random_name: 'Рандом',
    random_card_fmt: 'из всех тем · рандом-квизов: {n}',
    random_mood: 'Рандом: <b>вопросы из всех тем сразу</b>',
    part_added_fmt: 'Кусочек {n}/6 добавлен!',
    part_done: 'Фигурка собрана!',
    part_already: 'Фигурка уже в музее',
    part_next: 'Моя карточка →',
    part_hint_done_fmt: 'Экспонат музея: «{n}». Полная фигурка на полке.',
    part_hint_fmt: 'До полной фигурки ещё {n} соло-квиз(ов). Тему можно менять — фигурка общая.',
    part_hint_already: 'Можно играть дальше ради архетипа и фактов — новая часть не выдаётся.',
    rank_line_fmt: 'Ваш результат: {c} из 10',
    rank_you_fmt: 'Вы — <b>{r}</b>! {e}',
    score_of10_fmt: '{c} из 10',
    sovety_title: 'Совет',
    card_cur_fmt: 'Ошибок: {w}/10 · очки любопытства: {t} · сложность: {d}',
    btn_share: '💾 Сохранить карточку результата',
    save_ok: 'Карточка сохранена в галерею устройства и в музей карточек.',
    save_fail: 'Не удалось сохранить карточку.',
    btn_card_museum: 'В музей',
    btn_newquiz: 'Новый квиз',
    museum_title: 'Музей фигурок',
    museum_sub: '10 фигурок. Нажми на фигурку — увидеть крупно в текущей сборке.',
    museum_tab_figs: 'Фигурки',
    museum_tab_cards: 'Карточки',
    card_saved: 'Карточка уже в музее карточек.',
    museum_cards_title: 'Музей карточек',
    museum_cards_sub: 'Последние 24 карточки результата. Нажми — открыть крупно.',
    museum_cards_empty: 'Пока пусто. Пройдите квиз — карточка попадёт в архив сама.',
    museum_done: 'собрана', museum_wip: 'в сборке',
    museum_zoom_close: 'Закрыть',
    museum_zoom_hint: 'Нажми, чтобы увеличить',
    museum_del: 'Удалить',
    museum_del_fig: 'Удалить фигурку',
    museum_del_card: 'Удалить карточку',
    museum_del_fig_confirm: 'Сбросить сборку «{n}»? Прогресс обнулится — фигурку можно собирать снова.',
    museum_del_card_confirm: 'Удалить эту карточку из музея? Это действие нельзя отменить.',
    museum_profile: 'Доли тем (по вопросам)',
    museum_profile_sub: 'Рандом идёт в доли, не в «квизы темы». Тематических квизов: см. числа справа.',
    museum_theme_meta: '{q} вопр. · {z} квизов',
    museum_rand: 'Рандом-квизов: {n}',
    museum_best: 'Лучшее звание',
    museum_best_sub_fmt: 'квиз: {t} · цель — Легенда (9–10/10)',
    museum_ach: 'Достижения', btn_home: 'На главную',
    ach1: 'Первый кусочек', ach2: 'Первая фигурка', ach3: 'Коллекционер — 3 фигурки',
    ach4: 'Эрудит — 100 вопросов', ach5: 'Путешественник — 5 тем', ach6: 'Легенда — 9+ из 10',
    pn_collect: 'Собираем фигурку', pn_theme: 'Тема квиза', pn_records: 'Рекорды',
    pn_ach: 'Достижения', pn_quizzes: 'Квизов сыграно', pn_answered: 'Ответов дано',
    pn_parts: 'Кусочков собрано', pn_best: 'Лучший результат', pn_toparch: 'Ведущий архетип',
    pn_part_hint: 'Кусочек пазла — за каждый пройденный квиз',
    card_home: 'Вернуться в главное меню', pn_teams: 'Команды', pn_score: 'Счёт', pn_turn: 'Ходит',
    pn_visit: 'За этот заход', pn_runs: 'Дуэлей начато',
    generic_title: 'Любопытный универсал', noun_random: 'широкого круга',
    card_arch_balanced: 'архетипы сбалансированы', card_theme_fmt: '· квиз: {t}',
    card_shadow_fmt: '…и немного {a}, {p}%',
    share_logo: 'ФАКТ-БУМ',
    share_generic: 'вы примерили все шляпы — и это здорово',
    share_rank: 'Вы — {r}! {e}  ({c} из 10)',
    share_meta: 'Квиз: {t} · сложность: {d} · {p} очков за сессию',
    share_meta_l1: 'Квиз: {t}',
    share_meta_l2: 'Сложность: {d} · {p} очков за сессию',
    share_title: 'Факт-бум. Кто ты?',
    share_tag: '10 фактов за 5 минут · собери фигурку · найди архетип',
    share_vk: '',
    share_duel: '{a} {sa} : {sb} {b}',
    teams_title: 'Как зовут команды?',
    teams_sub: 'Сто шуточных имён в шляпе. Можно поменять или написать свои.',
    teams_reroll: 'Другие имена',
    teams_swap: 'Поменять местами',
    teams_go: 'Дальше — тема',
    teams_a: 'Команда А',
    teams_b: 'Команда Б',
    duel_title: 'Дуэль',
    duel_win: 'Победа: {n}!',
    duel_draw: 'Ничья! Честь поровну.',
    duel_score: '{a} {sa}  —  {sb} {b}',
    duel_again: 'Ещё дуэль',
    loading: 'Собираем факты…',
    load_err: 'Не удалось загрузить данные. Обновите страницу.',
    btn_start: 'Начать',
    btn_start_duel: 'Начать дуэль',
    help_keys_title: 'Клавиатура и экраны',
    help_keys_txt: 'Игра подстраивается под телефон, планшет и компьютер. Мышью и пальцем — как обычно. С клавиатуры: <b>1–5</b> — выбрать ответ, <b>Enter</b> — дальше / переход хода, <b>Esc</b> — закрыть окно или выйти из квиза. Стрелка вверху возвращает на предыдущий шаг; во время квиза — в меню с подтверждением. После ответа можно переключаться между фактом и вариантами ответа.',
    handoff_btn: 'Передать ход →', handoff_go: 'Поехали!',
    handoff_next: 'Сейчас играют:\n{n}',
    handoff_prev: 'Ход команды «{n}» закончен',
  },
  en: {
    checkpoint_changed_short:'The saved round contains updated questions.',
    checkpoint_invalid_short:'The saved round could not be restored.',
    checkpoint_pending_short:'The result is waiting to be saved.',
    help_resume_title:'Continuing a round',
    help_resume_txt:'During a round, this device saves the question, option order, answers and remaining time. The main screen offers Continue round. Starting a new quiz can discard the unfinished round without deleting completed progress. If its questions have been updated, the old round is not replayed with new answers. The checkpoint does not move to another device.',
    checkpoint_continue: "Continue round",
    checkpoint_new: "New quiz",
    checkpoint_solo: "Solo",
    checkpoint_context: "{mode} · {theme} · question {n}/{total} · on this device",
    checkpoint_exit: "Return to the menu? This unfinished round is saved on this device and can be continued.",
    checkpoint_menu: "Main menu",
    checkpoint_discard: "Start a new quiz instead of the saved round? Completed progress and your collection will remain.",
    checkpoint_cancel: "Cancel",
    checkpoint_ok: "Got it",
    checkpoint_busy: "This round is open in another tab. Continue it there or start a separate new quiz.",
    checkpoint_changed: "The questions in this saved round have been updated. Start a new quiz; completed progress and your collection are unchanged.",
    checkpoint_invalid: "This saved round could not be restored. You can start a new quiz; completed progress is unaffected.",
    checkpoint_pending: "The result has not yet been saved reliably. Please retry before starting another game.",
    checkpoint_retry: "Retry saving",
    checkpoint_saved: "This round’s result has already been recorded.",

    retry_loading:'Retry loading', sync_guest:'Guest', player_account:'Yandex player', sync_saved:'saved to cloud', sync_pending:'syncing…', sync_local:'saved on this device', sync_quota:'cloud full, saved on this device', sync_error:'could not save',
    logo: 'FACT-BOOM', h1: 'Who are you?',
    start_sub: '10 surprising questions in about 5–10 minutes.<br>Collect a figure, discover your quiz archetype and take away an everyday tip.',
    btn_play: 'Play', btn_duel: 'Two teams', btn_museum: 'Museum', btn_help: 'Help',
    stats_first: 'Your first quiz takes about 5 minutes',
    stats_fmt: 'Solo quizzes: {s} · duels: {d} · questions: {a}',
    player_fmt: 'Player: {u}',
    player_ya: '{n} · {u}',
    player_guest: 'Guest · {u}',
    btn_reward: 'Watch ad — get a random figure part',
    sound_on: 'Sound on',
    sound_off: 'Sound off',
    mute_sound: 'Mute sound', unmute_sound: 'Unmute sound',
    theme_light: 'Light theme', theme_dark: 'Dark theme',
    nav_home: 'Main menu', nav_exit_quiz: 'Leave the quiz',
    choose_answer: 'Choose an answer', correct_answer: 'Correct answer',
    quiz_review: 'Answers', quiz_fact: 'Wow fact',
    timer_label: 'Time per question', timer_seconds: '{n} s', timer_unlimited: 'Take your time',
    legacy_card_title: 'Past quiz card', legacy_card_note: 'Some details of this older card are unavailable.',
    result_card_title: 'Quiz result', share_difficulty: 'Difficulty: {d}', share_points: '{p} points this session',
    save_warning: 'Could not save on this device. Check free storage and browser settings.',
    reward_busy: 'Loading the ad…',
    reward_got: 'New part: {n}',
    reward_none: 'Ad not shown — try again.',
    reward_all: 'All figures are complete!',
    version_fmt: 'version {v}',
    help_title: 'Help', help_sub: 'How Fact-Boom works — in one minute. Promise: no boredom.',
    help_n_title: 'The idea',
    help_n_txt: '10 questions about amazing facts — about five minutes of your life. Solo mode figures out which of 10 archetypes you are, awards a rank and adds a puzzle piece to the figure you picked. No stress: mistakes and timeouts cost nothing.',
    help_th_title: 'Themes',
    help_th_txt: 'Seven themes plus the Random card, drawing from every theme at once. The game has {n} questions; the pool grows, and more questions are planned.',
    help_mood_title: 'Mood',
    help_mood_txt: 'Every question has one or more moods: thoughtful, mysterious, fun, light, philosophical. Your pick filters the deck. If there are not enough matching facts, the game gently widens the pool so you still get ten.',
    help_diff_title: 'Difficulty and time',
    help_diff_txt: '<b>Easy</b> — simple facts (1–2), 60 seconds.<br><b>Medium</b> — mixed (2–4), 40 seconds.<br><b>Hard</b> — for connoisseurs (3–5), 20 seconds.<br>The timer is kind: when it runs out, the game will not punish you — it simply waits for your choice. Quiet, no scolding.',
    help_norep_title: 'No repeats',
    help_norep_txt: 'Questions are marked seen after a completed quiz for the selected theme, difficulty and mood. Changing these settings or exhausting the matching pool may bring familiar questions back. A substantially revised question is treated as new.',
    help_rand_title: 'Random',
    help_rand_txt: 'Random quizzes are counted separately from themed ones. The museum profile shows shares: how many questions of each theme you have met (Random included). One random question = a 1/10 share of that theme, not a full quiz.',
    help_rank_title: 'Ranks',
    help_rank_txt: 'By correct answers out of ten (difficulty does not matter):<br>🌱 Novice — 0 · 📖 Apprentice — 1–2 · 🎓 Student — 3–4 · 💡 Expert — 5–6 · 🔬 Master — 7–8 · 🏆 Legend — 9–10. The goal is Legend.',
    help_arch_title: 'Archetypes',
    archetype_note:'A playful portrait of the question set, not a personality test or medical assessment.',
    help_arch_txt: 'Every question is tied to 1–2 archetypes. Any answer — right or wrong — gives +1 to those archetypes: curiosity counts. Mistakes are tracked separately and do not subtract archetype points. This is a playful portrait of the question set, not a psychological or medical assessment.<br><br>Ten archetypes: Empath, Explorer, Inventor, Dreamer, Detective, Philosopher, Intuitive, Jester, Mentor, Innovator. Plus, at the end of the game you get one interesting tip according to your play and level.',
    help_fig_title: 'Figures',
    help_fig_txt: 'Ten collectible figures. Any figure can be collected in any quiz — an astronaut during Music, a violin during History. One solo quiz = one of six puzzle pieces: it lands scattered, even upside down, so the picture stays a mystery until the end. Six quizzes — the pieces fly together and the figure bursts into colour. Duels do not pick or grow figures.',
    help_duel_title: 'Two teams',
    help_duel_txt: 'Each team answers 10 questions in turn (20 facts a match). The team with more correct answers wins. Pick from a hundred joke names or type your own. No archetype, no figure — just the score.',
    help_acc_title: 'Your profile',
    help_acc_txt: 'Progress is saved on this device and synchronised with an available Yandex Games profile. If the connection is lost, changes remain in a local queue. The main screen shows the save status. <a href="privacy.html">Data and privacy information</a>.',
    help_facts_title: 'About the facts',
    help_facts_txt: 'Questions cover science, nature, the history of everyday things and the arts. Wording, numbers and dates may be refined in updates.',
    help_footer: '"Fact-Boom. Who are you?" · Igor Talanov · 2026 · v{v}',
    help_back: 'Got it',
    theme_title: 'Choose a theme',
    theme_sub: '10 questions → 1 puzzle piece + archetype card',
    theme_sub_duel: 'Each team gets 10 questions · figures sit this one out',
    back: 'Back', cancel: 'Cancel',
    mood_diff_title: 'How hard?',
    mood_mood_title: 'What mood?',
    mood_hint: 'Pick difficulty and mood first — then the start button turns on.',
    start_hint_fmt: 'difficulty: {d} · mood: {m} — tap Start',
    start_hint_duel: 'difficulty: {d} · mood: {m} — tap Start the duel',
    fig_title: 'Who will we collect?',
    fig_sub: 'Any figure, any quiz. One puzzle piece per solo quiz. 6 quizzes — it comes alive.',
    fig_progress_fmt: 'collected {n}/6',
    fig_done_badge: 'already in the museum',
    fact_tag: 'WOW FACT',
    v_ok: 'Correct!',
    v_time: "Time's up! The right answer is highlighted",
    v_bad: 'Not quite — now you know!',
    chip_cur: 'curiosity +1',
    next: 'Next →', final: 'Finish →',
    exit_confirm: "Leave the quiz? This session won't be saved, and the questions stay in the deck.",
    exit_yes: 'Leave', exit_no: 'Stay',
    count_fmt: '{n} of {t}',
    figchip_fmt: 'Figure: {p}/6 · {d}',
    duelchip_fmt: '{a} {sa} : {sb} {b}',
    turn_fmt: 'Turn: {n}',
    theme_card_fmt: '{cnt} facts · quizzes: {n}',
    random_name: 'Random',
    random_card_fmt: 'from all themes · random quizzes: {n}',
    random_mood: 'Random: <b>questions from every theme</b>',
    part_added_fmt: 'Piece {n}/6 added!',
    part_done: 'Figure complete!',
    part_already: 'Figure already in the museum',
    part_next: 'My card →',
    part_hint_done_fmt: 'Museum exhibit: “{n}”. The complete figure is on the shelf.',
    part_hint_fmt: '{n} more solo quiz(es) to finish the figure. Switch themes freely — the figure is shared.',
    part_hint_already: 'Keep playing for the archetype and the facts — no extra part is granted.',
    rank_line_fmt: 'Your score: {c} of 10',
    rank_you_fmt: 'Your rank: <b>{r}</b> {e}',
    score_of10_fmt: '{c} of 10',
    sovety_title: 'A tip',
    card_cur_fmt: 'Mistakes: {w}/10 · curiosity points: {t} · difficulty: {d}',
    btn_share: '💾 Save result card',
    save_ok: 'Card saved to your device gallery and to the card museum.',
    save_fail: 'Could not save the card.',
    btn_card_museum: 'To the museum',
    btn_newquiz: 'New quiz',
    museum_title: 'Figure museum',
    museum_sub: '10 figures. Tap a figure to see it large, in its current state.',
    museum_tab_figs: 'Figures',
    museum_tab_cards: 'Cards',
    card_saved: 'The card is already in the card museum.',
    museum_cards_title: 'Card museum',
    museum_cards_sub: 'Your latest 24 result cards. Tap to enlarge.',
    museum_cards_empty: 'Empty for now. Finish a quiz — the card is archived automatically.',
    museum_done: 'complete', museum_wip: 'in progress',
    museum_zoom_close: 'Close',
    museum_zoom_hint: 'Tap to enlarge',
    museum_del: 'Delete',
    museum_del_fig: 'Delete figure',
    museum_del_card: 'Delete card',
    museum_del_fig_confirm: 'Reset the “{n}” build? Progress will zero out — you can collect it again.',
    museum_del_card_confirm: 'Delete this card from the museum? This cannot be undone.',
    museum_profile: 'Theme shares (by questions)',
    museum_profile_sub: 'Random feeds shares, not “theme quizzes”. Themed quiz counts are on the right.',
    museum_theme_meta: '{q} q · {z} quizzes',
    museum_rand: 'Random quizzes: {n}',
    museum_best: 'Best rank',
    museum_best_sub_fmt: 'quiz: {t} · goal — Legend (9–10/10)',
    museum_ach: 'Achievements', btn_home: 'Home',
    ach1: 'First piece', ach2: 'First figure', ach3: 'Collector — 3 figures',
    ach4: 'Polymath — 100 questions', ach5: 'Traveler — 5 themes', ach6: 'Legend — 9+ of 10',
    pn_collect: 'Collecting figure', pn_theme: 'Quiz theme', pn_records: 'Records',
    pn_ach: 'Achievements', pn_quizzes: 'Quizzes played', pn_answered: 'Answers given',
    pn_parts: 'Pieces collected', pn_best: 'Best score', pn_toparch: 'Top archetype',
    pn_part_hint: 'A puzzle piece for each completed quiz',
    card_home: 'Back to main menu', pn_teams: 'Teams', pn_score: 'Score', pn_turn: 'To move',
    pn_visit: 'This visit', pn_runs: 'Duels started',
    generic_title: 'Curious Polymath', noun_random: 'of many worlds',
    card_arch_balanced: 'archetypes are balanced', card_theme_fmt: '· quiz: {t}',
    card_shadow_fmt: '…a bit of {a} too, {p}%',
    share_logo: 'FACT-BOOM',
    share_generic: 'you tried on all the hats — and that is great',
    share_rank: 'Rank: {r} {e} · {c} of 10',
    share_meta: 'Quiz: {t} · difficulty: {d} · {p} points this session',
    share_meta_l1: 'Quiz: {t}',
    share_meta_l2: 'Difficulty: {d} · {p} points this session',
    share_title: 'Fact-Boom. Who are you?',
    share_tag: '10 facts in 5 minutes · collect a figure · find an archetype',
    share_vk: '',
    share_duel: '{a} {sa} : {sb} {b}',
    teams_title: 'Name the teams',
    teams_sub: 'A hundred joke names in the hat. Reroll or type your own.',
    teams_reroll: 'Other names',
    teams_swap: 'Swap',
    teams_go: 'Next — theme',
    teams_a: 'Team A',
    teams_b: 'Team B',
    duel_title: 'Duel',
    duel_win: 'Winner: {n}!',
    duel_draw: 'Draw! Honour split evenly.',
    duel_score: '{a} {sa}  —  {sb} {b}',
    duel_again: 'Rematch',
    loading: 'Gathering facts…',
    load_err: 'Could not load data. Please refresh.',
    btn_start: 'Start',
    btn_start_duel: 'Start the duel',
    help_keys_title: 'Keyboard and screens',
    help_keys_txt: 'The game fits phones, tablets and desktops. Mouse and touch work as usual. Keyboard: <b>1–5</b> pick an answer, <b>Enter</b> next / hand over, <b>Esc</b> closes a dialog or leaves the quiz. The top arrow goes back one step; during a quiz it asks before returning to the menu. After answering, switch between the fact and the answer options.',
    handoff_btn: 'Pass the turn →', handoff_go: 'Let’s go!',
    handoff_next: 'Now playing:\n{n}',
    handoff_prev: 'Team “{n}” is done',
  },
};

export function lang() {
  return prefs.lang === 'en' ? 'en' : 'ru';
}

export function fmt(s, o = {}) {
  return String(s).replace(/\{(\w+)\}/g, (m, k) => (k in o ? String(o[k]) : m));
}

export function tx(k, o) {
  const s = (STR[lang()] && STR[lang()][k]) || STR.ru[k] || k;
  return o ? fmt(s, o) : s;
}

export function themeName(id) {
  if (!id || id === 'random') return tx('random_name');
  return locName(DB.themes.find((t) => t.id === id), lang());
}

export function moodName(id) {
  return locName(DB.moods.find((m) => m.id === id), lang());
}

export function diffName(d) {
  if (!d) return '';
  const row = typeof d === 'string' ? DB.diffs.find((x) => x.id === d || x.ru === d || x.en === d) : d;
  return row ? (lang() === 'en' ? row.en : row.ru) : '';
}

export function teamName(t) {
  if (!t) return '';
  if (t.defaultTeam) return tx(t.defaultTeam === 'a' ? 'teams_a' : 'teams_b');
  const row = t.id && DB.teams.find((x) => x.id === t.id);
  return row ? locName(row, lang()) : (t.name || '');
}

export function archName(id) {
  return locName(DB.archetypes.find((a) => a.id === id), lang());
}

export function figName(id) {
  return locName(DB.figures.find((f) => f.id === id), lang());
}

export function rankName(r) {
  return r ? (lang() === 'en' ? r.en : r.ru) : '';
}

export function applyStaticI18n() {
  document.documentElement.setAttribute('lang', lang());
  document.title = lang() === 'en'
    ? `Fact-Boom. Who are you? · v${VERSION}`
    : `Факт-бум. Кто ты? · v${VERSION}`;
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const key = el.getAttribute('data-i18n');
    let v = STR[lang()][key];
    if (v === undefined) return;
    if (key === 'help_th_txt' || key === 'help_norep_txt') v = fmt(v, { n: DB.questionTotal });
    if (key === 'help_footer') v = fmt(v, { v: VERSION });
    if (HTML_KEYS.has(key)) el.innerHTML = v;
    else el.textContent = v;
  });
  document.querySelectorAll('[data-i18n-aria]').forEach((el) => {
    const key = el.getAttribute('data-i18n-aria');
    const v = STR[lang()][key] || STR.ru[key];
    if (v) el.setAttribute('aria-label', String(v).replace(/<[^>]+>/g, ''));
  });
}

export function setLang(l) {
  prefs.lang = l === 'en' ? 'en' : 'ru';
  savePrefs();
  window.dispatchEvent(new Event('factbum:state'));
}

export function setColorTheme(t) {
  prefs.theme = t === 'light' ? 'light' : 'dark';
  savePrefs();
  document.documentElement.setAttribute('data-theme', prefs.theme);
  window.dispatchEvent(new Event('factbum:state'));
}
