/**
 * v1.40 archive migration. Metadata, not translated display strings, is the source
 * of truth. Old text fields and bitmap stay on the entry as a local backup.
 * Missing historical percentages are UNKNOWN, never inferred from today's game.
 */
import { DB } from './data.js?v=1.43';
import { OLD_THEME_ID } from './config.js?v=1.43';

export const CARD_SCHEMA = 2;
const clean = (value) => String(value == null ? '' : value).replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim();
const number = (value, max = Infinity) => {
  if (value == null || value === '') return null;
  const n = Number(value);
  return Number.isFinite(n) && n >= 0 && n <= max ? n : null;
};
function matchNumber(text, re, max = Infinity) {
  const m = clean(text).match(re);
  return m ? number(m[1], max) : null;
}

export function themeId(value) {
  if (value && typeof value === 'object') value = value.id;
  const t = clean(value);
  if (/^(random|рандом)$/i.test(t)) return 'random';
  if (OLD_THEME_ID[t]) return OLD_THEME_ID[t];
  const row = DB.themes.find((x) => [x.id, x.ru, x.en].some((v) => clean(v).toLowerCase() === t.toLowerCase()));
  return row ? row.id : null;
}
export function diffId(value) {
  if (value && typeof value === 'object') value = value.id || value.ru || value.en;
  const t = clean(value).toLowerCase();
  const row = DB.diffs.find((x) => [x.id, x.ru, x.en].some((v) => clean(v).toLowerCase() === t));
  return row ? row.id : null;
}
export function normalizeTeam(team) {
  const name = clean(team && team.name).slice(0, 80);
  const explicit = team && team.id && DB.teams.find((x) => x.id === team.id);
  const known = explicit || DB.teams.find((x) => [x.ru,x.en,...(x.legacy_names||[])].includes(name));
  const defaultTeam = team && team.defaultTeam || (/^(Команда А|Team A)$/.test(name) ? 'a' : /^(Команда Б|Team B)$/.test(name) ? 'b' : null);
  return {
    id: known ? known.id : '',
    name,
    score: number(team && team.score, 10),
    ...(defaultTeam ? { defaultTeam } : {}),
  };
}
function titleArchetypes(title) {
  const t = clean(title);
  const labels = a => [a.ru,a.en,...(a.legacy_names||[])];
  const match = (start) => DB.archetypes.find((a) => labels(a).some((v) => start === v || start.startsWith(v + ' ') || start.startsWith(v + '-') || start.startsWith(v + '–')));
  const first = match(t);
  if (!first) return [null, null];
  const name = labels(first).find((n) => t.startsWith(n));
  const tail = t.slice(name.length);
  const second = /^[-–]/.test(tail) ? match(tail.slice(1)) : null;
  return [first.id, second ? second.id : null];
}

export function normalizeCardEntry(entry) {
  if (!entry || typeof entry !== 'object') return null;
  const old = entry.d && typeof entry.d === 'object' ? entry.d : null;
  if (entry.schema === CARD_SCHEMA && old) return entry;
  const title = clean(entry.title);
  const text = [entry.meta, entry.meta1, entry.meta2].map(clean).join(' · ');
  let theme = themeId(old && old.theme || entry.theme);
  if (!theme) {
    const m = text.match(/(?:Квиз|Quiz):\s*([^·]+)/i);
    if (m) theme = themeId(m[1]);
  }
  if (!theme) {
    const row = DB.themes.find((t) => [t.noun_ru, 'of ' + t.noun_en].some((v) => title.endsWith(' ' + v)));
    if (row) theme = row.id;
    else if (/(широкого круга|of a wide circle|of many worlds)$/i.test(title)) theme = 'random';
  }
  let diff = diffId(old && old.diff || entry.diff);
  if (!diff) {
    const m = text.match(/(?:Сложность|Difficulty):\s*([^·]+)/i);
    if (m) diff = diffId(m[1]);
  }
  const mode = (old && old.kind) || entry.mode || entry.kind || 'solo';
  let d;
  if (mode === 'duel') {
    let teams = old && old.teams || entry.teams;
    if (!Array.isArray(teams) || teams.length !== 2) {
      const m = clean(entry.sub).match(/^(.+?)\s+(\d{1,2})\s*(?:—|–|:|-)\s*(\d{1,2})\s+(.+)$/);
      teams = m ? [{ name: m[1], score: +m[2] }, { name: m[4], score: +m[3] }] : null;
    }
    teams = teams && teams.map(normalizeTeam);
    d = teams && teams.every((t) => t.score != null)
      ? { kind: 'duel', teams, theme, diff }
      : { kind: 'legacy', originalKind: 'duel', theme, diff, recovered: false };
  } else {
    const archs = titleArchetypes(title);
    const top1 = old && old.top1 || entry.top1 || archs[0];
    const top2 = old && old.top2 || entry.top2 || archs[1];
    const correct = number(old && old.correct != null ? old.correct : entry.correct, 10)
      ?? matchNumber(entry.sub, /\b(\d{1,2})\s*(?:из|of|\/)\s*10\b/i, 10);
    const total = number(old && old.total != null ? old.total : entry.total)
      ?? matchNumber(text, /(?:·|^)\s*(\d+)\s*(?:очк\S*|points)(?:\s|$)/i);
    const generic = old ? !!old.generic : /^(Любопытный универсал|Curious Polymath)$/i.test(title);
    d = {
      kind: top1 || generic || correct != null ? 'solo' : 'legacy',
      top1: DB.archetypes.some((a) => a.id === top1) ? top1 : null,
      top2: DB.archetypes.some((a) => a.id === top2) ? top2 : null,
      generic, hybrid: old ? !!old.hybrid : !!(top1 && top2),
      correct, total, theme, diff,
      p1: number(old ? old.p1 : entry.p1), p2: number(old ? old.p2 : entry.p2),
      pct: number(old ? old.pct : entry.pct, 100),
      advice: old && old.advice || null,
      recovered: !!old || !!(correct != null && (top1 || generic)),
    };
  }
  return { ...entry, id: entry.id || ('legacy-' + (entry.ts || 0)), schema: CARD_SCHEMA, d, mode: d.kind };
}
