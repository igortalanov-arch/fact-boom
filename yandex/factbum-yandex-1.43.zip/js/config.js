/** Game version. Bump on every published change: 1.01 → 1.02 → … */
export const VERSION = '1.43';

export const QUESTIONS_PER_RUN = 10;
export const FIGURE_PARTS = 6;
export const HYBRID_GAP = 3;
export const GENERIC_PCT = 30;
export const SAVE_VERSION = 4;
export const LS_LANG = 'factbum_lang';
export const LS_THEME = 'factbum_theme';
export const LS_UID = 'factbum_uid';
export const LS_SOUND = 'factbum_sound';
export const LS_SAVE_PREFIX = 'factbum_v2_';
export const LS_CARDS_PREFIX = 'factbum_cards_';
export const YA_STORAGE_KEY = 'factbum_yandex_v2';
export const YA_CARDS_KEY = 'factbum_yandex_c1';
export const CARD_ARCHIVE_MAX = 24;

export const THEME_FILES = ['body', 'space', 'ai', 'nature', 'history', 'music', 'cinema'];

export const PART_IDS = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6'];
export const PART_LABEL = {
  ru: { p1: 'фрагмент №1', p2: 'фрагмент №2', p3: 'фрагмент №3', p4: 'фрагмент №4', p5: 'фрагмент №5', p6: 'фрагмент №6' },
  en: { p1: 'piece 1', p2: 'piece 2', p3: 'piece 3', p4: 'piece 4', p5: 'piece 5', p6: 'piece 6' },
};

export const RANKS = [
  { min: 9, id: 'legend', ru: 'Легенда', en: 'Legend', e: '🏆', c1: '#ffd54f', c2: '#8a5a10',
    d: 'Невероятно! Вы — настоящая легенда среди знатоков. Ваш кругозор и эрудиция вызывают восхищение!',
    de: 'Incredible! You are a true legend among connoisseurs. Your horizon and erudition are impressive!' },
  { min: 7, id: 'master', ru: 'Магистр', en: 'Master', e: '🔬', c1: '#4fc3f7', c2: '#175a83',
    d: 'Вы настоящий исследователь! Ваши знания впечатляют, а умение анализировать факты достойно уважения.',
    de: 'You are a real researcher! Your knowledge impresses, and your ability to analyze facts deserves respect.' },
  { min: 5, id: 'expert', ru: 'Знаток', en: 'Expert', e: '💡', c1: '#ffb74d', c2: '#8a5a1c',
    d: 'Отличный уровень! Вы уверенно ориентируетесь в фактах и умеете удивлять окружающих.',
    de: 'Excellent level! You confidently navigate facts and know how to amaze people around you.' },
  { min: 3, id: 'student', ru: 'Студент', en: 'Student', e: '🎓', c1: '#5b8cff', c2: '#27407e',
    d: 'Хороший результат! Вы проявляете любознательность и уже ориентируетесь в разных темах.',
    de: 'Good result! You show curiosity and already navigate different topics.' },
  { min: 1, id: 'apprentice', ru: 'Ученик', en: 'Apprentice', e: '📖', c1: '#3ddc97', c2: '#1d6b5a',
    d: 'Первые шаги сделаны. Вы уже кое-что знаете, но впереди ещё много открытий!',
    de: 'The first steps are done. You already know a few things, but many discoveries lie ahead!' },
  { min: 0, id: 'novice', ru: 'Новичок', en: 'Novice', e: '🌱', c1: '#9b7bff', c2: '#3d2b8f',
    d: 'Вы только начинаете свой путь в мире удивительных фактов. Не расстраивайтесь — каждый эксперт когда-то был новичком!',
    de: "You are just beginning your path in the world of amazing facts. Don't be upset — every expert was once a novice!" },
];

export function getRank(correct) {
  return RANKS.find((r) => correct >= r.min);
}

/** Advice direction rotates by solo session count. */
export const ADVICE_DIRS = ['growth', 'relations', 'health', 'hobby'];
export const ADVICE_DIR_MAP = {
  growth: ['growth', 'learning', 'logic'],
  relations: ['relations', 'home'],
  health: ['health', 'body'],
  hobby: ['hobby', 'nature', 'tech'],
};

export const OLD_FIG_SLUG = {
  'Космонавт в скафандре': 'astronaut',
  'Дракон': 'dragon',
  'Динозавр (Тираннозавр)': 'trex',
  'Робот-исследователь': 'robot',
  'Мудрый кот': 'wise-cat',
  'Кит': 'whale',
  'Сова-ученая': 'owl',
  'Феникс': 'phoenix',
  'Дельфин': 'dolphin',
  'Пчела-труженица': 'bee',
  'Черепаха-путешественница': 'turtle',
  'Единорог': 'unicorn',
};

export const OLD_THEME_ID = {
  'Тело и здоровье': 'body',
  'Космос': 'space',
  'ИИ и технологии': 'ai',
  'Природа': 'nature',
  'История': 'history',
  'Музыка': 'music',
  'Кино и сериалы': 'cinema',
  'Рандом': 'random',
};
