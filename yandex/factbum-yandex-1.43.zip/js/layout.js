/** Fixed-to-viewport controls and measured, non-overlapping quiz typography. */
const $ = (id) => document.getElementById(id);
let pending = 0;
let initialized = false;

export function resetScreenScroll(id) {
  const screen = $('scr-' + id);
  if (!screen) return;
  screen.scrollTop = 0;
  const scroller = screen.querySelector('.screen-scroll');
  if (scroller) scroller.scrollTop = 0;
}

export function fitQuiz() {
  const screen = $('scr-quiz');
  if (!screen || !screen.classList.contains('on')) return;
  const scroller = screen.querySelector('.quiz-scroll');
  const question = $('quiz-question-view');
  const active = question && !question.hidden ? question : $('quiz-fact');
  if (!active || active.hidden || scroller.clientHeight < 20) return;
  const densities = ['roomy', 'comfortable', 'compact', 'dense', 'tight'];
  const small = scroller.clientWidth < 460;
  const first = small ? 2 : 0;
  for (let i = first; i < densities.length; i += 1) {
    screen.dataset.density = densities[i];
    if (active.getBoundingClientRect().height <= scroller.clientHeight - 4) break;
  }
  // Keep a safe internal-scroll fallback for unusually tiny embedded viewports.
  // Never conceal a question, truncate an answer, or shrink tap targets below 44px.
  screen.dataset.overflow = active.getBoundingClientRect().height > scroller.clientHeight - 4 ? 'true' : 'false';
}

export function syncDock(id) {
  const app = $('app');
  const dock = $('action-dock');
  if (!app || !dock) return;
  const current = id || app.dataset.screen || 'boot';
  app.dataset.screen = current;
  let visible = false;
  dock.querySelectorAll('[data-actions-for]').forEach((group) => {
    group.hidden = group.dataset.actionsFor !== current || (current === 'quiz' && $('quiz-next').disabled);
    if (!group.hidden) visible = true;
  });
  dock.hidden = !visible;
  const space = visible ? Math.ceil(dock.getBoundingClientRect().height) + 6 : 0;
  const val = space + 'px';
  if (app.style.getPropertyValue('--dock-space') !== val) app.style.setProperty('--dock-space', val);
  const back = $('btn-back');
  if (back) back.hidden = current === 'start' || current === 'boot';
  const status = $('header-quiz-status');
  if (status) status.hidden = current !== 'quiz';
  requestQuizFit();
}

export function requestQuizFit() {
  if (pending) cancelAnimationFrame(pending);
  pending = requestAnimationFrame(() => { pending = 0; fitQuiz(); });
}

export function initLayout() {
  if (initialized) return;
  initialized = true;
  syncDock('boot');
  const resized = () => { syncDock(); };
  window.addEventListener('resize', resized, { passive: true });
  if (window.visualViewport) window.visualViewport.addEventListener('resize', resized, { passive: true });
  if (typeof ResizeObserver !== 'undefined') {
    const ro = new ResizeObserver(resized);
    ro.observe($('app'));
    ro.observe($('action-dock'));
  }
}
