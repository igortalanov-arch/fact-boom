/** v3 merge model. Each installation owns a cloud slot; no device overwrites
 * another device's slot. Counters grow, explicit resets remove observed parts,
 * and archive deletion is a permanent tombstone for that immutable card ID. */
export const SYNC_SCHEMA = 3;
export const CLOUD_PREFIX = 'factbum_v3_device_';
export const TOTALS = ['sessions','duels','duelWins','duelDraws','answered','rand'];
const clone = (x) => JSON.parse(JSON.stringify(x));
const safeKey = (s) => typeof s === 'string' && s.length > 0 && s.length <= 180 && !['__proto__','prototype','constructor'].includes(s);
const count = (x) => Math.max(0, Math.min(1e12, Math.floor(Number(x) || 0)));
const stamp = (x) => Math.max(0, Math.min(Number.MAX_SAFE_INTEGER, Math.floor(Number(x) || 0)));
const entries = (x) => x && typeof x === 'object' && !Array.isArray(x) ? Object.entries(x).filter(([k]) => safeKey(k)) : [];
export function maxMap(a = {}, b = {}) {
  const out = {};
  for (const [k,v] of [...entries(a),...entries(b)]) out[k] = Math.max(count(out[k]), count(v));
  return out;
}
function minDates(a = {}, b = {}) {
  const out = {};
  for (const [k,v] of [...entries(a),...entries(b)]) if (stamp(v)) out[k] = out[k] ? Math.min(out[k],stamp(v)) : stamp(v);
  return out;
}
function bestOf(a, b) {
  const rows = [a,b].filter(v => v && Number.isFinite(Number(v.correct)) && v.correct >= 0 && v.correct <= 10 && safeKey(v.theme));
  rows.sort((x,y) => y.correct-x.correct || String(x.theme).localeCompare(String(y.theme)));
  return rows.length ? {correct:Number(rows[0].correct),theme:rows[0].theme} : null;
}
export function flatCounts(p = {}) {
  const out = {};
  TOTALS.forEach(k => { if (count(p[k])) out[k] = count(p[k]); });
  entries(p.arch).forEach(([k,v]) => { if(count(v)) out['arch/'+k] = count(v); });
  entries(p.themes).forEach(([k,v]) => {
    if(count(v.quizzes)) out['theme/'+k+'/quizzes'] = count(v.quizzes);
    if(count(v.questions)) out['theme/'+k+'/questions'] = count(v.questions);
  });
  return out;
}
export function newBranch(actor) {
  return {schema:3,actor,rev:0,clock:0,base:{counts:{},parts:{}},counts:{},parts:{},resets:{},ach:{},best:null,used:{},cards:{},deleted:{},receipts:[]};
}
function cardSort(a,b) { return (Number(b.ts)||0)-(Number(a.ts)||0) || String(b.id).localeCompare(String(a.id)); }
export function cardWithoutImage(c) {
  if (!c || typeof c !== 'object' || !safeKey(c.id)) return null;
  const {img,...rest} = c;
  return clone(rest);
}
function mergeCard(a,b) {
  if (!a) return cardWithoutImage(b); if (!b) return cardWithoutImage(a);
  // Metadata migrations can improve an old card without creating a new card.
  if ((b.schema||0) !== (a.schema||0)) return cardWithoutImage((b.schema||0) > (a.schema||0) ? b : a);
  const aa=JSON.stringify(a), bb=JSON.stringify(b);
  return cardWithoutImage(aa >= bb ? a : b);
}
export function mergeBranch(a,b) {
  if (!a) a = newBranch(b.actor);
  if (!b) b = newBranch(a.actor);
  const out = newBranch(a.actor || b.actor);
  out.receipts=[...new Set([...(a.receipts||[]),...(b.receipts||[])].filter(x=>typeof x==='string'&&x.length<100))];
  out.rev=Math.max(count(a.rev),count(b.rev)); out.clock=Math.max(stamp(a.clock),stamp(b.clock));
  out.base={counts:maxMap(a.base?.counts,b.base?.counts),parts:maxMap(a.base?.parts,b.base?.parts)};
  out.counts=maxMap(a.counts,b.counts); out.parts=maxMap(a.parts,b.parts);
  for(const [id,v] of [...entries(a.resets),...entries(b.resets)]) out.resets[id]=maxMap(out.resets[id],v);
  out.ach=minDates(a.ach,b.ach); out.best=bestOf(a.best,b.best);
  for(const [scope,v] of [...entries(a.used),...entries(b.used)]) {
    if (!Array.isArray(v) || typeof v[1] !== 'string') continue;
    const next=[stamp(v[0]),v[1].split(',').filter(s=>/^[A-Za-z0-9_-]{1,40}$/.test(s)).slice(-240).join(',')];
    const prev=out.used[scope]; if(!prev || next[0]>prev[0] || next[0]===prev[0]&&next[1]>prev[1]) out.used[scope]=next;
  }
  out.deleted=maxMap(a.deleted,b.deleted);
  for(const [id,c] of [...entries(a.cards),...entries(b.cards)]) {
    if(out.deleted[id] || !c || c.id!==id) continue;
    const value=mergeCard(out.cards[id],c); if(value) out.cards[id]=value;
  }
  out.cards=Object.fromEntries(Object.values(out.cards).sort(cardSort).slice(0,24).map(c=>[c.id,c]));
  return out;
}
export function validBranch(v, actor) {
  return v && v.schema === 3 && safeKey(v.actor) && (!actor || v.actor===actor);
}
export function mergeRecords(a = {}, b = {}) {
  const out={};
  for(const [actor,v] of [...entries(a),...entries(b)]) if(validBranch(v,actor)) out[actor]=mergeBranch(out[actor],v);
  return out;
}
export function knownParts(records, id) {
  const cutoffs={base:0};
  for(const [actor,r] of entries(records)) {cutoffs.base=Math.max(cutoffs.base,count(r.base?.parts?.[id]));cutoffs[actor]=count(r.parts?.[id]);}
  return cutoffs;
}
export function hasReset(records,id) { return Object.values(records).some(r=>Object.keys(r.resets?.[id]||{}).length); }
export function aggregate(records) {
  let baseline={},baseParts={},ach={},best=null,deleted={}; const totals={},parts={},resets={},used={},cards={};
  for(const [actor,r] of entries(records)) {
    baseline=maxMap(baseline,r.base?.counts); baseParts=maxMap(baseParts,r.base?.parts);
    for(const [k,n] of entries(r.counts)) totals[k]=(totals[k]||0)+count(n);
    for(const [id,cuts] of entries(r.resets)) resets[id]=maxMap(resets[id],cuts);
    ach=minDates(ach,r.ach); best=bestOf(best,r.best); deleted=maxMap(deleted,r.deleted);
    for(const [scope,v] of entries(r.used)) {
      const old=used[scope]; if(!old||v[0]>old[0]||v[0]===old[0]&&actor>old[2])used[scope]=[v[0],v[1],actor];
    }
  }
  const figIDs=new Set([...Object.keys(baseParts),...Object.values(records).flatMap(r=>Object.keys(r.parts||{}))]);
  for(const id of figIDs){
    let n=Math.max(0,(baseParts[id]||0)-(resets[id]?.base||0));
    for(const [actor,r] of entries(records))n+=Math.max(0,count(r.parts?.[id])-count(resets[id]?.[actor]));
    if(n)parts[id]=Math.min(5,n);
  }
  for(const r of Object.values(records))for(const [id,c] of entries(r.cards))if(!deleted[id])cards[id]=mergeCard(cards[id],c);
  const p={v:3,sessions:0,duels:0,duelWins:0,duelDraws:0,answered:0,rand:0,figs:parts,arch:{},themes:{},ach,best,used:{}};
  const combined={...baseline};for(const [k,n]of entries(totals))combined[k]=(combined[k]||0)+n;
  for(const [k,n]of entries(combined)){
    const bits=k.split('/');if(TOTALS.includes(k))p[k]=n;
    else if(bits[0]==='arch'&&bits.length===2&&safeKey(bits[1]))p.arch[bits[1]]=n;
    else if(bits[0]==='theme'&&bits.length===3&&safeKey(bits[1])&&['quizzes','questions'].includes(bits[2])){p.themes[bits[1]] ||= {quizzes:0,questions:0};p.themes[bits[1]][bits[2]]=n;}
  }
  for(const [scope,v]of entries(used))p.used[scope]=Object.fromEntries(v[1].split(',').filter(Boolean).map(id=>[id,1]));
  return {progress:p,cards:Object.values(cards).sort(cardSort).slice(0,24),deleted};
}
export function progressChange(previous, next, records) {
  const before=flatCounts(previous), after=flatCounts(next), change={counts:{},parts:{},resets:{},ach:{},used:{}};
  for(const [k,n]of entries(after))if(n>(before[k]||0))change.counts[k]=n-(before[k]||0);
  for(const id of new Set([...Object.keys(previous.figs||{}),...Object.keys(next.figs||{})])){
    const a=count(previous.figs?.[id]),b=count(next.figs?.[id]);
    if(b>a)change.parts[id]=b-a;
    if(b<a)change.resets[id]=knownParts(records,id);
  }
  for(const [id,t] of entries(next.ach))if(!previous.ach?.[id])change.ach[id]=stamp(t)||Date.now();
  if(JSON.stringify(next.best)!==JSON.stringify(previous.best))change.best=next.best;
  for(const scope of new Set([...Object.keys(previous.used||{}),...Object.keys(next.used||{})])){
    const a=Object.keys(previous.used?.[scope]||{}).slice(-240).join(','),b=Object.keys(next.used?.[scope]||{}).slice(-240).join(',');
    if(a!==b)change.used[scope]=b;
  }
  return change;
}
export function changeHasData(d) {return !!d && (['counts','parts','resets','ach','used','cards','deleted'].some(k=>Object.keys(d[k]||{}).length)||!!d.base||!!d.best);}
export function applyChange(branch, d, records = {}) {
  const r=mergeBranch(branch,newBranch(branch.actor));
  if(d.opID && r.receipts.includes(d.opID)) return r;
  if(d.opID)r.receipts.push(d.opID);
  r.rev++; r.clock=Math.max(Date.now(),r.clock+1,...Object.values(records).map(x=>(x.clock||0)+1));
  if(d.base){r.base.counts=maxMap(r.base.counts,d.base.counts);r.base.parts=maxMap(r.base.parts,d.base.parts);}
  for(const [k,n]of entries(d.counts))r.counts[k]=(r.counts[k]||0)+count(n);
  for(const [id,n]of entries(d.parts))r.parts[id]=(r.parts[id]||0)+count(n);
  for(const [id,cuts]of entries(d.resets)){
    // Same-installation actions are serialized. Include its earlier queued gains;
    // other devices' unobserved concurrent gains are deliberately NOT reset.
    r.resets[id]=maxMap(r.resets[id],{...cuts,[r.actor]:count(r.parts[id])});
  }
  r.ach=minDates(r.ach,d.ach);r.best=bestOf(r.best,d.best);
  for(const [scope,ids]of entries(d.used))r.used[scope]=[r.clock,String(ids).split(',').slice(-240).join(',')];
  r.deleted=maxMap(r.deleted,d.deleted);
  for(const [id,c]of entries(d.cards))if(!r.deleted[id]){const v=cardWithoutImage(c);if(v)r.cards[id]=v;}
  for(const id of Object.keys(r.deleted))delete r.cards[id];
  r.cards=Object.fromEntries(Object.values(r.cards).sort(cardSort).slice(0,24).map(c=>[c.id,c]));
  return r;
}
export function legacyChange(progress, cards) {
  const d={base:{counts:flatCounts(progress),parts:maxMap(progress.figs)},ach:progress.ach||{},best:progress.best,used:{},cards:{}};
  for(const [scope,ids]of entries(progress.used))d.used[scope]=Object.keys(ids).slice(-240).join(',');
  for(const c of cards||[])if(c&&safeKey(c.id))d.cards[c.id]=c;
  return d;
}
export function mergeLegacy(a,b) {
  const r1=applyChange(newBranch('legacy-a'),legacyChange(a||{},[]));
  const r2=applyChange(newBranch('legacy-b'),legacyChange(b||{},[]));
  return aggregate({'legacy-a':r1,'legacy-b':r2}).progress;
}

export function stableStringify(value) {
  const sorted=x=>Array.isArray(x)?x.map(sorted):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,sorted(x[k])])):x;
  return JSON.stringify(sorted(value));
}
