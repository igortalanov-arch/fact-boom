/** Shared pause reasons. Closing a modal or an ad cannot unpause a hidden tab. */
const reasons = new Set();
const listeners = new Set();
if (typeof document !== 'undefined' && document.hidden) reasons.add('hidden');

export function isPaused() { return reasons.size > 0; }
export function hasPause(reason) { return reasons.has(reason); }
export function pauseReasons() { return [...reasons]; }
export function onPauseChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }
export function setPaused(reason, value) {
  const before = reasons.has(reason);
  if (value) reasons.add(reason); else reasons.delete(reason);
  if (before === !!value) return;
  listeners.forEach((fn) => { try { fn(isPaused()); } catch { /* one listener must not block others */ } });
}
if (typeof document !== 'undefined') {
  document.addEventListener('visibilitychange', () => setPaused('hidden', document.hidden));
  window.addEventListener('blur', () => setPaused('blur', true));
  window.addEventListener('focus', () => setPaused('blur', false));
}
