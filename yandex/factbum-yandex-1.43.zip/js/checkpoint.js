/** Local unfinished rounds. Independent of cloud progress and translated text. */
const PREFIX='factbum_round1_', DONE='factbum_round_done_', LAST='factbum_round_last_', TAB='factbum_round_tab_';
const validId=x=>typeof x==='string'&&/^[a-z0-9-]{8,80}$/.test(x);
const clone=x=>JSON.parse(JSON.stringify(x));
function get(which,key){try{return (which==='session'?sessionStorage:localStorage).getItem(key);}catch{return null;}}
function put(which,key,value){try{(which==='session'?sessionStorage:localStorage).setItem(key,value);return true;}catch{return false;}}
function del(which,key){try{(which==='session'?sessionStorage:localStorage).removeItem(key);return true;}catch{return false;}}
function parse(text){try{return JSON.parse(text);}catch{return null;}}
export function createRunId(){return Date.now().toString(36)+'-'+(globalThis.crypto?.randomUUID?.().replaceAll('-','')||Math.random().toString(36).slice(2)+Math.random().toString(36).slice(2));}
/** Change detector, not a security/anti-cheat hash. Both locales affect it. */
export function questionSignature(q){
  const text=JSON.stringify([q.id,q.rev||1,q.theme,q.a1,q.a2,q.ru.q,q.ru.o,q.ru.f,q.en.q,q.en.o,q.en.f]);
  let a=2166136261,b=2246822519;
  for(let i=0;i<text.length;i++){const n=text.charCodeAt(i);a=Math.imul(a^n,16777619);b=Math.imul(b^n,3266489917);}
  return (a>>>0).toString(16).padStart(8,'0')+(b>>>0).toString(16).padStart(8,'0');
}
export const completionId=id=>'finish-'+id;
export const checkpointKey=(uid,id)=>PREFIX+uid+'_'+id;
export function completedLocally(uid,id){return validId(id)&&get('local',DONE+uid+'_'+id)==='1';}
export function markCompleted(uid,id){
  if(!validId(id))return false;
  const saved=put('local',DONE+uid+'_'+id,'1');
  if(saved)discardCheckpoint(uid,id);
  return saved;
}
export function discardCheckpoint(uid,id){
  if(!validId(id))return;
  del('local',checkpointKey(uid,id));
  if(get('local',LAST+uid)===id)del('local',LAST+uid);
  if(get('session',TAB+uid)===id)del('session',TAB+uid);
}
export function readCheckpoint(uid,id){
  if(!validId(id))return null;
  const raw=get('local',checkpointKey(uid,id));if(!raw||raw.length>24000)return null;
  const c=parse(raw);return c&&c.schema===1&&c.uid===uid&&c.runId===id?c:null;
}
export function findCheckpoint(uid){
  const own=get('session',TAB+uid),last=get('local',LAST+uid);
  // Without Web Locks we offer only this tab's checkpoint, not another tab's run.
  const ids=lockAPI()?[own,last]:[own];
  for(const id of [...new Set(ids)].filter(Boolean)){
    if(completedLocally(uid,id)){discardCheckpoint(uid,id);continue;}
    const c=readCheckpoint(uid,id);if(c)return c;
  }
  return null;
}
export function retainedRunOperations(uid){
  const ids=[];
  try{for(let i=0;i<localStorage.length;i++){
    const key=localStorage.key(i);if(!key?.startsWith(PREFIX+uid+'_'))continue;
    const c=parse(localStorage.getItem(key));if(c?.uid===uid&&validId(c.runId))ids.push(completionId(c.runId));
  }}catch{/* read-only or disabled storage */}
  return ids;
}
export function checkpointReferences(uid,key){return !!key&&(key.startsWith(PREFIX+uid+'_')||key.startsWith(DONE+uid+'_')||key===LAST+uid);}

export function packCheckpoint(uid,s,timer,handoff=false){
  if(!s?.running||s.finishing||!validId(s.runId)||!Array.isArray(s.q)||!s.q.length)return null;
  if(!Array.isArray(s.answers)||s.answers.length!==s.q.length)return null;
  return {
    schema:1,uid,runId:s.runId,startedAt:s.startedAt||Date.now(),updatedAt:Date.now(),
    mode:s.mode,theme:s.theme,random:!!s.random,diff:s.diff?.id,mood:s.mood,fig:s.fig||null,
    teams:s.mode==='duel'?s.teams.map(t=>({id:t.id||'',name:t.name||'',...(t.defaultTeam?{defaultTeam:t.defaultTeam}:{})})):null,
    questions:s.q.map(q=>({id:q.id,rev:q.rev||1,signature:q.signature,order:q.order.slice()})),
    index:s.qi,answers:s.answers.slice(),
    view:handoff?'handoff':s.done?(s.showingFact?'fact':'review'):'question',
    timer:{total:timer.total,left:Math.max(0,timer.left)},
  };
}
export function storeCheckpoint(c){
  if(!c||!validId(c.runId)||completedLocally(c.uid,c.runId))return false;
  const value=JSON.stringify(c);if(value.length>24000)return false;
  const saved=put('local',checkpointKey(c.uid,c.runId),value);
  if(saved){put('session',TAB+c.uid,c.runId);put('local',LAST+c.uid,c.runId);}
  return saved;
}
export function decodeCheckpoint(c,uid,db,prepare){
  const bad=reason=>({ok:false,reason});
  if(!c||c.schema!==1||c.uid!==uid||!validId(c.runId))return bad('invalid');
  if(!['solo','duel'].includes(c.mode)||!Number.isFinite(c.startedAt)||!Number.isFinite(c.updatedAt))return bad('invalid');
  const count=c.mode==='duel'?20:10;
  if(!Array.isArray(c.questions)||c.questions.length!==count||!Array.isArray(c.answers)||c.answers.length!==count)return bad('invalid');
  if(!Number.isInteger(c.index)||c.index<0||c.index>=count)return bad('invalid');
  const diff=db.diffs.find(x=>x.id===c.diff);
  if(!diff||!db.moods.some(x=>x.id===c.mood))return bad('invalid');
  if(c.random?c.theme!=='random':!db.themes.some(x=>x.id===c.theme))return bad('invalid');
  if(c.mode==='solo'&&!db.figures.some(x=>x.id===c.fig))return bad('invalid');
  const q=[],used=new Set(),lookup=new Map(db.questions.map(x=>[x.id,x]));
  for(const item of c.questions){
    if(!item||used.has(item.id))return bad('invalid');used.add(item.id);
    const raw=lookup.get(item.id);if(!raw||(raw.rev||1)!==item.rev)return bad('content');
    if(!c.random&&raw.theme!==c.theme)return bad('invalid');
    if(!Array.isArray(item.order)||item.order.length!==5||new Set(item.order).size!==5||item.order.some(n=>!Number.isInteger(n)||n<0||n>4))return bad('invalid');
    if(typeof item.signature!=='string'||item.signature!==questionSignature(raw))return bad('content');
    q.push(prepare(raw,item.order));
  }
  for(let i=0;i<count;i++){
    const a=c.answers[i];if(a!==null&&(!Number.isInteger(a)||a< -1||a>4))return bad('invalid');
    if(i<c.index&&a===-1||i>c.index&&a!==-1)return bad('invalid');
  }
  const done=c.answers[c.index]!==-1;
  if(!['question','fact','review','handoff'].includes(c.view)||(!done&&c.view!=='question')||(done&&c.view==='question'))return bad('invalid');
  if(c.view==='handoff'&&(c.mode!=='duel'||c.index===count-1))return bad('invalid');
  if(!c.timer||!Number.isFinite(c.timer.total)||c.timer.total<1||c.timer.total>120||!Number.isFinite(c.timer.left)||c.timer.left<0||c.timer.left>c.timer.total)return bad('invalid');
  let teams=null;
  if(c.mode==='duel'){
    if(!Array.isArray(c.teams)||c.teams.length!==2||c.teams.some(t=>!t||typeof t.name!=='string'||t.name.length>80))return bad('invalid');
    teams=c.teams.map(t=>({id:typeof t.id==='string'?t.id:'',name:t.name,score:0,...(['a','b'].includes(t.defaultTeam)?{defaultTeam:t.defaultTeam}:{})}));
  }
  let wrong=0;const pts={};
  c.answers.forEach((a,i)=>{
    if(a===-1)return;
    const ok=a===q[i].correct;if(!ok)wrong++;
    if(teams){if(ok)teams[i%2].score++;}
    else{pts[q[i].a1]=(pts[q[i].a1]||0)+1;if(q[i].a2)pts[q[i].a2]=(pts[q[i].a2]||0)+1;}
  });
  return {ok:true,session:{runId:c.runId,startedAt:c.startedAt,mode:c.mode,theme:c.theme,random:!!c.random,diff,mood:c.mood,fig:c.fig,q,qi:c.index,wrong,pts,teams,answers:c.answers.slice(),running:true,done,answerChoice:done?c.answers[c.index]:undefined,showingFact:c.view==='fact'},view:c.view,timer:clone(c.timer)};
}

// An active round is held exclusively in modern browsers; hidden tabs retain it.
let held=null,locksDenied=false;
function lockAPI(){try{return !locksDenied&&navigator.locks?.request?navigator.locks:null;}catch{return null;}}
export function releaseRun(){if(held){const h=held;held=null;h.release();}}
export async function acquireRun(uid,id,{fresh=false}={}){
  if(held?.uid===uid&&held.id===id)return true;
  releaseRun();
  const fallback=()=>{if(!fresh&&get('session',TAB+uid)!==id)return false;held={uid,id,release(){}};return true;};
  const api=lockAPI();if(!api)return fallback();
  let settle,release;
  const result=new Promise(r=>settle=r),hold=new Promise(r=>release=r);
  try{api.request('factbum-active-'+uid+'-'+id,{ifAvailable:true},async lock=>{
    if(!lock){settle(false);return;}
    held={uid,id,release};settle(true);await hold;
  }).catch(()=>{locksDenied=true;settle(fallback());});}catch{locksDenied=true;settle(fallback());}
  return result;
}
export function ownsRun(uid,id){return held?.uid===uid&&held.id===id;}
