import { THEME_FILES, VERSION } from './config.js?v=1.43';

export const DB = {
  version: null,
  themes: [],
  moods: [],
  diffs: [],
  archetypes: [],
  adviceThemes: [],
  figures: [],
  questions: [],
  advice: [],
  teams: [],
  byTheme: {},
  questionTotal: 0,
};

async function getJson(url) {
  const sep = url.includes('?') ? '&' : '?';
  const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),15000);
  try {
    const r=await fetch(url+sep+'v='+encodeURIComponent(VERSION),{cache:'no-cache',signal:controller.signal});
    if(!r.ok)throw new Error(`Не удалось загрузить ${url}: ${r.status}`);
    return await r.json();
  } finally {clearTimeout(timeout);}
}

function applyPack(meta, advice, teams, packs) {
  const questions = packs.flat();
  DB.version = (meta && meta.version) || DB.version;
  DB.themes = meta.themes;
  DB.moods = meta.moods;
  DB.diffs = meta.diffs;
  DB.archetypes = meta.archetypes;
  DB.adviceThemes = meta.advice_themes;
  DB.figures = meta.figures;
  DB.questions = questions;
  DB.advice = advice;
  DB.teams = teams;
  DB.questionTotal = questions.length;
  DB.byTheme = Object.fromEntries(THEME_FILES.map((id, i) => [id, packs[i] || []]));
}

export async function loadAll() {
  const inline = (typeof globalThis !== 'undefined' && globalThis.__FACTBUM_INLINE__) || null;
  if (inline && inline.meta && inline.questions) {
    const packs = THEME_FILES.map((id) => inline.questions[id] || []);
    applyPack(inline.meta, inline.advice, inline.teams, packs);
    return DB;
  }
  const [meta, advice, teams, ...packs] = await Promise.all([
    getJson('data/meta.json'),
    getJson('data/advice.json'),
    getJson('data/teams.json'),
    ...THEME_FILES.map((id) => getJson(`data/questions/${id}.json`)),
  ]);
  applyPack(meta, advice, teams, packs);
  return DB;
}

export function themeById(id) {
  return DB.themes.find((t) => t.id === id) || null;
}

export function moodById(id) {
  return DB.moods.find((m) => m.id === id) || null;
}

export function diffById(id) {
  return DB.diffs.find((d) => d.id === id) || null;
}

export function archById(id) {
  return DB.archetypes.find((a) => a.id === id) || null;
}

export function figById(id) {
  return DB.figures.find((f) => f.id === id) || null;
}

export function adviceThemeById(id) {
  return DB.adviceThemes.find((t) => t.id === id) || null;
}

export function locName(obj, lang) {
  if (!obj) return '';
  return lang === 'en' ? (obj.en || obj.ru) : (obj.ru || obj.en);
}
