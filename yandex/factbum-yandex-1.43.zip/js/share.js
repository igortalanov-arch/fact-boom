import { VERSION, getRank } from './config.js?v=1.43';
import { DB } from './data.js?v=1.43';
import { S, addSavedCard } from './state.js?v=1.43';
import { lang, tx, archName, themeName, diffName, rankName, teamName } from './i18n.js?v=1.43';
import { CARD_SCHEMA, normalizeCardEntry } from './archive-data.js?v=1.43';


function seeded(n) {
  let x = n || 1;
  return () => {
    x = (x * 1664525 + 1013904223) % 4294967296;
    return x / 4294967296;
  };
}

/* ------------------------- color helpers ------------------------- */

function hexRgb(h) {
  const m = /^#?([0-9a-f]{6})$/i.exec(h || '');
  if (!m) return [91, 140, 255];
  const n = parseInt(m[1], 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function rgbHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const mx = Math.max(r, g, b);
  const mn = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (mx + mn) / 2;
  if (mx !== mn) {
    const d = mx - mn;
    s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
    if (mx === r) h = (g - b) / d + (g < b ? 6 : 0);
    else if (mx === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    h /= 6;
  }
  return [h * 360, s * 100, l * 100];
}

function hslHex(h, s, l) {
  h = ((((h % 360) + 360) % 360) / 360);
  s = Math.min(100, Math.max(0, s)) / 100;
  l = Math.min(100, Math.max(0, l)) / 100;
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
  const p = 2 * l - q;
  const f = (t) => {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1 / 6) return p + (q - p) * 6 * t;
    if (t < 1 / 2) return q;
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
    return p;
  };
  const to = (v) => Math.round(v * 255).toString(16).padStart(2, '0');
  return '#' + to(f(h + 1 / 3)) + to(f(h)) + to(f(h - 1 / 3));
}

/**
 * Pleasant, strongly flowing gradient stops [top, mid, deep] from a base pair.
 * Same hue family, tamed saturation, clear light → dark flow (v1.39).
 */
export function cardCols(top, bottom) {
  const [h1, s1, l1] = rgbHsl(...hexRgb(top));
  const [h2, s2, l2] = rgbHsl(...hexRgb(bottom));
  const t = hslHex(h1, Math.min(s1, 62), Math.min(Math.max(l1, 46), 58));
  const m = hslHex(h1, Math.min(s1, 60), 36);
  const b = hslHex(s2 < 1 ? h1 : h2, Math.min(Math.max(s2, 30), 70), Math.min(l2, 24));
  return [t, m, b];
}

function baseCols(d) {
  if (d.kind === 'duel') return ['#5b8cff', '#7a5bff'];
  if (d.generic) return ['#5b8cff', '#27407e'];
  const arch = DB.archetypes.find((a) => a.id === d.top1);
  return arch ? arch.c : ['#5b8cff', '#27407e'];
}

export function entryCols(d) {
  const [t, b] = baseCols(d);
  return cardCols(t, b);
}

/* ------------------- language-free result data ------------------- */
export function soloCardData() {
  const c = S.card;
  return {
    kind: 'solo', top1: c.top1, top2: c.top2, p1: c.p1, p2: c.p2, pct: c.pct,
    generic: !!c.generic, hybrid: !!c.hybrid,
    correct: c.correct, total: c.total,
    theme: S.random ? 'random' : S.theme, diff: S.diff.id,
    advice: c.advice && c.advice[0] ? { ...c.advice[0] } : null,
  };
}
function duelCardData() {
  return {
    kind: 'duel',
    teams: S.teams.map((t) => ({ id: t.id || '', name: t.name, score: t.score, ...(t.defaultTeam ? { defaultTeam: t.defaultTeam } : {}) })),
    theme: S.random ? 'random' : S.theme, diff: S.diff.id,
  };
}
export function cardData(entry) { return normalizeCardEntry(entry)?.d || null; }
function themeNoun(themeId) {
  if (themeId === 'random') return tx('noun_random');
  const th = DB.themes.find((t) => t.id === themeId);
  return th ? (lang() === 'en' ? 'of ' + th.noun_en : th.noun_ru) : '';
}
export function cardTitle(d) {
  if (!d) return '';
  if (d.kind === 'legacy') return tx('legacy_card_title');
  if (d.kind === 'duel') {
    const [a, b] = d.teams;
    return a.score === b.score ? tx('duel_draw') : tx('duel_win', { n: teamName(a.score > b.score ? a : b) });
  }
  if (d.generic) return tx('generic_title');
  if (!d.top1) return tx('result_card_title');
  const arch = d.hybrid && d.top2 ? `${archName(d.top1)}-${archName(d.top2)}` : archName(d.top1);
  return [arch, themeNoun(d.theme)].filter(Boolean).join(' ');
}
export function cardSub(d) {
  if (!d) return '';
  if (d.kind === 'legacy') return tx('legacy_card_note');
  if (d.kind === 'duel') {
    const [a, b] = d.teams;
    return tx('duel_score', { a: teamName(a), sa: a.score, b: teamName(b), sb: b.score });
  }
  if (d.correct == null) return '';
  return tx('share_rank', { r: rankName(getRank(d.correct)), e: '', c: d.correct });
}
export function cardMeta(d) {
  if (!d) return ['', ''];
  const pts = d.kind === 'duel' ? d.teams[0].score + d.teams[1].score : d.total;
  const diff = diffName(d.diff);
  return [
    d.theme ? tx('share_meta_l1', { t: themeName(d.theme) }) : '',
    [diff ? tx('share_difficulty', { d: diff }) : '', pts != null ? tx('share_points', { p: pts }) : ''].filter(Boolean).join(' · '),
  ];
}

/* ------------------------- canvas painting ------------------------- */
function wrap(ctx, text, width) {
  const words = String(text || '').trim().split(/\s+/);
  const lines = [];
  let line = '';
  for (let word of words) {
    if (!word) continue;
    // User-supplied team names can be one long word, including non-BMP symbols.
    if (ctx.measureText(word).width > width) {
      if (line) { lines.push(line); line = ''; }
      let part = '';
      for (const char of Array.from(word)) {
        if (part && ctx.measureText(part + char).width > width) { lines.push(part); part = ''; }
        part += char;
      }
      line = part;
      continue;
    }
    const next = line ? line + ' ' + word : word;
    if (line && ctx.measureText(next).width > width) { lines.push(line); line = word; }
    else line = next;
  }
  if (line) lines.push(line);
  return lines;
}
function font(ctx, size, weight = 600) { ctx.font = `${weight} ${size}px Arial, sans-serif`; }
function paintBg(ctx, d) {
  const [ct, cm, cb] = entryCols(d);
  const g = ctx.createLinearGradient(0, 0, 0, 1350);
  g.addColorStop(0, ct); g.addColorStop(.5, cm); g.addColorStop(1, cb);
  ctx.fillStyle = g; ctx.fillRect(0, 0, 1000, 1350);
  const rnd = seeded((d.correct || 0) * 97 + (d.p1 || 1) * 13 + 31);
  ctx.fillStyle = 'rgba(255,255,255,.13)';
  for (let i = 0; i < 80; i++) { ctx.beginPath(); ctx.arc(rnd() * 1000, rnd() * 1350, rnd() * 2 + 1, 0, 7); ctx.fill(); }
  ctx.fillStyle = 'rgba(255,255,255,.06)';
  ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(420, 0); ctx.lineTo(120, 1350); ctx.lineTo(0, 1350); ctx.closePath(); ctx.fill();
}
/** Draw a stack inside a bounded rectangle. Reflow at each size, no clipping. */
function textStack(ctx, blocks, y1, y2) {
  const available = y2 - y1;
  let measured = [];
  for (let scale = 1; scale >= .44; scale -= .04) {
    measured = blocks.filter((b) => b.text).map((b) => {
      const size = Math.round(b.size * scale);
      font(ctx, size, b.weight || 600);
      const lines = wrap(ctx, b.text, 872);
      const lh = Math.ceil(size * 1.24);
      return { ...b, size, lines, lh, height: lh * lines.length + 20 * scale };
    });
    if (measured.reduce((sum, b) => sum + b.height, 0) <= available) break;
  }
  const total = measured.reduce((sum, b) => sum + b.height, 0);
  let y = y1 + Math.max(0, (available - total) / 2);
  ctx.textBaseline = 'top';
  measured.forEach((b) => {
    ctx.fillStyle = b.color || '#ffffff'; font(ctx, b.size, b.weight || 600);
    b.lines.forEach((line) => { ctx.fillText(line, 500, y); y += b.lh; });
    y += b.height - b.lh * b.lines.length;
  });
}
export function paintArchiveCard(ctx, d) {
  paintBg(ctx, d);
  ctx.textAlign = 'center'; ctx.textBaseline = 'top';
  ctx.fillStyle = '#fff'; font(ctx, 38, 800); ctx.fillText(tx('share_logo'), 500, 76);
  ctx.fillStyle = 'rgba(255,255,255,.75)'; font(ctx, 24, 400); ctx.fillText('v' + VERSION, 500, 127);
  const arch = DB.archetypes.find((a) => a.id === d.top1);
  ctx.font = '118px sans-serif'; ctx.fillStyle = '#fff';
  ctx.fillText(d.kind === 'duel' ? '🏆' : d.generic ? '🎭' : arch ? arch.e : '✦', 500, 217);
  const [m1, m2] = cardMeta(d);
  const blocks = [{ text: cardTitle(d), size: 60, weight: 800 }];
  if (d.kind === 'duel') {
    d.teams.forEach((t) => blocks.push({ text: `${teamName(t)} · ${t.score}`, size: 40, weight: 700, color: '#ffe196' }));
  } else {
    if (!d.generic && d.top1 && d.pct != null) blocks.push({ text: `${archName(d.top1)} — ${d.pct}%`, size: 33, weight: 400 });
    blocks.push({ text: cardSub(d), size: 38, weight: 800, color: '#ffe196' });
    if (!d.generic && d.top2 && d.p2 != null && d.total > 0) blocks.push({ text: tx('card_shadow_fmt', { a: archName(d.top2), p: Math.round(d.p2 / d.total * 100) }), size: 29, weight: 400, color: '#e2e3f8' });
  }
  blocks.push({ text: m1, size: 32 }, { text: m2, size: 29, weight: 400, color: '#e2e3f8' });
  textStack(ctx, blocks, 410, 1080);
  ctx.fillStyle = 'rgba(0,0,0,.28)'; ctx.fillRect(0, 1130, 1000, 220);
  textStack(ctx, [
    { text: tx('share_title'), size: 35, weight: 800 },
    { text: tx('share_tag'), size: 26, weight: 400, color: '#e2e3f8' },
  ], 1160, 1320);
}
const thumbCache = new Map();
export function resolveCardImg(entry, large = false) {
  const d = cardData(entry);
  if (!d) return '';
  // Language is part of the key. Old stored bitmaps are NEVER a locale fallback.
  const key = JSON.stringify([entry.id, CARD_SCHEMA, lang(), large, d]);
  if (thumbCache.has(key)) return thumbCache.get(key);
  try {
    const cv = document.createElement('canvas'); cv.width = 1000; cv.height = 1350;
    const ctx = cv.getContext('2d'); if (!ctx) return '';
    paintArchiveCard(ctx, d);
    let image;
    if (large) image = cv.toDataURL('image/jpeg', .9);
    else {
      const thumb = document.createElement('canvas'); thumb.width = 360; thumb.height = 486;
      thumb.getContext('2d').drawImage(cv, 0, 0, 360, 486);
      image = thumb.toDataURL('image/jpeg', .82);
    }
    if (thumbCache.size >= 50) thumbCache.delete(thumbCache.keys().next().value);
    thumbCache.set(key, image);
    return image;
  } catch { return ''; } // localized DOM caption is still usable without Canvas
}
export function archiveResultCard({defer=false}={}) {
  if (!S || S.cardArchived) return;
  const d = S.mode === 'duel' ? duelCardData() : (S.card ? soloCardData() : null);
  if (!d) return;
  addSavedCard({
    id: S.runId ? 'card-'+S.runId : Date.now().toString(36) + Math.random().toString(36).slice(2, 8),
    ts: Date.now(), schema: CARD_SCHEMA, mode: d.kind, theme: d.theme, d, cols: entryCols(d),
  },{defer});
  S.cardArchived = true;
}
