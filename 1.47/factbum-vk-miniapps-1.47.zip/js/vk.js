/**
 * VK Mini Apps adapter for «Факт-бум. Кто ты?» (v1.47).
 *
 * The game's only platform layer (VK Bridge). Design goals:
 *  - Runs inside VK Mini Apps (webview with window.vkBridge, injected by
 *    js/vk-bridge.min.js — the official @vkontakte/vk-bridge browser bundle).
 *  - Degrades gracefully outside the app (local preview / solo file build):
 *    the game still boots and plays as a guest, ads/cloud simply report
 *    "unavailable" instead of throwing.
 *  - Provides: init, player profile, VK Storage cloud sync, ads
 *    (interstitial + rewarded).
 *
 * VK Bridge reference: https://dev.vk.ru/ru/bridge/overview
 * Ads:                VKWebAppCheckNativeAds / VKWebAppShowNativeAds
 * Storage:            VKWebAppStorageGet / VKWebAppStorageSet / VKWebAppStorageGetKeys
 * User:               VKWebAppGetUserInfo / VKWebAppGetLaunchParams
 */
import { pauseForAd, resumeForAd } from './sound.js?v=1.47';
import { setPaused } from './pause.js?v=1.47';
import { VK_STORAGE_PREFIX, VK_CHUNK_BYTES } from './config.js?v=1.47';

let vk = null;
let vkUser = null;
let vkLaunch = null;

/** Current language reported by the VK client (ru/en only — the game has two locales). */
export let vkPlatformLang = 'ru';

/* ------------------------------ bridge access ----------------------------- */

function bridge() {
  if (typeof window !== 'undefined' && window.vkBridge) return window.vkBridge;
  if (typeof window !== 'undefined' && window.vkConnect) return window.vkConnect; // legacy
  return null;
}

function send(method, params) {
  const b = bridge();
  if (!b) return Promise.reject(new Error('vk bridge unavailable'));
  if (typeof b.sendPromise === 'function') return b.sendPromise(method, params);
  if (typeof b.send === 'function') return b.send(method, params);
  return Promise.reject(new Error('vk bridge send unavailable'));
}

function deadline(promise, ms, message) {
  let timer;
  return Promise.race([
    promise,
    new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(message)), ms); }),
  ]).finally(() => clearTimeout(timer));
}

/* -------------------------------- language -------------------------------- */

function mapLang(code) {
  if (code === undefined || code === null) return 'ru';
  const c = String(code).toLowerCase();
  if (c === 'ru' || c === '0' || c.startsWith('ru') || c === 'uk' || c === 'ua' || c === '1' || c === 'be' || c === '2' || c === 'kz') return 'ru';
  return 'en'; // en, pt, es and everything else → English locale
}

/* ----------------------------------- init --------------------------------- */

function guestResult() {
  return { vk: null, user: null, lang: 'ru' };
}

/**
 * Initialize VK Bridge. Returns { vk, user, lang } or a minimal object when
 * the bridge is unavailable (local / solo preview). Never throws.
 */
export async function initVk() {
  try {
    // file:// (solo single-file build): no VK client can exist.
    if (typeof location !== 'undefined' && location.protocol === 'file:') return guestResult();
    const b = bridge();
    if (!b) return guestResult();
    // Inside the app the page is a native webview (Android/iOS) or an iframe
    // hosted by the client (desktop / in-app browser). In a plain top-level
    // browser tab there is no client to answer bridge calls — enter guest
    // mode immediately instead of waiting for bridge timeouts.
    let embedded = false;
    try { embedded = (typeof b.isWebView === 'function' && b.isWebView()) || (typeof b.isIframe === 'function' && b.isIframe()); } catch { /* ignore */ }
    if (!embedded) return guestResult();

    try { await deadline(send('VKWebAppInit'), 4000, 'VKWebAppInit timeout'); } catch { /* non-fatal */ }

    // Launch params (language, app id, user id, …).
    try {
      vkLaunch = await deadline(send('VKWebAppGetLaunchParams'), 4000, 'launch params timeout');
    } catch { vkLaunch = null; }

    // Basic user info (no extra scopes needed for id + name + photo).
    try {
      const info = await deadline(send('VKWebAppGetUserInfo'), 4000, 'user info timeout');
      if (info && info.id) {
        vkUser = {
          id: String(info.id),
          name: [info.first_name, info.last_name].filter(Boolean).join(' ') || '',
          photo: info.photo_200 || info.photo_100 || '',
        };
      }
    } catch { vkUser = null; }

    vk = b;
    vkPlatformLang = mapLang(vkLaunch && vkLaunch.vk_language);
    window.dispatchEvent(new CustomEvent('factbum:sdk-available', { detail: { lang: vkPlatformLang } }));
    return { vk, user: describeUser(), lang: vkPlatformLang };
  } catch (err) {
    // Local / non-VK preview: run as guest with local storage only.
    return guestResult();
  }
}

export function describeUser() {
  if (!vkUser) return null;
  try {
    return { id: vkUser.id, name: vkUser.name || '', authorized: true };
  } catch { return null; }
}

export function isAuthorized() { return !!vkUser; }
export function vkPlayerName() { return (vkUser && vkUser.name) || ''; }
export function vkPlayerID() { return (vkUser && vkUser.id) || ''; }
export function legacyVkPlayerID() { return ''; } // no legacy VK profile format

/* --------------------------------- chrome --------------------------------- */

/**
 * Defensive UX rules required by the platform: no context menu, no text
 * selection. Layout/safe-area is handled by css/layout.css (env(safe-area-inset-*)).
 * The VK build intentionally has NO "close" button — the VK client provides
 * the system close control; a broken one would break gameplay (moderation
 * remark #3).
 */
export function applyVkChrome() {
  try {
    const block = (e) => { if (e && e.preventDefault) e.preventDefault(); return false; };
    document.addEventListener('contextmenu', block, { passive: false });
  } catch { /* ignore */ }
  try {
    document.body.style.webkitUserSelect = 'none';
    document.body.style.userSelect = 'none';
    document.body.style.webkitTouchCallout = 'none';
  } catch { /* ignore */ }
}

/** VK Mini Apps run inside the client webview — no fullscreen request needed. */
export function requestFullscreen() { /* no-op for VK */ }

/** VK has no LoadingAPI.ready(); a successful VKWebAppInit is enough. */
export function gameReady() { /* no-op for VK */ }

/** VK has no GameplayAPI — gameplay pause/resume is driven by visibility. */
export function gameplayStart() { /* no-op for VK */ }
export function gameplayStop() { /* no-op for VK */ }

/* ------------------------------- VK Storage --------------------------------
 * VK Storage is a flat key→string store (up to 1000 keys per user, up to
 * 4096 bytes per value). The sync layer writes a single JSON blob per cloud
 * key, so we split values into numbered chunks and reassemble on read.
 * -------------------------------------------------------------------------- */

function safeTag(s) {
  return String(s || '').replace(/[^a-zA-Z0-9_.:-]/g, '').slice(0, 80);
}

/** chunk → storage key. `<cloudKey>` is e.g. "factbum_v3_device_<actor>". */
function chunkKey(cloudKey, index) { return VK_STORAGE_PREFIX + safeTag(cloudKey) + '_' + index; }
function countKey(cloudKey) { return VK_STORAGE_PREFIX + safeTag(cloudKey) + '__n'; }

function uidTag(uid) { return safeTag(String(uid || 'local')); }

/** Split a string into chunks of at most maxBytes UTF-8 bytes, never inside a
 * multi-byte code point. */
function chunkByBytes(str, maxBytes) {
  const enc = new TextEncoder();
  const chunks = [];
  let cur = '';
  let curBytes = 0;
  for (const ch of String(str)) {
    const b = enc.encode(ch).length;
    if (cur && curBytes + b > maxBytes) { chunks.push(cur); cur = ''; curBytes = 0; }
    cur += ch;
    curBytes += b;
  }
  if (cur) chunks.push(cur);
  return chunks;
}

export function cloudUsable(uid) {
  return !!(vk && vkUser && uid === 'vk-' + vkUser.id);
}

/** Distinguish empty cloud data from offline/failed reads. */
export async function cloudReadAll(uid) {
  if (!cloudUsable(uid)) return { ok: false, reason: 'unavailable', data: null };
  try {
    const own = VK_STORAGE_PREFIX;
    const list = await deadline(send('VKWebAppStorageGetKeys', { count: 1000, offset: 0 }), 6000, 'storage keys timeout');
    const allKeys = (list && Array.isArray(list.keys)) ? list.keys : [];
    const mine = allKeys.filter((k) => typeof k === 'string' && k.startsWith(own));
    if (!mine.length) return { ok: true, data: {} };

    // Batch VKWebAppStorageGet by 50 keys.
    const data = {};
    for (let i = 0; i < mine.length; i += 50) {
      const batch = mine.slice(i, i + 50);
      const res = await deadline(send('VKWebAppStorageGet', { keys: batch }), 8000, 'storage get timeout');
      if (res && Array.isArray(res.keys)) {
        res.keys.forEach((kv) => { if (kv && typeof kv.key === 'string') data[kv.key] = kv.value || ''; });
      }
    }
    return { ok: true, data: reassemble(mine, data) };
  } catch {
    return { ok: false, reason: 'offline', data: null };
  }
}

/** Rebuild {cloudKey: value} from chunk keys `<prefix><cloudKey>_<i>` + count key. */
function reassemble(keys, values) {
  const out = {};
  const counts = {};
  const seen = new Set(keys);
  keys.forEach((k) => {
    if (k.endsWith('__n')) {
      const cloudKey = k.slice(VK_STORAGE_PREFIX.length, -3);
      counts[cloudKey] = parseInt(values[k], 10) || 0;
    }
  });
  const cloudKeys = new Set(Object.keys(counts));
  keys.forEach((k) => {
    if (k.endsWith('__n')) return;
    const body = k.slice(VK_STORAGE_PREFIX.length);
    const idx = body.lastIndexOf('_');
    if (idx < 0) return;
    const cloudKey = body.slice(0, idx);
    const chunkIndex = parseInt(body.slice(idx + 1), 10);
    if (Number.isNaN(chunkIndex) || !seen.has(k)) return;
    cloudKeys.add(cloudKey);
  });
  cloudKeys.forEach((cloudKey) => {
    const n = counts[cloudKey] || 0;
    const parts = [];
    let missing = false;
    for (let i = 0; i < n; i++) {
      const v = values[chunkKey(cloudKey, i)];
      if (v === undefined) { missing = true; break; }
      parts.push(v);
    }
    if (!missing) out[cloudKey] = parts.join('');
  });
  return out;
}

export async function cloudWrite(values, uid) {
  if (!cloudUsable(uid) || !values) return false;
  const tag = uidTag(uid);
  try {
    for (const [cloudKey, value] of Object.entries(values)) {
      const ck = safeTag(cloudKey);
      if (!ck) continue;
      if (value === null || value === undefined || value === '') {
        // Retire/delete: clear count + any known chunks.
        await send('VKWebAppStorageSet', { key: countKey(ck), value: '' });
        // Only the count is authoritative; stale chunks are ignored on read.
        continue;
      }
      const str = typeof value === 'string' ? value : JSON.stringify(value);
      const chunks = chunkByBytes(str, VK_CHUNK_BYTES);
      await send('VKWebAppStorageSet', { key: countKey(ck), value: String(chunks.length) });
      for (let i = 0; i < chunks.length; i++) {
        await send('VKWebAppStorageSet', { key: chunkKey(ck, i), value: chunks[i] });
      }
      // Clear the recently-shrunk tail so stale chunks never accumulate
      // (VK Storage is limited to 1000 keys per user).
      for (let i = chunks.length; i < chunks.length + 16; i++) {
        await send('VKWebAppStorageSet', { key: chunkKey(ck, i), value: '' });
      }
    }
    return true;
  } catch {
    return false;
  }
}

/** Simple keyed helpers (unused by the v3 sync, kept for completeness). */
export async function cloudGet(key) {
  const uid = vkUser ? 'vk-' + vkUser.id : '';
  const r = await cloudReadAll(uid);
  return r.ok && r.data ? (r.data[key] ?? null) : null;
}
export async function cloudSet(key, value) {
  const uid = vkUser ? 'vk-' + vkUser.id : '';
  return cloudWrite({ [key]: value }, uid);
}

/* ---------------------------------- Ads -----------------------------------
 * VK monetization (moderation remark #4). Only Android/iOS clients show ads;
 * on other platforms the call resolves false and the game continues.
 *  - interstitial: shown at natural level boundaries (after a run ends);
 *  - rewarded: the player watches voluntarily for a bonus figure piece.
 * -------------------------------------------------------------------------- */

export async function showFullscreen() {
  if (!vk) return false;
  pauseForAd(); // game sound must pause for the duration of the ad
  try {
    const r = await deadline(send('VKWebAppShowNativeAds', { ad_format: 'interstitial' }), 60000, 'ad timeout');
    return !!(r && r.result);
  } catch {
    return false;
  } finally {
    resumeForAd();
  }
}

/** Returns true only if the rewarded video was watched to the end. */
export async function showRewarded() {
  if (!vk) return false;
  pauseForAd();
  try {
    const r = await deadline(send('VKWebAppShowNativeAds', { ad_format: 'reward' }), 90000, 'rewarded ad timeout');
    return !!(r && r.result);
  } catch {
    return false;
  } finally {
    resumeForAd();
  }
}

export function isAdsAvailable() {
  return !!vk;
}

/** Open the VK share dialog (used from the result card). */
export async function shareToFeed(text) {
  if (!vk) return false;
  try {
    await deadline(send('VKWebAppShare', { link: typeof location !== 'undefined' ? location.href : '' }), 60000, 'share timeout');
    return true;
  } catch {
    try {
      await deadline(send('VKWebAppShowWallPostBox', { message: text }), 60000, 'wall post timeout');
      return true;
    } catch {
      return false;
    }
  }
}

/* ------------------------- lifecycle / platform events -------------------- */

if (typeof window !== 'undefined') {
  // VK sends VKWebAppViewRestore / VKWebAppViewHide when the app is hidden.
  window.addEventListener('message', (e) => {
    const d = e && e.detail ? e.detail : (e && e.data);
    if (!d) return;
    const type = d.type || (d.detail && d.detail.type);
    if (type === 'VKWebAppViewHide') setPaused('platform', true);
    else if (type === 'VKWebAppViewRestore') setPaused('platform', false);
  });
}


