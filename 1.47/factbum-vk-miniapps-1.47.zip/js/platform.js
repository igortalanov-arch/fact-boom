/**
 * Platform facade for «Факт-бум. Кто ты?» (v1.47).
 *
 * The game ships for VK Mini Apps. All SDK calls are routed through the
 * adapter in js/vk.js (VK Bridge). Outside the app (local/solo preview)
 * the adapter degrades gracefully to guest mode: no SDK, localStorage
 * only, ads/cloud report "unavailable" instead of throwing.
 *
 * Detection: the authoritative signal is the bridge itself — when vkBridge
 * is present AND the page runs as a native webview or an iframe hosted by
 * the client, we are inside the app. URL launch parameters (vk_user_id /
 * vk_app_id / vk_platform), the `platform=vk` flag and a mobile user-agent
 * are secondary hints. Anything else runs as a local guest.
 */
import * as vk from './vk.js?v=1.47';

function bridgeEmbedded() {
  try {
    const b = (typeof window !== 'undefined') && (window.vkBridge || window.vkConnect);
    if (!b) return false;
    return (typeof b.isWebView === 'function' && b.isWebView()) ||
           (typeof b.isIframe === 'function' && b.isIframe());
  } catch { return false; }
}

export function isVk() {
  if (typeof window === 'undefined') return false;
  try {
    const q = (location.search || '').toLowerCase();
    if (q.indexOf('platform=vk') !== -1 || q.indexOf('vk_user_id=') !== -1 ||
        q.indexOf('vk_app_id=') !== -1 || q.indexOf('vk_platform=') !== -1) return true;
    if (window.__VK__ === true) return true;
    if (bridgeEmbedded()) return true;
    const ua = String(navigator.userAgent || '');
    return /\bVK(?:MiniApp|MobileClient|Connect|WebApp)?\b|vkwebapp/i.test(ua);
  } catch { return false; }
}

/** Init the bridge. Guest-safe: never throws, resolves for local preview too. */
export async function initPlatform() { return vk.initVk(); }

/* ------------------------------- chrome / lifecycle ------------------------ */

export function applyPlatformChrome() {
  vk.applyVkChrome();
  // The `html.vk` class activates the in-client layout rules in css/app.css
  // (safe-area padding, chrome position under the app header).
  if (isVk()) { try { document.documentElement.classList.add('vk'); } catch { /* ignore */ } }
}
export function requestFullscreen() { vk.requestFullscreen(); }
export function gameReady() { vk.gameReady(); }
export function gameplayStart() { vk.gameplayStart(); }
export function gameplayStop() { vk.gameplayStop(); }

/* ---------------------------------- player --------------------------------- */

export function isAuthorized() { return vk.isAuthorized(); }
export function playerName() { return vk.vkPlayerName(); }
export function playerID() { return vk.vkPlayerID(); }
export function platformLang() { return vk.vkPlatformLang; }
export function describeUser() { return vk.describeUser(); }

/* ------------------------------- cloud storage ----------------------------- */

export function cloudUsable(uid) { return vk.cloudUsable(uid); }
export function cloudReadAll(uid) { return vk.cloudReadAll(uid); }
export function cloudWrite(values, uid) { return vk.cloudWrite(values, uid); }

/* ------------------------------------ ads ---------------------------------- */

export function showFullscreen() { return vk.showFullscreen(); }
export function showRewarded() { return vk.showRewarded(); }
export function isAdsAvailable() { return vk.isAdsAvailable(); }

export function shareToFeed(text) { return vk.shareToFeed(text); }
